import React, { useState, useEffect } from 'react';
import { authenticatedApi } from './api';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Modal from 'react-modal';
import ImageGallery from 'react-image-gallery';
import 'react-image-gallery/styles/css/image-gallery.css';

Modal.setAppElement('#root');

interface Variant {
  color: string;
  size: string;
  price: number;
}

interface Product {
  id_producto: number;
  nombre: string;
  precio: number;
  stock: number;
  descripcion: string;
  id_categoria: number;
  id_subcategoria: number;
  id_marca: number; // Campo para marca
  foto: string[]; // Fotos es un array de strings (URLs)
  variants: Variant[];
}

interface Category {
  id_categoria: number;
  descripcion: string;
}

interface Subcategory {
  id_subcategoria: number;
  id_categoria: number;
  descripcion: string;
}

interface Marca {
  id_marca: number;
  nombre: string;
}

const ProductManager: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [subcategories, setSubcategories] = useState<Subcategory[]>([]);
  const [marcas, setMarcas] = useState<Marca[]>([]);
  const [filteredSubcategories, setFilteredSubcategories] = useState<Subcategory[]>([]);
  const [newProduct, setNewProduct] = useState<{
    nombre: string;
    precio: string;
    stock: string;
    descripcion: string;
    id_categoria: string;
    id_subcategoria: string;
    id_marca: string; // Campo para marca
    foto: string;
  }>({
    nombre: '',
    precio: '',
    stock: '',
    descripcion: '',
    id_categoria: '',
    id_subcategoria: '',
    id_marca: '',
    foto: '',
  });
  const [variants, setVariants] = useState<Variant[]>([]);
  const [editMode, setEditMode] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [files, setFiles] = useState<File[]>([]);
  const [modalIsOpen, setModalIsOpen] = useState(false);
  const [currentImages, setCurrentImages] = useState<any[]>([]);
  const [editModalIsOpen, setEditModalIsOpen] = useState(false);

  useEffect(() => {
    fetchProducts();
    fetchCategories();
    fetchSubcategories();
    fetchMarcas();
  }, []);

  const fetchProducts = async () => {
    try {
      const response = await authenticatedApi.get('/productos');
      setProducts(response.data);
    } catch (error) {
      console.error('Error al cargar los productos:', error);
      toast.error('Error al cargar los productos');
    }
  };

  const fetchCategories = async () => {
    try {
      const response = await authenticatedApi.get('/categorias');
      setCategories(response.data);
    } catch (error) {
      console.error('Error al cargar las categorías:', error);
      toast.error('Error al cargar las categorías');
    }
  };

  const fetchSubcategories = async () => {
    try {
      const response = await authenticatedApi.get('/subcategorias');
      setSubcategories(response.data);
    } catch (error) {
      console.error('Error al cargar las subcategorías:', error);
      toast.error('Error al cargar las subcategorías');
    }
  };

  const fetchMarcas = async () => {
    try {
      const response = await authenticatedApi.get('/productos/marcas');
      setMarcas(response.data);
    } catch (error) {
      console.error('Error al cargar las marcas:', error);
      toast.error('Error al cargar las marcas');
    }
  };

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setNewProduct({ ...newProduct, [name]: value });

    if (name === 'id_categoria') {
      const filteredSubs = subcategories.filter((sub) => sub.id_categoria === parseInt(value));
      setFilteredSubcategories(filteredSubs);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setFiles (Array.from(e.target.files));
    }
  };

  const addVariant = () => {
    setVariants([...variants, { color: '', size: '', price: 0 }]);
  };

  const removeVariant = (index: number) => {
    const newVariants = variants.filter((_, i) => i !== index);
    setVariants(newVariants);
  };

  const handleVariantChange = (index: number, field: string, value: string) => {
    const newVariants = variants.map((variant, i) => {
      if (i === index) {
        return { ...variant, [field]: field === 'price' ? parseFloat(value) : value };
      }
      return variant;
    });
    setVariants(newVariants);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append('nombre', newProduct.nombre);
    formData.append('precio', newProduct.precio.toString());
    formData.append('stock', newProduct.stock.toString());
    formData.append('descripcion', newProduct.descripcion);
    formData.append('id_categoria', newProduct.id_categoria);
    formData.append('id_subcategoria', newProduct.id_subcategoria);
    formData.append('id_marca', newProduct.id_marca); // Agregar marca
    formData.append('variants', JSON.stringify(variants));
    if (files.length > 0) {
      files.forEach((file) => {
        formData.append('fotos', file);
      });
    }
    try {
      const response = editMode
        ? await authenticatedApi.put(`/productos/${selectedProduct?.id_producto}`, formData)
        : await authenticatedApi.post('/productos', formData);
      setProducts(
        editMode
          ? products.map((p) => (p.id_producto === response.data.id_producto ? response.data : p))
          : [...products, response.data]
      );
      resetForm();
      toast.success(`Producto ${editMode ? 'actualizado' : 'agregado'} con éxito`);
      if (editMode) {
        closeEditModal();
      }
    } catch (error: any) {
      console.error('Error al enviar el formulario:', error);
      if (error.response && error.response.data) {
        console.error('Detalles del error:', error.response.data);
      }
      toast.error(`Error al ${editMode ? 'actualizar' : 'agregar'} el producto`);
    }
  };

  const resetForm = () => {
    setNewProduct({
      nombre: '',
      precio: '',
      stock: '',
      descripcion: '',
      id_categoria: '',
      id_subcategoria: '',
      id_marca: '',
      foto: '',
    });
    setFiles([]);
    setVariants([]);
    setSelectedProduct(null);
    setEditMode(false);
    setFilteredSubcategories([]);
  };

  const handleEdit = (product: Product) => {
    setSelectedProduct(product);
    const filteredSubs = subcategories.filter((sub) => sub.id_categoria === product.id_categoria);
    setFilteredSubcategories(filteredSubs);
    setNewProduct({
      nombre: product.nombre || '', // Asignar vacío si es null
      precio: product.precio !== null ? product.precio.toString() : '0', // Manejar null
      stock: product.stock !== null ? product.stock.toString() : '0', // Manejar null
      descripcion: product.descripcion || '', // Asignar vacío si es null
      id_categoria: product.id_categoria !== null ? product.id_categoria.toString() : '', // Manejar null
      id_subcategoria: product.id_subcategoria !== null ? product.id_subcategoria.toString() : '', // Manejar null
      id_marca: product.id_marca !== null ? product.id_marca.toString() : '', // Manejar null
      foto: '', // Vacío porque las fotos se manejan en otro lugar
    });
    setVariants(product.variants || []); // Variantes se cargan correctamente
    setEditMode(true);
    setEditModalIsOpen(true); // Abre el modal de edición
  };

  const handleDelete = async (id: number) => {
    try {
      await authenticatedApi.delete(`/productos/${id}`);
      setProducts(products.filter((p) => p.id_producto !== id));
      toast.success('Producto eliminado con éxito');
    } catch (error) {
      console.error('Error al eliminar producto:', error);
      toast.error('Error al eliminar producto');
    }
  };

  const openModal = (images: string[]) => {
    const galleryImages = images.map((imgUrl) => ({
      original: imgUrl,
      thumbnail: imgUrl,
    }));
    setCurrentImages(galleryImages);
    setModalIsOpen(true);
  };

  const closeModal = () => {
    setModalIsOpen(false);
  };

  const closeEditModal = () => {
    setEditModalIsOpen(false);
    resetForm();
  };

  return (
    <div className="container mx-auto px-4 py-6">
      {/* Modal de Edición */}
      <Modal
        isOpen={editModalIsOpen}
        onRequestClose={closeEditModal}
        contentLabel="Editar Producto"
        style={{
          overlay: {
            backgroundColor: 'rgba(0, 0, 0, 0.75)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
          },
          content: {
            background: 'white',
            padding: '20px',
            borderRadius: '8px',
            maxWidth: '600px',
            width: '100%',
            maxHeight: '90vh',
            overflowY: 'auto',
          },
        }}
      >
        <h2 className="text-2xl font-bold mb-6">Editar Producto</h2>
        <form onSubmit={handleSubmit} className="mb-8 p-6 bg-gray-100 rounded-lg shadow-md">
          {/* Nombre */}
          <div className="mb-4">
            <label className="block text-gray-700 text-sm font-bold mb-2">Nombre:</label>
            <input
              type="text"
              name="nombre"
              value={newProduct.nombre}
              onChange={handleInputChange}
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700"
              required
            />
          </div>

          {/* Precio */}
          <div className="mb-4">
            <label className="block text-gray-700 text-sm font-bold mb-2">Precio:</label>
            <input
              type="number"
              name="precio"
              value={newProduct.precio}
              onChange={handleInputChange}
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700"
              required
            />
          </div>

          {/* Stock */}
          <div className="mb-4">
            <label className="block text-gray-700 text-sm font-bold mb-2">Stock:</label>
            <input
              type="number"
              name="stock"
              value={newProduct.stock}
              onChange={handleInputChange}
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700"
              required
            />
          </div>

          {/* Categoría */}
          <div className="mb-4">
            <label className="block text-gray-700 text-sm font-bold mb-2">Categoría:</label>
            <select
              name="id_categoria"
              value={newProduct.id_categoria}
              onChange={handleInputChange}
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700"
              required
            >
              <option value="">Seleccionar Categoría</option>
              {categories.map((category) => (
                <option key={category.id_categoria} value={category.id_categoria}>
                  {category.descripcion}
                </option>
              ))}
            </select>
          </div>

          {/* Subcategoría */}
          <div className="mb-4">
            <label className="block text-gray-700 text-sm font-bold mb-2">Subcategoría:</label>
            <select
              name="id_subcategoria"
              value={newProduct.id_subcategoria}
              onChange={handleInputChange}
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700"
              required
            >
              <option value="">Seleccionar Subcategoría</option>
              {filteredSubcategories.map((sub) => (
                <option key={sub.id_subcategoria} value={sub.id_subcategoria}>
                  {sub.descripcion}
                </option>
              ))}
            </select>
          </div>

          {/* Marca */}
          <div className="mb-4">
            <label className="block text-gray-700 text-sm font-bold mb-2">Marca:</label>
            <select
              name="id_marca"
              value={newProduct.id_marca}
              onChange={handleInputChange}
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700"
              required
            >
              <option value="">Seleccionar Marca</option>
              {marcas.map((marca) => (
                <option key={marca.id_marca} value={marca.id_marca}>
                  {marca.nombre}
                </option>
              ))}
            </select>
          </div>

          {/* Descripción */}
          <div className="mb-4">
            <label className="block text-gray-700 text-sm font-bold mb-2">Descripción:</label>
            <textarea
              name="descripcion"
              value={newProduct.descripcion}
              onChange={handleInputChange}
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700"
              required
            />
          </div>

          {/* Variantes */}
          <div className="mb-4">
            <label className="block text-gray-700 text-sm font-bold mb-2">Variantes:</label>
            {variants.map((variant, index) => (
              <div key={index} className="mb-4 border p-2 rounded bg-white shadow">
                <div className="mb-2">
                  <label className="block text-gray-700 text-sm font-bold mb-1">Color :</label>
                  <input
                    type="text"
                    value={variant.color}
                    onChange={(e) => handleVariantChange(index, 'color', e.target.value)}
                    className="shadow appearance-none border rounded w-full py-1 px-2 text-gray-700"
                    required
                  />
                </div>
                <div className="mb-2">
                  <label className="block text-gray-700 text-sm font-bold mb-1">Tamaño:</label>
                  <input
                    type="text"
                    value={variant.size}
                    onChange={(e) => handleVariantChange(index, 'size', e.target.value)}
                    className="shadow appearance-none border rounded w-full py-1 px-2 text-gray-700"
                    required
                  />
                </div>
                <div className="mb-2">
                  <label className="block text-gray-700 text-sm font-bold mb-1">Precio:</label>
                  <input
                    type="number"
                    value={variant.price}
                    onChange={(e) => handleVariantChange(index, 'price', e.target.value)}
                    className="shadow appearance-none border rounded w-full py-1 px-2 text-gray-700"
                    required
                    step="0.01"
                  />
                </div>
                <button
                  type="button"
                  onClick={() => removeVariant(index)}
                  className="bg-red-500 hover:bg-red-700 text-white font-bold py-1 px-2 rounded"
                >
                  Eliminar Variante
                </button>
              </div>
            ))}
            <button
              type="button"
              onClick={addVariant}
              className="bg-[#D96299] hover:bg-[#F2C2DC] text-white font-bold py-1 px-2 rounded"
            >
              Agregar Variante
            </button>
          </div>

          {/* Fotos */}
          <div className="mb-4">
            <label className="block text-gray-700 text-sm font-bold mb-2">Fotos:</label>
            <input
              type="file"
              name="fotos"
              onChange={handleFileChange}
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700"
              multiple
            />
          </div>

          <div className="flex justify-end">
            <button
              type="submit"
              className="bg-[#D96299] hover:bg-[#F2C2DC] text-white font-bold py-2 px-4 rounded"
            >
              {editMode ? 'Actualizar' : 'Agregar'}
            </button>
            <button
              type="button"
              onClick={closeEditModal}
              className="ml-4 bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded"
            >
              Cancelar
            </button>
          </div>
        </form>
      </Modal>

      {/* Formulario para Agregar Productos */}
      <h2 className="text-2xl font-bold mb-6">Agregar Producto</h2>
      <form onSubmit={handleSubmit} className="mb-8 p-6 bg-gray-100 rounded-lg shadow-md">
        {/* Nombre */}
        <div className="mb-4">
          <label className="block text-gray-700 text-sm font-bold mb-2">Nombre:</label>
          <input
            type="text"
            name="nombre"
            value={newProduct.nombre}
            onChange={handleInputChange}
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700"
            required
          />
        </div>

        {/* Precio */}
        <div className="mb-4">
          <label className="block text-gray-700 text-sm font-bold mb-2">Precio:</label>
          <input
            type="number"
            name="precio"
            value={newProduct.precio}
            onChange={handleInputChange}
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700"
            required
          />
        </div>

        {/* Stock */}
        <div className="mb-4">
          <label className="block text-gray-700 text-sm font-bold mb-2">Stock:</label>
          <input
            type="number"
            name="stock"
            value={newProduct.stock}
            onChange={handleInputChange}
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700"
            required
          />
        </div>

        {/* Categoría */}
        <div className="mb-4">
          <label className="block text-gray-700 text-sm font-bold mb-2">Categoría:</label>
          <select
            name="id_categoria"
            value={newProduct.id_categoria}
            onChange={handleInputChange}
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700"
            required
          >
            <option value="">Seleccionar Categoría</option>
            {categories.map((category) => (
              <option key={category.id_categoria} value={category.id_categoria}>
                {category.descripcion}
              </option>
            ))}
          </select>
        </div>

        {/* Subcategoría */}
        <div className="mb-4">
          <label className="block text-gray-700 text-sm font-bold mb-2">Subcategoría:</label>
          <select
            name="id_subcategoria"
            value={newProduct.id_subcategoria}
            onChange={handleInputChange}
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700"
            required
          >
            <option value="">Seleccionar Subcategoría</option>
            {filteredSubcategories.map((sub) => (
              <option key={sub.id_subcategoria} value={sub.id_subcategoria}>
                {sub.descripcion}
              </option>
            ))}
          </select>
        </div>

        {/* Marca */}
        <div className="mb-4">
          <label className="block text-gray-700 text-sm font-bold mb-2">Marca:</label>
          <select
            name="id_marca"
            value={newProduct.id_marca}
            onChange={handleInputChange}
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700"
            required
          >
            <option value="">Seleccionar Marca</option>
            {marcas.map((marca) => (
              <option key={marca.id_marca} value={marca.id_marca}>
                {marca.nombre}
              </option>
            ))}
          </select>
        </div>

        {/* Descripción */}
        <div className="mb-4">
          <label className="block text-gray-700 text-sm font-bold mb-2">Descripción:</label>
          <textarea
            name="descripcion"
            value={newProduct.descripcion}
            onChange={handleInputChange}
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700"
            required
          />
        </div>

        {/* Variantes */}
        <div className="mb-4">
          <label className="block text-gray-700 text-sm font-bold mb-2">Variantes:</label>
          {variants.map((variant, index) => (
            <div key={index} className="mb-4 border p-2 rounded bg-white shadow">
              <div className="mb-2">
                <label className="block text-gray-700 text-sm font-bold mb-1">Color:</label>
                <input
                  type="text"
                  value={variant.color}
                  onChange={(e) => handleVariantChange(index, 'color', e.target.value)}
                  className="shadow appearance-none border rounded w-full py-1 px-2 text-gray-700"
                  required
                />
              </div>
              <div className="mb-2">
                <label className="block text-gray-700 text-sm font-bold mb-1">Tamaño:</label>
                <input
                  type="text"
                  value={variant.size}
                  onChange={(e) => handleVariantChange(index, 'size', e.target.value)}
                  className="shadow appearance-none border rounded w-full py-1 px-2 text-gray-700"
                  required
                />
              </div>
              <div className="mb-2">
                <label className="block text-gray-700 text-sm font-bold mb-1">Precio:</label>
                <input
                  type="number"
                  value={variant.price}
                  onChange={(e) => handleVariantChange(index, 'price', e.target.value)}
                  className="shadow appearance-none border rounded w-full py-1 px-2 text-gray-700"
                  required
                  step="0.01"
                />
              </div>
              <button
                type="button"
                onClick={() => removeVariant(index)}
                className="bg-red-500 hover:bg-red-700 text-white font-bold py-1 px-2 rounded"
              >
                Eliminar Variante
              </button>
            </div>
          ))}
          <button
            type="button"
            onClick={addVariant}
            className="bg-[#D96299] hover:bg-[#F2C2DC] text-white font-bold py-1 px-2 rounded"
          >
            Agregar Variante
          </button>
        </div>

        {/* Fotos */}
        <div className="mb-4">
          <label className="block text-gray-700 text-sm font-bold mb-2">Fotos:</label>
          <input
            type="file"
            name="fotos"
            onChange={handleFileChange}
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700"
            multiple
          />
        </div>

        <button
          type="submit"
          className="bg-[#D96299] hover:bg-[#F2C2DC] text-white font-bold py-2 px-4 rounded"
        >
          {editMode ? 'Actualizar' : 'Agregar'}
        </button>
      </form>

      {/* Listado de Productos */}
      <div className="bg-white p-6 rounded-lg shadow-md">
        <h3 className="text-xl font-semibold mb-4">Listado de Productos</h3>
        <table className="table-auto w-full mt-4 border border-gray-300">
          <thead>
            <tr className="bg-[#F2D5D5] border-b border-gray-300">
              <th className="px-4 py-2 border-r border-gray-300">ID</th>
              <th className="px-4 py-2 border-r border-gray-300">Nombre</th>
              <th className="px-4 py-2 border-r border-gray-300">Precio</th>
              <th className="px-4 py-2 border-r border-gray-300">Stock</th>
              <th className="px-4 py-2 border-r border-gray-300">Categoría</th>
              <th className="px-4 py-2 border-r border-gray-300">Subcategoría</th>
              <th className="px-4 py-2 border-r border-gray-300">Marca</th>
              <th className="px-4 py-2 border-r border-gray-300">Fotos</th>
              <th className="px-4 py-2 border-r border-gray-300">Variantes</th>
              <th className="px-4 py-2">Acciones</th>
            </tr>
          </thead>
          <tbody>
            {products.map((product) => (
              <tr key={product.id_producto} className="border-b border-gray-300">
                <td className="px-4 py-2 border-r border-gray-300">{product.id_producto}</td>
                <td className="px-4 py-2 border-r border-gray-300">{product.nombre}</td>
                <td className="px-4 py-2 border-r border-gray-300">
                  ₲{product.precio.toLocaleString('es-PY')}
                </td>
                <td className="px-4 py-2 border-r border-gray-300">{product.stock}</td>
                <td className="px-4 py-2 border-r border-gray-300">{product.id_categoria}</td>
                <td className="px-4 py-2 border-r border-gray-300">{product.id_subcategoria}</td>
                <td className="px-4 py-2 border-r border-gray-300">{product.id_marca}</td>
                <td className="px-4 py-2 border-r border-gray-300">
                  {product.foto &&
                    product.foto.length > 0 &&
                    product.foto.map((fotoUrl, index) => (
                      <img
                        key={index}
                        src={fotoUrl}
                        alt="Producto"
                        className="h-10 w-10 rounded-full cursor-pointer inline-block mr-2"
                        onClick={() => openModal(product.foto)}
                      />
                    ))}
                </td>
                <td className="px-4 py-2 border-r border-gray-300">
                  {product.variants &&
                    product.variants.length > 0 &&
                    product.variants.map((variant, index) => (
                      <div key={index} className="mb-2 border-b pb-2">
                        <p>
                          <strong>Color:</strong> {variant.color}
                        </p>
                        <p>
                          <strong>Tamaño:</strong> {variant.size}
                        </p>
                        <p>
                          <strong>Precio:</strong> ₲
                          {variant.price.toLocaleString('es-PY')}
                        </p>
                      </div>
                    ))}
                </td>
                <td className="px-4 py-2">
                  <button
                    className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-1 px-2 rounded mb-1"
                    onClick={() => handleEdit(product)}
                  >
                    Editar
                  </button>
                  <button
                    className="bg-red-500 hover:bg-red-700 text-white font-bold py-1 px-2 rounded"
                    onClick={() => handleDelete(product.id_producto)}
                  >
                    Eliminar
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Modal de Imágenes */}
      <Modal
        isOpen={modalIsOpen}
        onRequestClose={closeModal}
        contentLabel="Galería de Imágenes"
        style={{
          overlay: {
            backgroundColor: 'rgba(0, 0, 0,  0.75)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
          },
          content: {
            background: 'white',
            padding: '20px',
            borderRadius: '8px',
            maxWidth: '800px',
            width: '100%',
            maxHeight: '90vh',
            overflowY: 'auto',
          },
        }}
      >
        <button
          onClick={closeModal}
          className="mb-4 bg-gray-500 hover:bg-gray-700 text-white font-bold py-1 px-2 rounded"
        >
          Cerrar
        </button>
        <ImageGallery items={currentImages} />
      </Modal>

      <ToastContainer />
    </div>
  );
};

export default ProductManager;