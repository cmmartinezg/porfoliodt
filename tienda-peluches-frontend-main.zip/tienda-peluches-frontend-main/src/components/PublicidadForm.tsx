import React, { useState, useEffect } from "react";
import api from "./api";
import Modal from "react-modal";

interface Publicidad {
  id_publicidad: number;
  titulo: string;
  descripcion: string;
  imagen: string;
}

const PublicidadForm: React.FC = () => {
  const [titulo, setTitulo] = useState("");
  const [descripcion, setDescripcion] = useState("");
  const [imagen, setImagen] = useState<File | null>(null);
  const [publicidades, setPublicidades] = useState<Publicidad[]>([]);
  const [modalIsOpen, setModalIsOpen] = useState(false);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  useEffect(() => {
    const fetchPublicidades = async () => {
      try {
        const res = await api.get("/publicidad");
        setPublicidades(res.data);
      } catch (error) {
        console.error("Error al obtener publicidades:", error);
        alert("Error al cargar las publicidades");
      }
    };
    fetchPublicidades();
  }, []);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setImagen(e.target.files[0]);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!titulo || !descripcion || !imagen) {
      alert("Todos los campos son obligatorios");
      return;
    }

    const formData = new FormData();
    formData.append("titulo", titulo);
    formData.append("descripcion", descripcion);
    formData.append("imagen", imagen);

    try {
      const res = await api.post("/publicidad", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });

      if (res.status === 201) {
        alert("Publicidad creada con éxito");
        setPublicidades((prev) => [...prev, res.data]);
        setTitulo("");
        setDescripcion("");
        setImagen(null);
      } else {
        alert("Error al crear la publicidad: " + res.data.message);
      }
    } catch (error: any) {
      console.error("Error al subir la publicidad:", error);
      alert(
        "Error al subir la publicidad: " +
          (error.response?.data?.message || "Error desconocido")
      );
    }
  };

  const openModal = (image: string) => {
    setSelectedImage(image);
    setModalIsOpen(true);
  };

  const closeModal = () => {
    setModalIsOpen(false);
    setSelectedImage(null);
  };

  const deletePublicidad = async (id: number) => {
    try {
      await api.delete(`/publicidad/${id}`);
      setPublicidades((prev) => prev.filter((pub) => pub.id_publicidad !== id));
      alert("Publicidad eliminada con éxito");
    } catch (error: any) {
      console.error("Error al eliminar la publicidad:", error);
      alert(
        "Error al eliminar la publicidad: " +
          (error.response?.data?.message || "Error desconocido")
      );
    }
  };

  return (
    <div style={styles.formContainer}>
      <h2 style={styles.formTitle}>Subir Publicidad</h2>
      <form onSubmit={handleSubmit} style={styles.form}>
        <div style={styles.inputGroup}>
          <label style={styles.label}>Título:</label>
          <input
            type="text"
            value={titulo}
            onChange={(e) => setTitulo(e.target.value)}
            style={styles.input}
            required
          />
        </div>
        <div style={styles.inputGroup}>
          <label style={styles.label}>Descripción:</label>
          <textarea
            value={descripcion}
            onChange={(e) => setDescripcion(e.target.value)}
            style={styles.textarea}
            required
          />
        </div>
        <div style={styles.inputGroup}>
          <label style={styles.label}>Imagen:</label>
          <input
            type="file"
            accept="image/*"
            onChange={handleImageChange}
            style={styles.inputFile}
            required
          />
        </div>
        <button type="submit" style={styles.submitButton}>
          Subir Publicidad
        </button>
      </form>

      <h2 style={styles.formTitle}>Publicidades Existentes</h2>
      {publicidades.length > 0 ? (
        <table style={styles.table}>
          <thead>
            <tr>
              <th style={styles.tableHeader}>ID</th>
              <th style={styles.tableHeader}>Título</th>
              <th style={styles.tableHeader}>Descripción</th>
              <th style={styles.tableHeader}>Imagen</th>
              <th style={styles.tableHeader}>Acciones</th>
            </tr>
          </thead>
          <tbody>
            {publicidades.map((pub) => (
              <tr key={pub.id_publicidad}>
                <td style={styles.tableCell}>{pub.id_publicidad}</td>
                <td style={styles.tableCell}>{pub.titulo}</td>
                <td style={styles.tableCell}>{pub.descripcion}</td>
                <td style={styles.tableCell}>
                  <img
                    src={pub.imagen}
                    alt={pub.titulo}
                    style={styles.imageThumbnail}
                    onClick={() => openModal(pub.imagen)} // Abre el modal al hacer clic en la imagen
                  />
                </td>
                <td style={styles.tableCell}>
                  <button
                    onClick={() => deletePublicidad(pub.id_publicidad)}
                    style={styles.deleteButton}
                  >
                    Eliminar
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <p style={{ textAlign: "center" }}>No hay publicidades disponibles.</p>
      )}

      {/* Modal para mostrar la imagen */}
      <Modal
        isOpen={modalIsOpen}
        onRequestClose={closeModal}
        style={modalStyles}
      >
        <h2 style={styles.formTitle}>Imagen de Publicidad</h2>
        {selectedImage && (
          <img src={selectedImage} alt="Publicidad" style={styles.modalImage} />
        )}
        <button onClick={closeModal} style={styles.closeButton}>
          Cerrar
        </button>
      </Modal>
    </div>
  );
};

// Estilos actualizados con el nuevo diseño
const styles: any = {
  formContainer: {
    maxWidth: "800px", // Se amplió el ancho del contenedor del formulario
    margin: "0 auto",
    padding: "20px",
    //   border: `2px solid #D96299`,
    borderRadius: "10px",
    backgroundColor: "#FFFFFF", // Cambiado a un fondo gris claro
  },
  titleDescriptionContainer: {
    backgroundColor: "#FFFFFF", // Fondo blanco para el título y la descripción
    padding: "15px",
    borderRadius: "8px",
    marginBottom: "20px", // Espacio inferior para separar del resto del formulario
  },
  formTitle: {
    textAlign: "center",
    fontSize: "24px", // Tamaño del texto más grande
    color: "#000", // Color negro
    fontWeight: "bold", // Texto en negrita
  },
  form: {
    display: "flex",
    flexDirection: "column" as "column",
    gap: "25px", // Aumentado el espacio vertical entre los elementos
  },
  inputGroup: {
    display: "flex",
    flexDirection: "column" as "column",
    width: "100%", // Expandir los elementos horizontalmente
  },
  label: {
    marginBottom: "5px",
    color: "#000", // Color negro
    fontWeight: "bold", // Texto en negrita
  },
  input: {
    padding: "10px",
    border: "1px solid #F24BA7",
    borderRadius: "5px",
    backgroundColor: "#FFFFFF",
    width: "100%", // Expandir los inputs horizontalmente
  },
  textarea: {
    padding: "10px",
    border: "1px solid #F24BA7",
    borderRadius: "5px",
    backgroundColor: "#FFFFFF",
    height: "100px",
    width: "100%", // Expandir el textarea horizontalmente
  },
  inputFile: {
    marginTop: "5px",
  },
  submitButton: {
    padding: "10px",
    backgroundColor: "#D96299",
    color: "#fff",
    marginTop: "10px",
    marginBottom: "20px",
    border: "none",
    borderRadius: "5px",
    cursor: "pointer",
    transition: "background-color 0.3s ease",
    width: "100%", // Expandir el botón horizontalmente
  },
  table: {
    width: "100%",
    borderCollapse: "collapse",
    marginTop: "20px",
  },
  tableHeader: {
    border: "1px solid #D96299",
    padding: "10px",
    backgroundColor: "#F24BA7",
    color: "#fff",
    fontWeight: "bold", // Texto en negrita para los encabezados de la tabla
  },
  tableCell: {
    border: "1px solid #D96299",
    padding: "10px",
    backgroundColor: "#F2D5D5",
  },
  imageThumbnail: {
    width: "50px",
    height: "50px",
    objectFit: "cover",
    cursor: "pointer",
    border: "2px solid #D96299",
  },
  deleteButton: {
    padding: "5px",
    backgroundColor: "#F24BA7",
    color: "#fff",
    border: "none",
    borderRadius: "5px",
    cursor: "pointer",
    transition: "background-color 0.3s ease",
  },
  modalImage: {
    maxWidth: "100%",
    maxHeight: "400px",
    marginBottom: "20px",
  },
  closeButton: {
    padding: "10px",
    backgroundColor: "#555",
    color: "#fff",
    border: "none",
    borderRadius: "5px",
    cursor: "pointer",
    transition: "background-color 0.3s ease",
  },
};

// Estilos para el modal
const modalStyles = {
  overlay: {
    backgroundColor: "rgba(0, 0, 0, 0.7)",
  },
  content: {
    top: "50%",
    left: "50%",
    right: "auto",
    bottom: "auto",
    transform: "translate(-50%, -50%)",
    padding: "20px",
    border: `2px solid #F24BA7`,
    backgroundColor: "#F2C2DC",
  },
};

export default PublicidadForm;
