import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Swiper, SwiperSlide } from "swiper/react";
import { Link } from "react-router-dom";
import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/pagination";
import "swiper/css/autoplay";
import { Navigation, Pagination, Autoplay } from "swiper/modules";
import { useCart } from "./CartContext"; // Contexto del carrito
import { authenticatedApi } from "./api"; // API para obtener los productos
import ImageGallery from "react-image-gallery";
import "react-image-gallery/styles/css/image-gallery.css";
import tiktokicon from "../assets/tiktok.png"; // Importa la imagen de TikTok
import igicon from "../assets/ig.png";
import fbicon from "../assets/fb.png";
import whatsappIcon from "../assets/pngwing.com.png"; // Importa la imagen de WhatsApp
interface Variant {
  color: string;
  size: string;
  price: number;
}

interface Product {
  id_producto: number;
  nombre: string;
  precio: number;
  foto: string[]; // Ahora es un arreglo de URLs
  descripcion: string;
  stock: number;
  id_categoria: number;
  variants?: Variant[]; // Variants es un arreglo de Variant
}

interface ProductCardProps {
  product: {
    id: number;
    name: string;
    price: number;
    image: string;
  };
}

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const navigate = useNavigate();

  const handleClick = () => {
    navigate(`/producto/${product.id}`);
  };

  return (
    <div
      className="bg-white p-4 rounded-lg shadow-md transition-transform duration-500 hover:scale-105 cursor-pointer  flex flex-col items-center justify-center"
      onClick={handleClick}
    >
      <img
        src={product.image}
        alt={product.name}
        className="w-full h-30 object-cover rounded-md"
      />
      <h4 className="text-lg font-bold mt-2">{product.name}</h4>
      <p className="text-pink-600 font-bold">
        Gs. {product.price.toLocaleString("es-PY")}
      </p>
    </div>
  );
};

const ProductDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [product, setProduct] = useState<Product | null>(null);
  const [relatedProducts, setRelatedProducts] = useState<Product[]>([]);
  const [otherProducts, setOtherProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [quantity, setQuantity] = useState(1);
  const { addToCart } = useCart();
  const [selectedColor, setSelectedColor] = useState("");
  const [selectedSize, setSelectedSize] = useState("");

  // Obtener el producto individual
  useEffect(() => {
    const fetchProduct = async () => {
      try {
        const response = await authenticatedApi.get(`/productos/${id}`);
        const productData = response.data; // Cambiado 'let' por 'const'

        // Manejar 'variants' si es una cadena
        if (productData.variants && typeof productData.variants === "string") {
          productData.variants = JSON.parse(productData.variants);
        }

        // Manejar 'variants' si es un objeto
        if (productData.variants && !Array.isArray(productData.variants)) {
          productData.variants = Object.values(productData.variants);
        }

        setProduct(productData);
      } catch (error) {
        console.error("Error al cargar el producto:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchProduct();
  }, [id]);

  // Obtener productos relacionados por categoría y otros productos
  useEffect(() => {
    if (product) {
      const fetchProducts = async () => {
        try {
          const response = await authenticatedApi.get("/productos");
          const allProducts = response.data;

          // Filtrar productos de la misma categoría que el actual
          const related = allProducts.filter(
            (p: Product) =>
              p.id_categoria === product.id_categoria &&
              p.id_producto !== product.id_producto
          );

          // Filtrar otros productos de categorías diferentes
          const other = allProducts.filter(
            (p: Product) => p.id_categoria !== product.id_categoria
          );

          setRelatedProducts(related.slice(0, 5)); // Mostrar solo 5 productos relacionados
          setOtherProducts(other.slice(0, 5)); // Mostrar solo 5 productos de otras categorías
        } catch (error) {
          console.error("Error al cargar los productos:", error);
        }
      };

      fetchProducts();
    }
  }, [product]);

  // Añadir al carrito
  const handleAddToCart = () => {
    if (product) {
      if (variantsArray.length > 0) {
        if (!selectedColor || !selectedSize) {
          alert("Por favor, selecciona un color y un tamaño.");
          return;
        }

        addToCart({
          id: product.id_producto,
          name: product.nombre,
          price: selectedVariant?.price || product.precio,
          image: product.foto[0],
          quantity: quantity,
          color: selectedColor,
          size: selectedSize,
        });

        alert(
          `${quantity} ${product.nombre} (${selectedColor}, ${selectedSize}) ha(n) sido añadido(s) al carrito.`
        );
      } else {
        // Si no tiene variantes, agregar directamente
        addToCart({
          id: product.id_producto,
          name: product.nombre,
          price: product.precio,
          image: product.foto[0],
          quantity: quantity,
          color: "",
          size: "",
        });

        alert(
          `${quantity} ${product.nombre} ha(n) sido añadido(s) al carrito.`
        );
      }
    }
  };

  // Límite de stock para cantidad solicitada
  const handleQuantityChange = (newQuantity: number) => {
    const limitedQuantity = Math.max(
      1,
      Math.min(newQuantity, product?.stock || 1)
    );
    setQuantity(limitedQuantity);
  };

  const incrementQuantity = () => {
    handleQuantityChange(quantity + 1);
  };

  const decrementQuantity = () => {
    handleQuantityChange(quantity - 1);
  };

  // Obtener variantes según color y tamaño seleccionados
  const variantsArray = Array.isArray(product?.variants)
    ? product!.variants
    : [];

  const availableSizes = selectedColor
    ? [
        ...new Set(
          variantsArray
            .filter((v) => v.color === selectedColor)
            .map((v) => v.size)
        ),
      ]
    : [];

  const selectedVariant = variantsArray.find(
    (variant) =>
      variant.color === selectedColor && variant.size === selectedSize
  );

  if (loading) {
    return <p>Cargando...</p>;
  }

  if (!product) {
    return <p>No se encontró el producto.</p>;
  }

  // Preparar imágenes para el carrusel
  const images = product.foto.map((url) => ({
    original: url,
    thumbnail: url,
  }));

  return (
    <div className="flex flex-col min-h-screen">
      <div className="max-w-6xl mx-auto p-5 flex-grow mt-8">
        {/* Detalle del producto */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Galería de imágenes */}
          <div className="space-y-4">
            <div className="w-full h-[475px] max-h-[470px] overflow-hidden flex justify-center items-center">
              <ImageGallery
                items={images}
                showThumbnails={true}
                showPlayButton={false}
                renderItem={(item) => (
                  <div className="image-gallery-image relative flex justify-center items-center">
                    <img
                      src={item.original}
                      alt=""
                      className="object-cover w-[550px] h-[550px]"
                    />
                  </div>
                )}
                renderThumbInner={(item) => (
                  <div className="h-16 w-16 overflow-hidden rounded-lg border-2 border-transparent hover:border-pink-500 transition">
                    <img
                      src={item.thumbnail}
                      alt=""
                      className="object-cover w-full h-full"
                    />
                  </div>
                )}
              />
            </div>
          </div>

          {/* Descripción y detalles */}
          <div className="bg-white p-8 rounded-lg shadow-lg">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">
              {product.nombre}
            </h2>
            <div className="flex items-center mb-4">
              <span className="text-green-500 text-lg font-semibold">
                Stock: {product.stock}
              </span>
            </div>
            <p className="text-pink-600 font-bold text-3xl mb-6">
              Gs.{" "}
              {(selectedVariant?.price || product.precio).toLocaleString(
                "es-PY"
              )}
            </p>
            <p className="text-gray-700 text-lg mb-6">{product.descripcion}</p>

            {/* Selección de variantes */}
            {variantsArray.length > 0 ? (
              <div className="mb-6">
                <div className="mb-4">
                  <label className="block text-gray-700 font-semibold mb-2">
                    Color:
                  </label>
                  <div className="flex space-x-3">
                    {[...new Set(variantsArray.map((v) => v.color))].map(
                      (color, index) => (
                        <button
                          key={index}
                          onClick={() => setSelectedColor(color)}
                          className={`px-4 py-2 rounded ${
                            selectedColor === color
                              ? "bg-pink-500 text-white"
                              : "bg-gray-200 text-gray-700"
                          }`}
                        >
                          {color}
                        </button>
                      )
                    )}
                  </div>
                </div>
                {selectedColor && (
                  <div className="mb-4">
                    <label className="block text-gray-700 font-semibold mb-2">
                      Tamaño:
                    </label>
                    <div className="flex space-x-3">
                      {availableSizes.map((size, index) => (
                        <button
                          key={index}
                          onClick={() => setSelectedSize(size)}
                          className={`px-4 py-2 rounded ${
                            selectedSize === size
                              ? "bg-pink-500 text-white"
                              : "bg-gray-200 text-gray-700"
                          } hover:bg-pink-100 transition-colors`}
                        >
                          {size}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="mb-6">
                <p className="text-gray-700">
                  Este producto no tiene variantes disponibles.
                </p>
              </div>
            )}

            {/* Selección de cantidad */}
            <div className="flex items-center mb-6">
              <span className="mr-4 text-lg font-semibold">Cantidad</span>
              <div className="flex items-center border border-gray-300 rounded">
                <button
                  onClick={decrementQuantity}
                  className="bg-gray-100 text-black py-2 px-3 rounded-l hover:bg-gray-200 transition"
                >
                  −
                </button>
                <input
                  type="number"
                  value={quantity}
                  min={1}
                  max={product.stock}
                  readOnly
                  className="w-12 text-center border-0 focus:ring-0"
                />
                <button
                  onClick={incrementQuantity}
                  className="bg-gray-100 text-black py-2 px-3 rounded-r hover:bg-gray-200 transition"
                >
                  +
                </button>
              </div>

              <button
                onClick={handleAddToCart}
                className="bg-pink-500 text-white py-2 px-4 rounded-lg hover:bg-pink-600 transition ml-4"
              >
                Añadir al Carrito
              </button>
            </div>

            {/* Información de envío */}
            <div className="mt-6">
              <p className="text-sm text-gray-500">
                🚚 Opción de envío o (pickup) disponible.
              </p>
              <p className="text-sm text-gray-500">
                🔄 Devoluciones en un plazo de 24 horas a partir de la recepción
                del producto.
              </p>
            </div>
          </div>
        </div>

        <div className="my-8">
          <h3 className="text-2xl font-bold text-gray-800 mb-4">
            Te pueden interesar
          </h3>
          <Swiper
            spaceBetween={10}
            slidesPerView={3}
            navigation
            pagination={{ clickable: true }}
            autoplay={{ delay: 3000 }}
            modules={[Navigation, Pagination, Autoplay]}
            className="w-full"
          >
            {relatedProducts.map((related) => (
              <SwiperSlide key={related.id_producto}>
                <ProductCard
                  product={{
                    id: related.id_producto,
                    name: related.nombre,
                    price: related.precio,
                    image: related.foto[0],
                  }}
                />
              </SwiperSlide>
            ))}
          </Swiper>

          <style>
            {`
      .swiper-button-next,
      .swiper-button-prev {
        color: #D96299 !important; /* Flechas en rosa */
      }
      .swiper-pagination-bullet {
        background: #D96299 !important; /* Puntos de paginación en rosa */
      }
      .swiper-pagination-bullet-active {
        background: #F24BA7 !important; /* Punto activo en rosa más oscuro */
      }
    `}
          </style>
        </div>

        {/* Carrusel de otros productos */}
        <div className="my-8">
          <h3 className="text-2xl font-bold text-gray-800 mb-4">
            Más productos que te pueden gustar
          </h3>
          <Swiper
            spaceBetween={10}
            slidesPerView={3}
            navigation
            pagination={{ clickable: true }}
            autoplay={{ delay: 3000 }}
            modules={[Navigation, Pagination, Autoplay]}
            className="w-full"
          >
            {otherProducts.map((other) => (
              <SwiperSlide key={other.id_producto}>
                <ProductCard
                  product={{
                    id: other.id_producto,
                    name: other.nombre,
                    price: other.precio,
                    image: other.foto[0], // Usar la primera imagen
                  }}
                />
              </SwiperSlide>
            ))}
          </Swiper>
        </div>
      </div>

      {/* Pie de página */}
      <footer
        style={{
          backgroundColor: "#F2C2DC",
        }}
        className="text-center py-5 w-full mt-auto" // Cambiado a py-5 para menos espacio
      >
        <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Columna Nueva Izquierda - La Empresa */}
          <div className="flex flex-col items-center text-center">
            <h3
              className="text-2xl font-bold mb-2 tracking-wide"
              style={{ color: "#F24BA7" }}
            >
              La Empresa
            </h3>
            <Link
              to="/about-us"
              className="font-bold mt-2"
              style={{ color: "#F24BA7" }}
            >
              Sobre Nosotros
            </Link>
            <Link
              to="/about-us"
              className="font-bold mt-2"
              style={{ color: "#F24BA7" }}
            >
              Misión
            </Link>
            <Link
              to="/about-us"
              className="font-bold mt-2"
              style={{ color: "#F24BA7" }}
            >
              Visión
            </Link>
          </div>

          {/* Columna Izquierda - ¿Dónde Estamos? */}
          <div className="flex flex-col items-center text-center">
            <h3
              className="text-2xl font-bold mb-2 tracking-wide"
              style={{ color: "#F24BA7" }}
            >
              ¿Dónde Estamos?
            </h3>
            <p className="mt-2 font-bold" style={{ color: "#F24BA7" }}>
              Eusebio Lillo Robles Esquina, Asunción 001409
            </p>
            <div className="mt-2">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3607.3354307710406!2d-57.5567853!3d-25.292932!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x945da89294287697%3A0x164ec5c39508981e!2sBoopillows%20Py!5e0!3m2!1ses-419!2spy!4v1728595022183!5m2!1ses-419!2spy"
                width="300"
                height="200"
                style={{ border: "0" }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              ></iframe>
            </div>
          </div>

          {/* Columna Derecha - Atención al Cliente */}
          <div className="flex flex-col items-center text-center">
            <h3
              className="text-2xl font-bold mb-4 tracking-wide"
              style={{ color: "#F24BA7" }}
            >
              Atención al Cliente
            </h3>
            <ul className="mt-3 space-y-3">
              <li>
                <a
                  href="/politica-privacidad"
                  className="font-bold hover:text-pink-300 transition duration-300"
                  style={{ color: "#F24BA7" }}
                >
                  Políticas de Privacidad
                </a>
              </li>

              <li>
                <Link
                  to="/return-policy"
                  className="font-bold hover:text-pink-300 transition duration-300"
                  style={{ color: "#F24BA7" }}
                >
                  Políticas de Cambios y Devoluciones
                </Link>
              </li>
              <li>
                <a
                  href="https://beacons.ai/boopillows"
                  className="font-bold hover:text-pink-300 transition duration-300"
                  style={{ color: "#F24BA7" }}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Contáctanos
                </a>
              </li>
            </ul>

            {/* Iconos de Redes Sociales */}
            <div className="flex space-x-5 mt-10 justify-center">
              <a
                href="https://wa.me/595983474763"
                target="_blank"
                rel="noopener noreferrer"
              >
                <img src={whatsappIcon} alt="WhatsApp" className="h-8 w-8" />
              </a>
              <a
                href="https://www.instagram.com/boopillows/"
                target="_blank"
                rel="noopener noreferrer"
              >
                <img src={igicon} alt="Instagram" className="h-8 w-8" />
              </a>
              <a
                href="https://www.facebook.com/boopillows"
                target="_blank"
                rel="noopener noreferrer"
              >
                <img src={fbicon} alt="Facebook" className="h-8 w-8" />
              </a>
              <a
                href="https://www.tiktok.com/@boopillows"
                target="_blank"
                rel="noopener noreferrer"
              >
                <img src={tiktokicon} alt="TikTok" className="h-8 w-8" />
              </a>
            </div>
          </div>
        </div>

        <div className="mt-4 text-sm text-gray-200 font-bold">
          <p style={{ color: "#F24BA7" }}>
            &copy; {new Date().getFullYear()} Boo Pillows. Todos los derechos
            reservados.
          </p>
        </div>
      </footer>
    </div>
  );
};
export default ProductDetail;
