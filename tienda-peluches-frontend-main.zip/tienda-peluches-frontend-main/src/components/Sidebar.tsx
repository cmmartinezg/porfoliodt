import React, { useState } from "react";
import { Link } from "react-router-dom";
import { FaChevronDown, FaChevronUp, FaBox, FaClipboardList, FaChartBar, FaCog } from "react-icons/fa";

const Sidebar: React.FC = () => {
  const [isProductSectionOpen, setProductSectionOpen] = useState(false);

  return (
    <div className="sidebar bg-gradient-to-b from-blue-800 to-indigo-900 text-white h-full p-6 shadow-2xl transition-all duration-300">
      <h2 className="text-2xl font-bold mb-6">Admin Panel</h2>
      <ul className="space-y-6 text-lg">
        {/* Pedidos */}
        <li>
          <Link to="/orders" className="flex items-center text-gray-300 hover:text-white transition-all duration-300">
            <FaClipboardList className="mr-3 text-xl" /> Pedidos
          </Link>
        </li>

        {/* Ventas */}
        <li>
          <Link to="/sales" className="flex items-center text-gray-300 hover:text-white transition-all duration-300">
            <FaChartBar className="mr-3 text-xl" /> Ventas
          </Link>
        </li>

        {/* Productos con menú desplegable */}
        <li>
          <div
            onClick={() => setProductSectionOpen(!isProductSectionOpen)}
            className="flex items-center justify-between cursor-pointer text-gray-300 hover:text-white transition-all duration-300"
          >
            <div className="flex items-center">
              <FaBox className="mr-3 text-xl" /> Productos
            </div>
            {isProductSectionOpen ? <FaChevronUp /> : <FaChevronDown />}
          </div>

          {isProductSectionOpen && (
            <ul className="pl-6 mt-2 space-y-3 text-base text-gray-400">
              <li>
                <Link to="/upload-product" className="hover:text-white transition-all duration-300">
                  Subir Producto
                </Link>
              </li>
              <li>
                <Link to="/products" className="hover:text-white transition-all duration-300">
                  Ver Productos (Catálogo)
                </Link>
              </li>
            </ul>
          )}
        </li>

        {/* Configuración */}
        <li>
          <Link to="/settings" className="flex items-center text-gray-300 hover:text-white transition-all duration-300">
            <FaCog className="mr-3 text-xl" /> Configuración
          </Link>
        </li>
      </ul>
    </div>
  );
};

export default Sidebar;
