import React from 'react';
import { Link } from 'react-router-dom';
import { useCart } from './CartContext';

interface ProductCardProps {
  product: {
    id: number;
    name: string;
    price: number;
    image: string;
  };
}

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { addToCart } = useCart();

  const handleAddToCart = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.stopPropagation(); // Evita que el clic en el botón propague el evento al contenedor
    addToCart({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      quantity: 1,
      color: '',
      size: ''
    });
    alert(`${product.name} ha sido añadido al carrito`);
  };

  return (
    <div className="bg-white p-4 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300 cursor-pointer">
      <Link to={`/producto/${product.id}`} className="block">
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-40 object-cover rounded-md mb-4"
        />
        <h4 className="text-lg font-bold mb-2">{product.name}</h4>
        <p className="text-pink-600 font-bold mb-4">
          Gs. {product.price.toLocaleString('es-PY')}
        </p>
      </Link>
      <div className="flex justify-end">
        {/* Botón para añadir al carrito */}
        <button
          onClick={handleAddToCart}
          className="bg-pink-500 text-white py-2 px-4 rounded-lg hover:bg-pink-600"
        >
          Añadir al Carrito
        </button>
      </div>
    </div>
  );
};

export default ProductCard;
