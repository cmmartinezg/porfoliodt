// firebaseConfig.tsx
import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider, FacebookAuthProvider } from 'firebase/auth';

// Firebase configuration (credentials provided by you)
const firebaseConfig = {
  apiKey: "AIzaSyBu7AFGg3nzTrBefXwa-VPQ6tF8Dncx2zo",
  authDomain: "boopillows-b8e7b.firebaseapp.com",
  projectId: "boopillows-b8e7b",
  storageBucket: "boopillows-b8e7b.appspot.com",
  messagingSenderId: "983631904651",
  appId: "1:983631904651:web:53656ccc19a9e57f5c398e",
  measurementId: "G-F63T86D04L"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const googleProvider = new GoogleAuthProvider();
const facebookProvider = new FacebookAuthProvider();

//autenticacion con facebook
//https://boopillows-b8e7b.firebaseapp.com/__/auth/handler


export { auth, googleProvider, facebookProvider };
 