import React, { useEffect, useState } from "react";
import { authenticatedApi } from "./api"; // Asegúrate de que la ruta de importación coincida con tu estructura de proyecto
import { toast } from "react-toastify";

interface Order {
  id: number;
  customerName: string;
  totalAmount: number;
  status: string;
  date: string;
}

const Orders: React.FC = () => {
  const [orders, setOrders] = useState<Order[]>([]);

  useEffect(() => {
    authenticatedApi
      .get("/orders")
      .then((response) => setOrders(response.data))
      .catch((error) => {
        console.error("Error fetching orders:", error);
        toast.error("Error al cargar los pedidos");
      });
  }, []);

  const tableStyles: React.CSSProperties = {
    width: "100%",
    borderCollapse: "collapse", // Corregimos el tipo
    backgroundColor: "#FFFFFF", // Fondo blanco de la tabla
  };

  const thStyles: React.CSSProperties = {
    backgroundColor: "#D96299", // Color de fondo del encabezado
    color: "white",
    padding: "10px",
    textAlign: "left",
  };

  const tdStyles: React.CSSProperties = {
    padding: "8px",
    color: "#333333", // Color del texto de las celdas
    borderBottom: "1px solid #CCCCCC", // Línea gris para separar las filas
  };

  const evenRowStyles: React.CSSProperties = {
    backgroundColor: "#F2F2F2", // Color de fondo para filas pares
  };

  const oddRowStyles: React.CSSProperties = {
    backgroundColor: "#FFFFFF", // Color de fondo para filas impares
  };

  const headerStyles: React.CSSProperties = {
    fontSize: "23px", // Tamaño del encabezado
    color: "black", // Color del encabezado
    fontWeight: "bold", // Hace que el texto sea negrita
    marginBottom: "20px", // Espacio debajo del encabezado
  };

  return (
    <div>
      <h1 style={headerStyles}>Gestión de Pedidos</h1>
      <table style={tableStyles}>
        <thead>
          <tr>
            <th style={thStyles}>ID</th>
            <th style={thStyles}>Cliente</th>
            <th style={thStyles}>Monto Total</th>
            <th style={thStyles}>Estado</th>
            <th style={thStyles}>Fecha</th>
          </tr>
        </thead>
        <tbody>
          {orders.map((order, index) => (
            <tr
              key={order.id}
              style={index % 2 === 0 ? evenRowStyles : oddRowStyles}
            >
              <td style={tdStyles}>{order.id}</td>
              <td style={tdStyles}>{order.customerName}</td>
              <td style={tdStyles}>{order.totalAmount}</td>
              <td style={tdStyles}>{order.status}</td>
              <td style={tdStyles}>{order.date}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Orders;
