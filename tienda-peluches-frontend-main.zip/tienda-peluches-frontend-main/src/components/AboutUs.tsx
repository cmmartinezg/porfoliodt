import React, { useEffect } from "react";
import logo from "../assets/boopillowslogo.png"; 
import {
  FaRocket,
  FaLightbulb,
  FaHandshake,
  FaBalanceScale,
  FaHandHoldingHeart,
  FaUsers,
  FaCreativeCommons,
  FaShieldAlt,
} from "react-icons/fa";

const AboutUs: React.FC = () => {
  useEffect(() => {
    // Desplaza la ventana hacia el inicio cuando el componente se monte
    window.scrollTo(0, 0);
  }, []);

  return (
    <section className="py-13 ">
      <div className="max-w-2xl mx-auto text-center py-12 ">
        {/* Logo */}
        <img
          src={logo}
          alt="Boo Pillows Logo"
          className="mx-auto mb-5"
          style={{ width: "150px" }} // Ajusta el tamaño en píxeles según lo necesites
        />
        <div className="flex flex-col gap-8 mb-10">
          {/* Cuadro para Sobre nosotros */}
          <div
            className="p-6 rounded-lg shadow-xl transform hover:scale-105 transition duration-300 ease-in-out mb-5"
            style={{
              backgroundColor: "#F2D5D5",
              boxShadow: "8px 8px 15px rgba(0, 0, 0, 0.2)",
            }}
          >
            <h2
              className="text-3xl font-bold mb-3"
              style={{ color: "#F24BA7" }}
            >
              Sobre nosotros
            </h2>
            <p className="text-lg mb-10">
              Somos una tienda de regalos de Paraguay, una empresa que busca la
              satisfacción del cliente con productos de alta calidad y poco
              comunes en el mercado. Nuestro propósito es que el cliente regale
              una sonrisa en cualquier ocasión especial.
            </p>
          </div>

          {/* Cuadro para Misión */}
          <div
            className="p-6 rounded-lg shadow-xl transform hover:scale-105 transition duration-300 ease-in-out flex flex-col items-center text-center mb-5"
            style={{
              backgroundColor: "#F2D5D5",
              boxShadow: "8px 8px 15px rgba(0, 0, 0, 0.2)",
            }}
          >
            <FaRocket className="text-6xl mb-4" style={{ color: "#F24BA7" }} />
            <h2 className="text-2xl font-bold mb-4">Misión</h2>
            <p className="text-lg">
              Nuestra misión es seleccionar productos únicos y novedosos para
              satisfacer las necesidades y deseos de nuestros clientes,
              asegurando que cada artículo elegido haga de sus momentos más
              especiales.
            </p>
          </div>

          {/* Cuadro para Visión */}
          <div
            className="p-6 rounded-lg shadow-xl transform hover:scale-105 transition duration-300 ease-in-out flex flex-col items-center text-center mb-10"
            style={{
              backgroundColor: "#F2D5D5",
              boxShadow: "8px 8px 15px rgba(0, 0, 0, 0.2)",
            }}
          >
            <FaLightbulb
              className="text-6xl mb-4"
              style={{ color: "#F24BA7" }}
            />
            <h2 className="text-2xl font-bold mb-4">Visión</h2>
            <p className="text-lg">
              Nuestra visión es ser la tienda líder y de referencia reconocida
              por nuestra innovación, calidad y capacidad de inspirar alegría y
              afecto en cada uno de nuestros productos.
            </p>
          </div>
        </div>

        {/* Valores */}
        <div>
          <h2 className="text-3xl font-bold mb-8 " style={{ color: "#F24BA7" }}>
            Valores
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 ">
            {/* Honestidad */}
            <div
              className="flex flex-col items-center p-4 rounded-lg shadow-lg transform hover:scale-105 transition duration-300 ease-in-out flex flex-col"
              style={{ backgroundColor: "#C7F6FF" }}
            >
              <FaHandshake
                className="text-5xl mb-4"
                style={{ color: "#F24BA7" }}
              />
              <h3 className="text-xl font-bold ">Honestidad</h3>
              <p className="text-center">
                Operamos con transparencia y sinceridad, asegurando que nuestros
                clientes y colaboradores puedan confiar plenamente en nosotros.
              </p>
            </div>

            {/* Creatividad */}
            <div
              className="flex flex-col items-center p-4 rounded-lg shadow-lg transform hover:scale-105 transition duration-300 ease-in-out flex flex-col"
              style={{ backgroundColor: "#E3D7FE" }}
            >
              <FaCreativeCommons
                className="text-5xl mb-4"
                style={{ color: "#F24BA7" }}
              />
              <h3 className="text-xl font-bold">Creatividad</h3>
              <p className="text-center">
                Fomentamos la innovación y la originalidad en todos nuestros
                productos y en cada aspecto de nuestro negocio.
              </p>
            </div>

            {/* Confianza */}
            <div
              className="flex flex-col items-center p-4 rounded-lg shadow-lg transform hover:scale-105 transition duration-300 ease-in-out flex flex-col"
              style={{ backgroundColor: "#FFF4B2" }}
            >
              <FaShieldAlt
                className="text-5xl mb-4"
                style={{ color: "#F24BA7" }}
              />
              <h3 className="text-xl font-bold">Confianza</h3>
              <p className="text-center">
                Nos comprometemos a construir relaciones de confianza con
                nuestros clientes y colaboradores.
              </p>
            </div>

            {/* Colaboración */}
            <div
              className="flex flex-col items-center p-4 rounded-lg shadow-lg transform hover:scale-105 transition duration-300 ease-in-out flex flex-col"
              style={{ backgroundColor: "#FFE4E4" }}
            >
              <FaUsers className="text-5xl mb-4" style={{ color: "#F24BA7" }} />
              <h3 className="text-xl font-bold">Colaboración</h3>
              <p className="text-center">
                Valoramos el trabajo en equipo y la cooperación, creyendo que
                juntos logramos más.
              </p>
            </div>

            {/* Respeto */}
            <div
              className="flex flex-col items-center p-4 rounded-lg shadow-lg transform hover:scale-105 transition duration-300 ease-in-out flex flex-col"
              style={{ backgroundColor: "#E7FFDF" }}
            >
              <FaHandHoldingHeart
                className="text-5xl mb-4"
                style={{ color: "#F24BA7" }}
              />
              <h3 className="text-xl font-bold">Respeto</h3>
              <p className="text-center">
                Tratamos a nuestros clientes, colaboradores y proveedores con el
                máximo respeto, valorando la diversidad y las ideas de todos.
              </p>
            </div>

            {/* Integridad */}
            <div
              className="flex flex-col items-center p-4 rounded-lg shadow-lg transform hover:scale-105 transition duration-300 ease-in-out flex flex-col"
              style={{ backgroundColor: "#FFE4E4" }}
            >
              <FaBalanceScale
                className="text-5xl mb-4"
                style={{ color: "#F24BA7" }}
              />
              <h3 className="text-xl font-bold">Integridad</h3>
              <p className="text-center">
                Actuamos con ética y responsabilidad, manteniendo nuestros
                principios en todas nuestras acciones y decisiones.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutUs;
