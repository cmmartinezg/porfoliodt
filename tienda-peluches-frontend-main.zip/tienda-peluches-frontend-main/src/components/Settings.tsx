// Settings.tsx
import React, { Component, ChangeEvent, FormEvent } from 'react';
import axios from 'axios';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

// Definición de interfaces
interface NotificationPreferences {
  newOrders: boolean;
  sales: boolean;
}

interface UserSettingsData {
  username: string;
  email: string;
  notifications: NotificationPreferences;
}

interface CompanySettingsData {
  ruc: string;
  razon_social: string;
  celular_salida: string;
  direccion: string;
  contacto_responsable_nombre_apellido: string;
  contacto_admin_nombre_apellido: string;
  email: string;
}

interface SettingsState {
  userSettings: UserSettingsData;
  companySettings: CompanySettingsData;
  loading: boolean;
  submitting: boolean;
}

// Configuración de axios para autenticación
const authenticatedApi = axios.create({
  baseURL: 'https://tu-api.com/api', // Reemplaza con la URL base de tu API
  headers: {
    'Content-Type': 'application/json',
  },
});

// Agregar un interceptor para incluir el token de autenticación en cada solicitud
authenticatedApi.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('authToken'); // O donde almacenes el token
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

class Settings extends Component<{}, SettingsState> {
  constructor(props: {}) {
    super(props);
    this.state = {
      userSettings: {
        username: '',
        email: '',
        notifications: {
          newOrders: false,
          sales: false,
        },
      },
      companySettings: {
        ruc: '',
        razon_social: '',
        celular_salida: '',
        direccion: '',
        contacto_responsable_nombre_apellido: '',
        contacto_admin_nombre_apellido: '',
        email: '',
      },
      loading: true,
      submitting: false,
    };
  }

  componentDidMount() {
    this.fetchSettings();
  }

  // Función para obtener configuraciones de usuario y empresa
  fetchSettings = async () => {
    try {
      const [userResponse, companyResponse] = await Promise.all([
        authenticatedApi.get('/user-settings'), // Ajusta el endpoint según tu API
        authenticatedApi.get('/company-settings'), // Ajusta el endpoint según tu API
      ]);

      this.setState({
        userSettings: userResponse.data,
        companySettings: companyResponse.data,
        loading: false,
      });
    } catch (error) {
      console.error('Error al obtener las configuraciones:', error);
      toast.error('Error al cargar las configuraciones.');
      this.setState({ loading: false });
    }
  };

  // Manejar cambios en campos de texto de usuario
  handleUserInputChange = (
    e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    this.setState((prevState) => ({
      userSettings: {
        ...prevState.userSettings,
        [name]: value,
      },
    }));
  };

  // Manejar cambios en checkboxes de notificaciones
  handleUserCheckboxChange = (e: ChangeEvent<HTMLInputElement>) => {
    const { name, checked } = e.target;
    this.setState((prevState) => ({
      userSettings: {
        ...prevState.userSettings,
        notifications: {
          ...prevState.userSettings.notifications,
          [name]: checked,
        },
      },
    }));
  };

  // Manejar cambios en campos de texto de empresa
  handleCompanyInputChange = (
    e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    this.setState((prevState) => ({
      companySettings: {
        ...prevState.companySettings,
        [name]: value,
      },
    }));
  };

  // Manejar el envío del formulario
  handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    this.setState({ submitting: true });
    try {
      // Enviar actualizaciones de usuario
      const userResponse = await authenticatedApi.put(
        '/user-settings',
        this.state.userSettings
      ); // Ajusta el endpoint según tu API

      // Enviar actualizaciones de empresa
      const companyResponse = await authenticatedApi.put(
        '/company-settings',
        this.state.companySettings
      ); // Ajusta el endpoint según tu API

      // Actualizar estados con las respuestas
      this.setState({
        userSettings: userResponse.data,
        companySettings: companyResponse.data,
        submitting: false,
      });

      toast.success('Configuraciones actualizadas con éxito.');
    } catch (error) {
      console.error('Error al actualizar las configuraciones:', error);
      toast.error('Error al actualizar las configuraciones.');
      this.setState({ submitting: false });
    }
  };

  render() {
    const { userSettings, companySettings, loading, submitting } = this.state;

    // Definir la paleta de colores
    const colors = {
      primary: '#D96299', // Color para botones
      textDark: '#2c3e50',
      textLight: '#7f8c8d',
      background: 'white',
      inputBorder: '#dcdcdc',
      buttonHover: '#F2C2DC',
    };

    // Definir los estilos en línea
    const styles = {
      page: {
        backgroundColor: colors.background,
        padding: '25px',
        borderRadius: '10px',
        boxShadow: '0 4px 10px rgba(0, 0, 0, 0.05)',
        maxWidth: '900px',
        margin: '40px auto', // Centrado vertical y horizontal
        fontFamily: 'Arial, sans-serif',
      },
      section: {
        marginBottom: '30px',
      },
      sectionTitle: {
        fontSize: '1.7em',
        marginBottom: '15px',
        color: colors.textDark,
        fontWeight: 'bold' as const,
      },
      form: {
        display: 'flex' as const,
        flexDirection: 'column' as const,
        gap: '20px', // Espaciado entre elementos
      },
      label: {
        display: 'flex' as const,
        flexDirection: 'column' as const,
        fontSize: '1.1em',
        color: colors.textDark,
        marginBottom: '15px',
      },
      input: {
        padding: '12px',
        marginTop: '8px',
        width: '100%',
        maxWidth: '500px',
        border: `1px solid ${colors.inputBorder}`,
        borderRadius: '8px',
      },
      checkboxLabel: {
        display: 'flex' as const,
        alignItems: 'center',
        fontSize: '1.1em',
        color: colors.textDark,
        marginBottom: '15px',
      },
      button: {
        padding: '12px 25px',
        border: 'none',
        borderRadius: '8px',
        backgroundColor: colors.primary,
        color: 'white',
        fontSize: '1.1em',
        cursor: 'pointer',
        transition: 'background-color 0.3s ease',
        alignSelf: 'flex-start',
      },
      buttonDisabled: {
        backgroundColor: '#ccc',
        cursor: 'not-allowed',
      },
      sectionContainer: {
        border: `1px solid ${colors.inputBorder}`,
        borderRadius: '8px',
        padding: '20px',
        boxShadow: '0 2px 5px rgba(0, 0, 0, 0.1)',
      },
    };

    return (
      <div style={styles.page}>
        <h1 style={styles.sectionTitle}>⚙️ Configuración</h1>

        {loading ? (
          <p>Cargando configuraciones...</p>
        ) : (
          <form style={styles.form} onSubmit={this.handleSubmit}>
            {/* Preferencias de Cuenta del Usuario */}
            <div style={styles.sectionContainer}>
              <h2 style={styles.sectionTitle}>Preferencias de Cuenta</h2>
              {/* Nombre de Usuario */}
              <label style={styles.label}>
                Nombre de usuario:
                <input
                  type="text"
                  name="username"
                  value={userSettings.username}
                  onChange={this.handleUserInputChange}
                  placeholder="Cambiar nombre de usuario"
                  style={styles.input}
                  required
                />
              </label>

              {/* Correo Electrónico */}
              <label style={styles.label}>
                Correo electrónico:
                <input
                  type="email"
                  name="email"
                  value={userSettings.email}
                  onChange={this.handleUserInputChange}
                  placeholder="Cambiar correo electrónico"
                  style={styles.input}
                  required
                />
              </label>

              {/* Botón de Envío */}
              <button
                type="submit"
                style={{
                  ...styles.button,
                  ...(submitting ? styles.buttonDisabled : {}),
                }}
                disabled={submitting}
                onMouseOver={(e: React.MouseEvent<HTMLButtonElement>) => {
                  if (!submitting) {
                    (e.currentTarget as HTMLButtonElement).style.backgroundColor =
                      colors.buttonHover;
                  }
                }}
                onMouseOut={(e: React.MouseEvent<HTMLButtonElement>) => {
                  (e.currentTarget as HTMLButtonElement).style.backgroundColor =
                    colors.primary;
                }}
              >
                {submitting ? 'Guardando...' : 'Guardar Cambios'}
              </button>
            </div>

            {/* Preferencias de Notificación del Usuario */}
            <div style={styles.sectionContainer}>
              <h2 style={styles.sectionTitle}>Preferencias de Notificación</h2>
              {/* Notificaciones de Nuevos Pedidos */}
              <label style={styles.checkboxLabel}>
                <input
                  type="checkbox"
                  name="newOrders"
                  checked={userSettings.notifications.newOrders}
                  onChange={this.handleUserCheckboxChange}
                  style={{ marginRight: '10px' }}
                />
                Recibir notificaciones de nuevos pedidos
              </label>

              {/* Notificaciones de Ventas */}
              <label style={styles.checkboxLabel}>
                <input
                  type="checkbox"
                  name="sales"
                  checked={userSettings.notifications.sales}
                  onChange={this.handleUserCheckboxChange}
                  style={{ marginRight: '10px' }}
                />
                Recibir notificaciones de ventas
              </label>

              {/* Botón de Envío */}
              <button
                type="submit"
                style={{
                  ...styles.button,
                  ...(submitting ? styles.buttonDisabled : {}),
                }}
                disabled={submitting}
                onMouseOver={(e: React.MouseEvent<HTMLButtonElement>) => {
                  if (!submitting) {
                    (e.currentTarget as HTMLButtonElement).style.backgroundColor =
                      colors.buttonHover;
                  }
                }}
                onMouseOut={(e: React.MouseEvent<HTMLButtonElement>) => {
                  (e.currentTarget as HTMLButtonElement).style.backgroundColor =
                    colors.primary;
                }}
              >
                {submitting ? 'Guardando...' : 'Guardar Preferencias'}
              </button>
            </div>

            {/* Datos Empresariales */}
            <div style={styles.sectionContainer}>
              <h2 style={styles.sectionTitle}>Datos Empresariales</h2>
              {/* RUC */}
              <label style={styles.label}>
                RUC:
                <input
                  type="text"
                  name="ruc"
                  value={companySettings.ruc}
                  onChange={this.handleCompanyInputChange}
                  placeholder="Ingresar RUC"
                  style={styles.input}
                  required
                />
              </label>

              {/* Razón Social */}
              <label style={styles.label}>
                Razón Social:
                <input
                  type="text"
                  name="razon_social"
                  value={companySettings.razon_social}
                  onChange={this.handleCompanyInputChange}
                  placeholder="Ingresar Razón Social"
                  style={styles.input}
                  required
                />
              </label>

              {/* Celular Salida */}
              <label style={styles.label}>
                Celular Salida:
                <input
                  type="text"
                  name="celular_salida"
                  value={companySettings.celular_salida}
                  onChange={this.handleCompanyInputChange}
                  placeholder="Ingresar Celular"
                  style={styles.input}
                  required
                />
              </label>

              {/* Dirección */}
              <label style={styles.label}>
                Dirección:
                <input
                  type="text"
                  name="direccion"
                  value={companySettings.direccion}
                  onChange={this.handleCompanyInputChange}
                  placeholder="Ingresar Dirección"
                  style={styles.input}
                  required
                />
              </label>

              {/* Email */}
              <label style={styles.label}>
                Email:
                <input
                  type="email"
                  name="email"
                  value={companySettings.email}
                  onChange={this.handleCompanyInputChange}
                  placeholder="Ingresar Email"
                  style={styles.input}
                  required
                />
              </label>

              {/* Contacto Responsable */}
              <label style={styles.label}>
                Contacto Responsable (Dueño):
                <input
                  type="text"
                  name="contacto_responsable_nombre_apellido"
                  value={companySettings.contacto_responsable_nombre_apellido}
                  onChange={this.handleCompanyInputChange}
                  placeholder="Ingresar Nombre y Apellido"
                  style={styles.input}
                  required
                />
              </label>

              {/* Contacto Administrativo */}
              <label style={styles.label}>
                Contacto Administrativo:
                <input
                  type="text"
                  name="contacto_admin_nombre_apellido"
                  value={companySettings.contacto_admin_nombre_apellido}
                  onChange={this.handleCompanyInputChange}
                  placeholder="Ingresar Nombre y Apellido"
                  style={styles.input}
                  required
                />
              </label>

              {/* Botón de Envío */}
              <button
                type="submit"
                style={{
                  ...styles.button,
                  ...(submitting ? styles.buttonDisabled : {}),
                }}
                disabled={submitting}
                onMouseOver={(e: React.MouseEvent<HTMLButtonElement>) => {
                  if (!submitting) {
                    (e.currentTarget as HTMLButtonElement).style.backgroundColor =
                      colors.buttonHover;
                  }
                }}
                onMouseOut={(e: React.MouseEvent<HTMLButtonElement>) => {
                  (e.currentTarget as HTMLButtonElement).style.backgroundColor =
                    colors.primary;
                }}
              >
                {submitting ? 'Guardando...' : 'Guardar Datos Empresariales'}
              </button>
            </div>
          </form>
        )}

        {/* Contenedor para las notificaciones */}
        <ToastContainer />
      </div>
    );
  }
}

export default Settings;
