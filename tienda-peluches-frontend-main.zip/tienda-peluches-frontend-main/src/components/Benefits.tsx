// src/components/Benefits.tsx
import React from "react";
import tiktokicon from "../assets/tiktok.png"; // Importa la imagen de TikTok
import igicon from "../assets/ig.png";
import fbicon from "../assets/fb.png";
import whatsappIcon from "../assets/pngwing.com.png"; // Importa la imagen de WhatsApp
import { Link } from "react-router-dom"; // Usar Link para la navegación

const Benefits: React.FC = () => {
  return (
    <section className="py-13">
      <footer
        style={{
          backgroundColor: "#F2C2DC",
        }}
        className="text-center py-5 w-full mt-auto"
      >
        <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Nueva Columna Izquierda */}
          <div className="flex flex-col items-center text-center">
            <h3
              className="text-2xl font-bold mb-2 tracking-wide"
              style={{ color: "#F24BA7" }}
            >
              La Empresa
            </h3>
            <Link
              to="/about-us"
              className="font-bold mt-2"
              style={{ color: "#F24BA7" }}
            >
              Sobre Nosotros
            </Link>
            <Link
              to="/about-us"
              className="font-bold mt-2"
              style={{ color: "#F24BA7" }}
            >
              Misión
            </Link>
            <Link
              to="/about-us"
              className="font-bold mt-2"
              style={{ color: "#F24BA7" }}
            >
              Visión
            </Link>
          </div>

          {/* Columna Central */}
          <div className="flex flex-col items-center text-center">
            <h3
              className="text-2xl font-bold mb-2 tracking-wide"
              style={{ color: "#F24BA7" }}
            >
              ¿Dónde Estamos?
            </h3>
            <p className="mt-2 font-bold" style={{ color: "#F24BA7" }}>
              Eusebio Lillo Robles Esquina, Asunción 001409
            </p>
            <div className="mt-2">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3607.3354307710406!2d-57.5567853!3d-25.292932!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x945da89294287697%3A0x164ec5c39508981e!2sBoopillows%20Py!5e0!3m2!1ses-419!2spy!4v1728595022183!5m2!1ses-419!2spy"
                width="300"
                height="200"
                style={{ border: "0" }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              ></iframe>
            </div>
          </div>

          {/* Columna Derecha */}
          <div className="flex flex-col items-center text-center">
            <h3
              className="text-2xl font-bold mb-4 tracking-wide"
              style={{ color: "#F24BA7" }}
            >
              Atención al Cliente
            </h3>
            <ul className="mt-3 space-y-3">
            <li>
                <a
                  href="/politica-privacidad"
                  className="font-bold hover:text-pink-300 transition duration-300"
                  style={{ color: "#F24BA7" }}
                >
                  Políticas de Privacidad
                </a>
              </li>

              <li>
                <Link
                  to="/return-policy"
                  className="font-bold hover:text-pink-300 transition duration-300"
                  style={{ color: "#F24BA7" }}
                >
                  Políticas de Cambios y Devoluciones
                </Link>
              </li>

              <li>
                <a
                  href="https://beacons.ai/boopillows"
                  className="font-bold hover:text-pink-300 transition duration-300"
                  style={{ color: "#F24BA7" }}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Contáctanos
                </a>
              </li>
            </ul>

            {/* Iconos de Redes Sociales */}
            <div className="flex space-x-5 mt-10 justify-center">
              <a
                href="https://wa.me/595983474763"
                target="_blank"
                rel="noopener noreferrer"
              >
                <img src={whatsappIcon} alt="WhatsApp" className="h-8 w-8" />
              </a>
              <a
                href="https://www.instagram.com/boopillows/"
                target="_blank"
                rel="noopener noreferrer"
              >
                <img src={igicon} alt="Instagram" className="h-8 w-8" />
              </a>
              <a
                href="https://www.facebook.com/boopillows"
                target="_blank"
                rel="noopener noreferrer"
              >
                <img src={fbicon} alt="Facebook" className="h-8 w-8" />
              </a>
              <a
                href="https://www.tiktok.com/@boopillows"
                target="_blank"
                rel="noopener noreferrer"
              >
                <img src={tiktokicon} alt="TikTok" className="h-8 w-8" />
              </a>
            </div>
          </div>
        </div>

        <div className="mt-4 text-sm text-gray-200 font-bold">
          <p style={{ color: "#F24BA7" }}>
            &copy; {new Date().getFullYear()} Peluche Store. Todos los derechos
            reservados.
          </p>
        </div>
      </footer>
    </section>
  );
};

export default Benefits;
