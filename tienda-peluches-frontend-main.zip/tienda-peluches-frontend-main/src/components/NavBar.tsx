import React, { useState, useEffect, useRef } from "react";
import { useNavigate, Link } from "react-router-dom";
import Modal from "react-modal";
import {
  FaBars,
  FaShoppingCart,
  FaTimes,
  FaUser,
  FaArrowLeft,
} from "react-icons/fa";
import { useCart } from "./CartContext";
import authenticatedApi from "./api";
import { FaSearch } from "react-icons/fa"; // Asegúrate de importar el ícono
import boopillowsLogo from "../assets/boopillowslogo.png"; // Ajusta la ruta según tu estructura
import whatsappIcon from "../assets/pngwing.com.png"; // Importa la imagen de WhatsApp

interface Product {
  id_producto: number;
  nombre: string;
  precio: number;
}

interface SubCategory {
  id_subcategoria: number;
  id_categoria: number;
  descripcion: string;
}

interface Category {
  id_categoria: number;
  descripcion: string;
}

// Función para capitalizar la primera letra de cada palabra
const capitalize = (text: string) => {
  return text
    .split(" ")
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ");
};

const Navbar: React.FC = () => {
  const { cartItemCount } = useCart();
  const [isCategoryModalOpen, setIsCategoryModalOpen] = useState(false);
  const [categories, setCategories] = useState<Category[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<Category | null>(
    null
  );
  const [subCategories, setSubCategories] = useState<SubCategory[]>([]);
  const [searchResults, setSearchResults] = useState<Product[]>([]);
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [isSearchModalOpen, setIsSearchModalOpen] = useState(false);
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [userName, setUserName] = useState<string | null>(null);
  const navigate = useNavigate();

  // Ref para el input de búsqueda
  const searchInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const response = await authenticatedApi.get("/categorias");
        setCategories(response.data);
      } catch (error) {
        console.error("Error al cargar categorías:", error);
      }
    };

    fetchCategories();

    const storedUserName = localStorage.getItem("userName");
    if (storedUserName) {
      setUserName(storedUserName);
    }
  }, []);

  const toggleCategoryModal = () => {
    setIsCategoryModalOpen(!isCategoryModalOpen);
    setSelectedCategory(null);
    setSubCategories([]);
  };

  const toggleLoginModal = () => {
    setIsLoginModalOpen(!isLoginModalOpen);
  };

  const handleCategoryClick = async (category: Category) => {
    try {
      const response = await authenticatedApi.get("/subcategorias");
      const allSubCategories: SubCategory[] = response.data;

      const filteredSubCategories = allSubCategories.filter(
        (subcat) => subcat.id_categoria === category.id_categoria
      );

      if (filteredSubCategories.length > 0) {
        setSubCategories(filteredSubCategories);
        setSelectedCategory(category);
      } else {
        navigate(`/categoria/${category.id_categoria}`);
        setIsCategoryModalOpen(false);
      }
    } catch (error) {
      console.error("Error al obtener subcategorías:", error);
      navigate(`/categoria/${category.id_categoria}`);
      setIsCategoryModalOpen(false);
    }
  };

  const closeCategoryModal = () => {
    setIsCategoryModalOpen(false);
    setSelectedCategory(null);
    setSubCategories([]);
  };

  const fetchSearchResults = async (query: string) => {
    try {
      const response = await authenticatedApi.get("/productos");
      const allProducts: Product[] = response.data;

      const filteredProducts = allProducts.filter((product) =>
        product.nombre.toLowerCase().includes(query.toLowerCase())
      );

      setSearchResults(filteredProducts);
    } catch (error) {
      console.error("Error al buscar productos:", error);
    }
  };

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const query = e.target.value;
    setSearchQuery(query);
    if (query) {
      fetchSearchResults(query);
      setIsSearchModalOpen(true);
    } else {
      setIsSearchModalOpen(false);
    }
  };

  const handleSearchResultClick = (id_producto: number) => {
    setIsSearchModalOpen(false);
    navigate(`/producto/${id_producto}`);
  };

  const handleNavigateAndCloseModal = (path: string) => {
    setIsLoginModalOpen(false);
    navigate(path);
  };

  const handleLogout = () => {
    localStorage.removeItem("userName");
    setUserName(null);
    navigate("/login");
  };

  return (
    <nav className="bg-[#F2D5D5] p-4 flex flex-col md:flex-row justify-between items-center shadow-md fixed w-full top-0 z-50">
      {/* Logo y Título */}
      <div className="flex items-center space-x-4 mb-4 md:mb-0">
        <Link to="/" className="hover:opacity-75 transition duration-300">
          <img src={boopillowsLogo} alt="Logo" className="h-16 w-26 " />{" "}
          {/* Cambia el tamaño aquí */}
        </Link>
      </div>

      {/* Contenedor principal del buscador con flex y margenes */}
      <div className="flex flex-col md:flex-row items-center w-full max-w-3xl mb-4 md:mb-0">
        {/* Botón para mostrar las categorías con icono */}
        <button
          onClick={toggleCategoryModal}
          className="flex items-center text-[#F24BA7] px-4 py-2 rounded-l transition duration-300 capitalize font-bold hover:text-white hover:bg-[#F24BA7]"
        >
          <FaBars className="mr-2 md:block" />{" "}
          {/* Solo se muestra en móviles */}
          <span className="hidden md:inline">Categorías</span>{" "}
          {/* Ocultar texto en móviles */}
        </button>

        {/* Buscador */}
        <div className="relative w-full mt-4 md:mt-0">
          {" "}
          {/* Margin top en móvil  */}
          <input
            ref={searchInputRef} // Asignar el ref al input
            type="text"
            value={searchQuery}
            onChange={handleSearchChange}
            placeholder="Buscar productos..."
            className="w-full py-2 px-4 rounded-md border border-gray-300 focus:outline-none focus:ring-2 focus:ring-pink-300 transition duration-300 capitalize"
          />
          <button
            onClick={() => searchInputRef.current?.focus()} // Enfocar el input usando el ref
            className="absolute right-0 top-0 mt-2 mr-2 p-2 rounded transition duration-300"
          >
            <FaSearch className="text-[#F24BA7]" />
          </button>
          {/* Resultados de la búsqueda */}
          {isSearchModalOpen && (
            <div className="absolute bg-white border border-gray-300 rounded mt-1 w-full max-h-60 overflow-y-auto shadow-lg z-10">
              {searchResults.length > 0 ? (
                searchResults.map((product) => (
                  <div
                    key={product.id_producto}
                    onClick={() => handleSearchResultClick(product.id_producto)}
                    className="cursor-pointer px-4 py-2 hover:bg-pink-100 capitalize text-[#F24BA7]" // Cambiar color aquí
                  >
                    {product.nombre} - ₲{product.precio.toLocaleString("es-PY")}
                  </div>
                ))
              ) : (
                <div className="px-4 py-2 text-[#F24BA7] capitalize">
                  No se encontraron resultados
                </div> // Cambiar color aquí también
              )}
            </div>
          )}
        </div>
      </div>
      {/* Mi Cuenta y Carrito */}
      <div className="flex items-center space-x-4">
        {/* Mi Cuenta */}
        <button
          className="flex items-center text-[#F24BA7] hover:text-pink-300 transition duration-300 capitalize font-bold"
          onClick={toggleLoginModal}
        >
          <FaUser className="mr-2" />
          <span className="hidden lg:inline">
            {userName ? userName : "Mi Cuenta"}
          </span>{" "}
          {/* Ocultar texto en móviles, mostrar en pantallas grandes */}
        </button>

        {/* Icono de WhatsApp con la imagen */}
        <div className="fixed bottom-4 right-4">
          <a
            href="https://wa.me/595983474763"
            target="_blank"
            rel="noopener noreferrer"
            className="p-2 rounded-full shadow-lg hover:opacity-75 transition duration-300"
          >
            <img src={whatsappIcon} alt="WhatsApp" className="h-12 w-12" />
          </a>
        </div>

        {/* Carrito con cantidad de productos */}
        <button
          className="flex items-center text-[#F24BA7] hover:text-pink-300 transition duration-300 capitalize font-bold"
          onClick={() => navigate("/carrito")}
        >
          <FaShoppingCart className="mr-2" />
          <span className="hidden lg:inline">
            Carrito ({cartItemCount})
          </span>{" "}
          {/* Ocultar texto en móviles, mostrar en pantallas grandes */}
        </button>
      </div>

      {/* Modal para categorías y subcategorías */}
      <Modal
        isOpen={isCategoryModalOpen}
        onRequestClose={closeCategoryModal}
        className={`absolute bg-white p-6 rounded-lg shadow-lg w-80 z-60 ${
          isCategoryModalOpen ? "modal-enter" : "modal-exit"
        }`} // Cambiado z-50 a z-60
        style={{
          content: {
            top: "70px", // Ajusta este valor para que se vea más por encima del encabezado
            left: "15%",
            width: "320px",
            height: "auto",
            borderRadius: "10px",
            boxShadow: "0 10px 30px rgba(0, 0, 0, 0.5)", // Efecto 3D
          },
          overlay: {
            backgroundColor: "rgba(0, 0, 0, 0.5)",
          },
        }}
        overlayClassName="fixed inset-0 bg-black bg-opacity-30 z-50" // Asegúrate de que este z-index sea menor que el del modal
      >
        <div className="flex justify-between items-center">
          <h2 className="text-[#F24BA7] font-bold text-lg">
            {selectedCategory ? "Subcategorías" : "Categorías"}
          </h2>
          <button
            onClick={closeCategoryModal}
            className="text-gray-500 hover:text-gray-700"
          >
            <FaTimes />
          </button>
        </div>
        <div className="mt-4">
          {selectedCategory ? (
            <div>
              <button
                className="flex items-center text-pink-500 mb-4"
                onClick={() => setSelectedCategory(null)}
              >
                <FaArrowLeft className="mr-2" /> Volver
              </button>
              <h3 className="text-[#F24BA7] font-bold mb-2">
                {capitalize(selectedCategory.descripcion)}
              </h3>
              {subCategories.length > 0 ? (
                <ul>
                  {subCategories.map((subcategory) => (
                    <li
                      key={subcategory.id_subcategoria}
                      className="text-[#F24BA7] text-sm cursor-pointer hover:bg-pink-100 transition duration-300 capitalize"
                      onClick={() => {
                        navigate(
                          `/subcategoria/${subcategory.id_subcategoria}`
                        );
                        setIsCategoryModalOpen(false);
                      }}
                    >
                      {capitalize(subcategory.descripcion)}
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="text-gray-500">
                  No hay subcategorías disponibles
                </p>
              )}
            </div>
          ) : (
            <ul>
              {categories.map((category) => (
                <li
                  key={category.id_categoria}
                  className="text-[#F24BA7] cursor-pointer transition duration-300 capitalize hover:bg-[#F24BA7] hover:text-white px-2 py-1"
                  onClick={() => handleCategoryClick(category)}
                >
                  {capitalize(category.descripcion)}
                </li>
              ))}
            </ul>
          )}
        </div>
      </Modal>

      {/* Modal para inicio de sesión y registro */}
      <Modal
        isOpen={isLoginModalOpen}
        onRequestClose={toggleLoginModal}
        className="absolute bg-white p-6 rounded-lg shadow-lg w-80 z-50"
        style={{
          content: {
            top: "40%",
            left: "50%",
            right: "auto",
            bottom: "auto",
            transform: "translate(-50%, -50%)",
            borderRadius: "15px",
            boxShadow: "0 4px 12px rgba(0, 0, 0, 0.1)",
          },
          overlay: {
            backgroundColor: "rgba(0, 0, 0, 0.5)",
          },
        }}
        overlayClassName="fixed inset-0 bg-black bg-opacity-30 z-40"
      >
        <div className="flex flex-col space-y-4">
          {userName ? (
            <>
              <button
                className="bg-pink-600 text-white py-2 rounded hover:bg-pink-700 transition duration-300"
                onClick={() => handleNavigateAndCloseModal("/mi-cuenta")}
              >
                Editar Perfil
              </button>
              <button
                className="bg-pink-600 text-white py-2 rounded hover:bg-pink-700 transition duration-300"
                onClick={handleLogout}
              >
                Cerrar Sesión
              </button>
            </>
          ) : (
            <>
              <button
                className="bg-pink-600 text-white py-2 rounded hover:bg-pink-700 transition duration-300"
                onClick={() => handleNavigateAndCloseModal("/login")}
              >
                Iniciar Sesión
              </button>
              <button
                className="bg-pink-600 text-white py-2 rounded hover:bg-pink-700 transition duration-300"
                onClick={() => handleNavigateAndCloseModal("/registro")}
              >
                Registro
              </button>
            </>
          )}
        </div>
      </Modal>
    </nav>
  );
};

export default Navbar;
