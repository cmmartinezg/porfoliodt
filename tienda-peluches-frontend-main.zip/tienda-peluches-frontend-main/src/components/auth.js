// src/auth.js
import { signInWithPopup } from "firebase/auth";
import { auth, googleProvider } from './firebaseConfig'; // Importamos la configuración de Firebase

const signInWithGoogle = async () => {
  try {
    const result = await signInWithPopup(auth, googleProvider);
    const user = result.user;
    console.log("Usuario autenticado con Google:", user);
    return user;
  } catch (error) {
    console.error("Error durante la autenticación con Google:", error);
  }
};

export { signInWithGoogle };
