import React, { useState, useEffect } from "react";
import authenticatedApi from "./api"; // Asegúrate de que la ruta de importación coincida con tu estructura de proyecto

interface Category {
  id_categoria?: number;
  descripcion: string;
  foto?: string;
}

const CategorySlider: React.FC = () => {
  const [categories, setCategories] = useState<Category[]>([]);

  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const response = await authenticatedApi.get("/categorias");
        setCategories(response.data);
      } catch (error) {
        console.error("Error al cargar categorías:", error);
        // Aquí podrías manejar un estado de error o mostrar un mensaje
      }
    };

    fetchCategories();
  }, []);

  return (
    <div className="flex justify-between space-x-4 p-4 bg-white w-full overflow-x-auto">
      {categories.map((category) => (
        <div // Cambiamos "button" por "div" para deshabilitar la interacción
          key={category.id_categoria}
          className="flex flex-col items-center flex-grow"
        >
          <img
            src={category.foto}
            alt={category.descripcion}
            className="w-24 h-24 object-cover rounded-full"
          />
          {/* Aplicar negrita, color, y capitalización al texto */}
          <span className="text-sm mt-2 text-center font-bold text-pink-600 capitalize">
            {category.descripcion}
          </span>
        </div>
      ))}
    </div>
  );
};

export default CategorySlider;
