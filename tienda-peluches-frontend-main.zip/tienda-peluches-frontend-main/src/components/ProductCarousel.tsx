import React, { useEffect, useState } from 'react';
import { Swiper, SwiperSlide } from 'swiper/react';
import 'swiper/css';
import 'swiper/css/navigation';
import 'swiper/css/pagination';
import 'swiper/css/autoplay'; // Para autoplay
import { Navigation, Pagination, Autoplay } from 'swiper/modules';
import ProductCard from './ProductCard';
import { authenticatedApi } from './api';

interface Product {
  id: number;
  name: string;
  price: number;
  image: string;
}

const ProductCarousel: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([]);

  // Obtener productos reales desde la API
  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await authenticatedApi.get('/productos');
        setProducts(
          response.data.map((product: any) => ({
            id: product.id_producto,
            name: product.nombre,
            price: parseFloat(product.precio),
            image:
              Array.isArray(product.foto) && product.foto.length > 0
                ? product.foto[0]
                : '/ruta_default_de_imagen.jpg',
          }))
        );
      } catch (error) {
        console.error('Error al cargar los productos:', error);
      }
    };

    fetchProducts();
  }, []);

  return (
    <div className="product-carousel">
      <Swiper
        spaceBetween={10}
        slidesPerView={3}
        navigation
        pagination={{ clickable: true }}
        autoplay={{ delay: 3000 }}
        modules={[Navigation, Pagination, Autoplay]}
        className="w-full"
      >
        {products.map((product) => (
          <SwiperSlide key={product.id}>
            <ProductCard product={product} />
          </SwiperSlide>
        ))}
      </Swiper>
    </div>
  );
};

export default ProductCarousel;
