import React, { useEffect, useState } from "react";
import { authenticatedApi } from "./api";
import { toast } from "react-toastify";

interface Sale {
  id: number;
  productName: string;
  quantity: number;
  totalPrice: number;
  saleDate: string;
}

const Sales: React.FC = () => {
  const [sales, setSales] = useState<Sale[]>([]);

  useEffect(() => {
    fetchSales();
  }, []);

  const fetchSales = async () => {
    try {
      const response = await authenticatedApi.get("/sales"); // Cambié a "/sales" para que coincida con lo que debería ser.
      setSales(response.data);
    } catch (error) {
      console.error("Error fetching sales:", error);
      toast.error("Error al cargar");
    }
  };

  const tableStyles: React.CSSProperties = {
    width: "100%",
    borderCollapse: "collapse",
    backgroundColor: "#FFFFFF",
  };

  const thStyles: React.CSSProperties = {
    backgroundColor: "#D96299",
    color: "white",
    padding: "10px",
    textAlign: "left" as "left", // Especificando el tipo correcto
  };

  const tdStyles: React.CSSProperties = {
    padding: "8px",
    color: "#333333",
    borderBottom: "1px solid #CCCCCC",
  };

  const evenRowStyles: React.CSSProperties = {
    backgroundColor: "#F2F2F2",
  };

  const oddRowStyles: React.CSSProperties = {
    backgroundColor: "#FFFFFF",
  };

  const headerStyles: React.CSSProperties = {
    fontSize: "23px",
    color: "black",
    fontWeight: "bold",
    marginBottom: "20px",
  };

  return (
    <div>
      <h1 style={headerStyles}>Gestión de Ventas</h1>
      <table style={tableStyles}>
        <thead>
          <tr>
            <th style={thStyles}>ID</th>
            <th style={thStyles}>Producto</th>
            <th style={thStyles}>Cantidad</th>
            <th style={thStyles}>Precio Total</th>
            <th style={thStyles}>Fecha de Venta</th>
          </tr>
        </thead>
        <tbody>
          {sales.map((sale, index) => (
            <tr
              key={sale.id}
              style={index % 2 === 0 ? evenRowStyles : oddRowStyles}
            >
              <td style={tdStyles}>{sale.id}</td>
              <td style={tdStyles}>{sale.productName}</td>
              <td style={tdStyles}>{sale.quantity}</td>
              <td style={tdStyles}>{sale.totalPrice}</td>
              <td style={tdStyles}>{sale.saleDate}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Sales;
