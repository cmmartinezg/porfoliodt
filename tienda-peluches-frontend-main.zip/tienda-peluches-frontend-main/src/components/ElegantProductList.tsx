import React, { useState, useEffect } from 'react';
import Modal from 'react-modal';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { authenticatedApi } from './api'; // Asegúrate de que la ruta sea correcta

interface Product {
  id: number;
  nombre: string;
  categoria: string;
  precio: number;
  stock: number;
  publicado?: boolean; // Campo adicional para indicar si ya fue publicado
  foto?: string;
  id_categoria?: string;
  id_subcategoria?: string;
}

interface Category {
  id_categoria: number;
  descripcion: string;
}

interface Subcategory {
  id_subcategoria: number;
  id_categoria: number;
  descripcion: string;
}

const ElegantProductList: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isPublishModalOpen, setIsPublishModalOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [newPhotos, setNewPhotos] = useState<File[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [subcategories, setSubcategories] = useState<Subcategory[]>([]);
  const [filteredSubcategories, setFilteredSubcategories] = useState<Subcategory[]>([]);

   // Cargar productos desde la API local /productoexterno
   useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await authenticatedApi.get('/productoexterno'); // Usa authenticatedApi para hacer la petición
        const data = response.data;
        const formattedProducts = data.content.map((item: never) => ({
          id: item[0],
          nombre: item[1],
          categoria: item[2],
          precio: item[3],
          stock: item[4],
          publicado: false, // Inicialmente se asume que no está publicado
          foto: '', // Inicialmente sin foto
        }));
        setProducts(formattedProducts);
      } catch (error) {
        console.error('Error al cargar los productos externos:', error);
        toast.error('Error al cargar los productos externos');
      } finally {
        setIsLoading(false);
      }
    };

    fetchProducts();
    fetchCategories();
    fetchSubcategories();
  }, []);

  // Obtener categorías
  const fetchCategories = async () => {
    try {
      const response = await authenticatedApi.get('/categorias');
      setCategories(response.data);
    } catch (error) {
      console.error('Error al cargar las categorías:', error);
      toast.error('Error al cargar las categorías');
    }
  };

  // Obtener subcategorías
  const fetchSubcategories = async () => {
    try {
      const response = await authenticatedApi.get('/subcategorias');
      setSubcategories(response.data);
    } catch (error) {
      console.error('Error al cargar las subcategorías:', error);
      toast.error('Error al cargar las subcategorías');
    }
  };

  // Abrir modal para publicar el producto
  const handlePublish = (product: Product) => {
    setSelectedProduct({
      ...product,
      id_categoria: '',
      id_subcategoria: '',
    });
    setFilteredSubcategories([]);
    setNewPhotos([]);
    setIsPublishModalOpen(true);
  };

  // Manejar cambios en el archivo (fotos)
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setNewPhotos(Array.from(e.target.files));
    }
  };

  // Manejar cambios en el campo de categoría para filtrar subcategorías
  const handleCategoryChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const categoryId = e.target.value;
    setSelectedProduct({
      ...selectedProduct!,
      id_categoria: categoryId,
      id_subcategoria: '',
    });
    const filteredSubs = subcategories.filter(
      (sub) => sub.id_categoria.toString() === categoryId
    );
    setFilteredSubcategories(filteredSubs);
  };

  // Enviar el formulario para publicar el producto en la base de datos local
const handleSubmit = async () => {
  if (selectedProduct) {
    if (!selectedProduct.id_categoria || !selectedProduct.id_subcategoria) {
      toast.error("Por favor selecciona una categoría y una subcategoría");
      return;
    }

    try {
      const formData = new FormData();
      formData.append('nombre', selectedProduct.nombre);
      formData.append('descripcion', selectedProduct.categoria);
      formData.append('precio', selectedProduct.precio.toString());
      formData.append('stock', selectedProduct.stock.toString());
      formData.append('id_categoria', selectedProduct.id_categoria || '');
      formData.append('id_subcategoria', selectedProduct.id_subcategoria || '');

      // Adjuntar las nuevas fotos si existen
      newPhotos.forEach((photo) => {
        formData.append('fotos', photo);
      });

      // Enviar la solicitud para publicar el producto a tu API local
      const response = await authenticatedApi.post('/productos', formData);

      if (response.status !== 200 && response.status !== 201) {
        throw new Error('Error al publicar el producto');
      }

      setProducts((prevProducts) =>
        prevProducts.map((p) =>
          p.id === selectedProduct.id ? { ...p, publicado: true } : p
        )
      );

      setIsPublishModalOpen(false);
      setSelectedProduct(null);
      setNewPhotos([]);
      toast.success('Producto publicado con éxito');
    } catch (error) {
      console.error('Error al publicar el producto:', error);
      toast.error('Error al publicar el producto');
    }
  }
};

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-6 text-center">Productos Disponibles</h1>
      {isLoading ? (
        <p className="text-center text-lg">Cargando productos...</p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {products.map((product) => (
            <div
              key={product.id}
              className="bg-white shadow-md rounded-lg p-4 hover:shadow-lg transition-shadow duration-300"
            >
              <h3 className="text-lg font-semibold mb-2">{product.nombre}</h3>
              <p className="text-gray-500 mb-1">
                <strong>Categoría:</strong> {product.categoria}
              </p>
              <p className="text-gray-500 mb-1">
                <strong>Precio:</strong> ₲{product.precio.toLocaleString('es-PY')}
              </p>
              <p className="text-gray-500 mb-1">
                <strong>Stock:</strong> {product.stock}
              </p>
              {product.foto && (
                <img
                  src={product.foto}
                  alt={product.nombre}
                  className="w-full h-32 object-cover rounded mt-2"
                />
              )}
              <button
                onClick={() => handlePublish(product)}
                className={`mt-4 px-4 py-2 rounded transition-colors duration-300 ${
                  product.stock === 0
                    ? 'bg-red-500 cursor-not-allowed'
                    : product.publicado
                    ? 'bg-gray-500 cursor-not-allowed'
                    : 'bg-green-500 hover:bg-green-600 text-white'
                }`}
                disabled={product.stock === 0 || product.publicado}
              >
                {product.publicado ? 'Ya Publicado' : 'Publicar'}
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Modal para publicar producto */}
      {selectedProduct && (
        <Modal
          isOpen={isPublishModalOpen}
          onRequestClose={() => setIsPublishModalOpen(false)}
          contentLabel="Publicar Producto"
          className="bg-white p-6 rounded-lg max-w-md mx-auto mt-20"
          overlayClassName="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center"
        >
          <h2 className="text-xl font-semibold mb-4">Publicar Producto</h2>
          <div className="mb-3">
            <label className="block text-gray-700 mb-2">Nombre:</label>
            <input
              type="text"
              value={selectedProduct.nombre}
              onChange={(e) =>
                setSelectedProduct({ ...selectedProduct!, nombre: e.target.value })
              }
              className="w-full border rounded p-2"
            />
          </div>
          <div className="mb-3">
            <label className="block text-gray-700 mb-2">Categoría:</label>
            <select
              value={selectedProduct.id_categoria || ''}
              onChange={handleCategoryChange}
              className="w-full border rounded p-2"
            >
              <option value="">Seleccionar Categoría</option>
              {categories.map((category) => (
                <option key={category.id_categoria} value={category.id_categoria}>
                  {category.descripcion}
                </option>
              ))}
            </select>
          </div>
          {filteredSubcategories.length > 0 && (
            <div className="mb-3">
              <label className="block text-gray-700 mb-2">Subcategoría:</label>
              <select
                value={selectedProduct.id_subcategoria || ''}
                onChange={(e) =>
                  setSelectedProduct({ ...selectedProduct!, id_subcategoria: e.target.value })
                }
                className="w-full border rounded p-2"
              >
                <option value="">Seleccionar Subcategoría</option>
                {filteredSubcategories.map((sub) => (
                  <option key={sub.id_subcategoria} value={sub.id_subcategoria}>
                    {sub.descripcion}
                  </option>
                ))}
              </select>
            </div>
          )}
          <div className="mb-3">
            <label className="block text-gray-700 mb-2">Precio:</label>
            <input
              type="number"
              value={selectedProduct.precio}
              onChange={(e) =>
                setSelectedProduct({ ...selectedProduct!, precio: +e.target.value })
              }
              className="w-full border rounded p-2"
            />
          </div>
          <div className="mb-3">
            <label className="block text-gray-700 mb-2">Stock:</label>
            <input
              type="number"
              value={selectedProduct.stock}
              onChange={(e) =>
                setSelectedProduct({ ...selectedProduct!, stock: +e.target.value })
              }
              className="w-full border rounded p-2"
            />
          </div>
          <div className="mb-3">
            <label className="block text-gray-700 mb-2">Fotos:</label>
            <input
              type="file"
              multiple
              accept="image/*"
              onChange={handleFileChange}
              className="border rounded p-2"
            />
          </div>
          <button
            onClick={handleSubmit}
            className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded"
          >
            Publicar Producto
          </button>
        </Modal>
      )}

      <ToastContainer />
    </div>
  );
};

export default ElegantProductList;
