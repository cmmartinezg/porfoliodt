import React, { useState } from 'react';
import { Link, Route, Routes } from 'react-router-dom';
import ProductUploadForm from './ProductUploadForm';
import ElegantProductList from './ElegantProductList';
import Orders from './Orders';
import Sales from './Sales';
import Settings from './Settings';
import AdManagement from './PublicidadForm'; // Componente para la gestión de publicidad
import CategoryManager from './CategoryManager';

const AdminPanel: React.FC = () => {
  const [activeTab, setActiveTab] = useState('orders');
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  // Nueva paleta de colores en base a la tienda
  const colors = {
    primary: '#F2C2DC', // Color de acento
    secondary: '#D96299', // Color del sidebar
    background: '#F2D5D5', // Color del fondo general
    textLight: '#F2C2DC', // Texto claro
    textDark: '#2c3e50', // Texto oscuro
  };

  const styles = {
    container: {
      display: 'flex' as const,
      height: '100vh',
      backgroundColor: colors.background,
      padding: '40px 0', // Márgenes arriba y abajo
    },
    sidebar: {
      backgroundColor: colors.secondary,
      color: colors.textLight,
      width: '250px',
      padding: '20px',
      boxShadow: '2px 0 5px rgba(0, 0, 0, 0.1)',
      margin: '0 15px', // Margen derecho e izquierdo para mejor separación
      borderRadius: '10px', // Bordes redondeados para un look más suave
    },
    sidebarTitle: {
      fontSize: '1.6em',
      marginBottom: '30px',
      color: colors.primary,
      fontWeight: 'bold' as const,
    },
    sidebarList: {
      listStyle: 'none' as const,
      padding: 0,
    },
    sidebarItem: {
      margin: '15px 0',
    },
    sidebarLink: {
      textDecoration: 'none',
      color: colors.textLight,
      fontSize: '1.1em',
      display: 'flex' as const,
      alignItems: 'center' as const,
      padding: '10px 15px',
      borderRadius: '8px',
      transition: 'background-color 0.3s ease',
    },
    activeLink: {
      backgroundColor: colors.primary,
      color: colors.textDark,
    },
    sidebarLinkHover: {
      backgroundColor: '#D96299',
    },
    mainContent: {
      flexGrow: 1,
      padding: '30px',
      backgroundColor: colors.background,
      overflowY: 'auto' as const,
      borderRadius: '10px', // Bordes redondeados para el área de contenido
    },
    panelSection: {
      backgroundColor: 'white',
      padding: '25px',
      borderRadius: '10px',
      boxShadow: '0 4px 10px rgba(0, 0, 0, 0.05)',
      marginBottom: '25px',
    },
  };

  const toggleDropdown = () => {
    setIsDropdownOpen((prev) => !prev);
  };

  const handleTabClick = (tab: string) => {
    setActiveTab(tab);
    // Cerrar el desplegable si se selecciona una pestaña diferente a 'products'
    if (tab !== 'products' && tab !== 'upload' && tab !== 'categories') {
      setIsDropdownOpen(false);
    } else {
      setIsDropdownOpen(true); // Mantener abierto si se selecciona 'products', 'upload' o 'categories'
    }
  };

  return (
    <div style={styles.container}>
      <aside style={styles.sidebar}>
        <h2 style={styles.sidebarTitle}>Panel Administrador</h2>
        <ul style={styles.sidebarList}>
          <li style={styles.sidebarItem}>
            <Link
              to="/admin/orders"
              onClick={() => handleTabClick('orders')}
              style={{
                ...styles.sidebarLink,
                ...(activeTab === 'orders' ? styles.activeLink : {}),
              }}
            >
              📦 Pedidos o Delivery
            </Link>
          </li>
          <li style={styles.sidebarItem}>
            <Link
              to="/admin/sales"
              onClick={() => handleTabClick('sales')}
              style={{
                ...styles.sidebarLink,
                ...(activeTab === 'sales' ? styles.activeLink : {}),
              }}
            >
              💰 Ventas
            </Link>
          </li>

          <li style={styles.sidebarItem}>
            <Link
              to="#"
              onClick={toggleDropdown} // Cambiar a '#' para evitar la navegación
              style={{
                ...styles.sidebarLink,
                ...(activeTab === 'products' || activeTab === 'upload' ? styles.activeLink : {}),
              }}
            >
              🛍 Productos
            </Link>
            {isDropdownOpen && ( // Mostrar opciones solo si el desplegable está abierto
              <ul style={{ listStyle: 'none', paddingLeft: '20px' }}>
                <li style={styles.sidebarItem}>
                  <Link
                    to="/admin/products"
                    onClick={() => {
                      handleTabClick('products');
                      setIsDropdownOpen(true); // Mantener el desplegable abierto al seleccionar
                    }}
                    style={{
                      ...styles.sidebarLink,
                      ...(activeTab === 'products' ? styles.activeLink : {}),
                    }}
                  >
                    📦 Lista de Productos
                  </Link>
                </li>
                <li style={styles.sidebarItem}>
                  <Link
                    to="/admin/upload"
                    onClick={() => {
                      handleTabClick('upload');
                      setIsDropdownOpen(true); // Mantener el desplegable abierto al seleccionar
                    }}
                    style={{
                      ...styles.sidebarLink,
                      ...(activeTab === 'upload' ? styles.activeLink : {}),
                    }}
                  >
                    📤 Subir Producto
                  </Link>
                </li>
                <li style={styles.sidebarItem}>
                  <Link
                    to="/admin/categories"
                    onClick={() => {
                      handleTabClick('categories');
                      setIsDropdownOpen(true); // Mantener el desplegable abierto al seleccionar
                    }}
                    style={{
                      ...styles.sidebarLink,
                      ...(activeTab === 'categories' ? styles.activeLink : {}),
                    }}
                  >
                    🗂 Categorías
                  </Link>
                </li>
              </ul>
            )}
          </li>

          <li style={styles.sidebarItem}>
            <Link
              to="/admin/ads"
              onClick={() => handleTabClick('ads')}
              style={{
                ...styles.sidebarLink,
                ...(activeTab === 'ads' ? styles.activeLink : {}),
              }}
            >
              📢 Publicidad
            </Link>
          </li>
          <li style={styles.sidebarItem}>
            <Link
              to="/admin/settings"
              onClick={() => handleTabClick('settings')}
              style={{
                ...styles.sidebarLink,
                ...(activeTab === 'settings' ? styles.activeLink : {}),
              }}
            >
              ⚙️ Configuración
            </Link>
          </li>
        </ul>
      </aside>

      <main style={styles.mainContent}>
        <Routes>
          <Route path="/orders" element={<Orders />} />
          <Route path="/sales" element={<Sales />} />
          <Route path="/products" element={<ElegantProductList />} />
          <Route path="/upload" element={<ProductUploadForm />} />
          <Route path="/ads" element={<AdManagement />} /> {/* Nueva ruta para Publicidad */}
          <Route path="/categories" element={<CategoryManager />} />
          <Route path="/settings" element={<Settings />} />
        </Routes>
      </main>
    </div>
  );
};

export default AdminPanel;
