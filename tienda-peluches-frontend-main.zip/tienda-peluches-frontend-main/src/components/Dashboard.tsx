// src/components/Dashboard.tsx
import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Sidebar from "./Sidebar";
import Orders from "./Orders";
import Sales from "./Sales";
import Products from "./Products";

const Dashboard: React.FC = () => {
  return (
    <Router>
      <div className="dashboard">
        <Sidebar />
        <div className="content">
          <Routes>
            <Route path="/orders" element={<Orders />} />
            <Route path="/sales" element={<Sales />} />
            <Route path="/products" element={<Products />} />
            {/* Agrega más rutas aquí para otras secciones */}
          </Routes>
        </div>
      </div>
    </Router>
  );
};

export default Dashboard;
