// import React, { useEffect, useState } from "react";
// import { Link } from "react-router-dom";
// import api from "./api"; // Asegúrate de importar tu instancia de API
// import { FaChevronLeft, FaChevronRight } from "react-icons/fa"; // Importar los iconos

// // Página Principal
// const HeroBanner: React.FC = () => {
//   const [bannerImages, setBannerImages] = useState<string[]>([]);
//   const [currentIndex, setCurrentIndex] = useState(0);

//   // Efecto para obtener las imágenes de la API
//   useEffect(() => {
//     const fetchBannerImages = async () => {
//       try {
//         const response = await api.get("/publicidad"); // Usando tu API

//         // Verificar si la respuesta es válida
//         if (response.status !== 200) {
//           throw new Error(
//             `Network response was not ok: ${response.statusText}`
//           );
//         }

//         // Obtener las imágenes
//         const data = response.data;

//         if (data && data.length > 0) {
//           const images = data.map((item: any) => item.imagen);
//           setBannerImages(images);
//         } else {
//           console.warn(
//             "No hay imágenes disponibles en la respuesta de la API."
//           );
//         }
//       } catch (error) {
//         console.error("Error al obtener las imágenes del banner:", error);
//       }
//     };

//     fetchBannerImages();
//   }, []);

//   // Efecto para cambiar de imagen cada 3 segundos
//   useEffect(() => {
//     const interval = setInterval(() => {
//       setCurrentIndex((prevIndex) => (prevIndex + 1) % bannerImages.length);
//     }, 3000);

//     return () => clearInterval(interval);
//   }, [bannerImages]);

//   // Función para cambiar la imagen manualmente
//   const handleNext = () => {
//     setCurrentIndex((prevIndex) => (prevIndex + 1) % bannerImages.length);
//   };

//   const handlePrev = () => {
//     setCurrentIndex(
//       (prevIndex) => (prevIndex - 1 + bannerImages.length) % bannerImages.length
//     );
//   };

//   return (
//     <div
//       style={{
//         position: "relative",
//         height: "26rem",
//         display: "flex",
//         alignItems: "center",
//         justifyContent: "center",
//         overflow: "hidden",
//         textAlign: "center",
//         borderRadius: "15px",
//         marginBottom: "2rem",
//         boxShadow: "0 4px 15px rgba(0, 0, 0, 0.2)", // Sombra para darle profundidad
//       }}
//     >
//       {/* Contenedor del carrusel */}
//       {bannerImages.length > 0 && (
//         <>
//           <img
//             src={bannerImages[currentIndex]}
//             alt="Banner"
//             style={{
//               position: "absolute",
//               inset: 0,
//               width: "100%",
//               height: "100%",
//               objectFit: "cover",
//               transition: "opacity 1s ease-in-out",
//               opacity: 1,
//               zIndex: 0,
//             }}
//             className={`animate-fade ${currentIndex}`}
//           />
//           <button
//             onClick={handlePrev}
//             style={{
//               position: "absolute",
//               left: "20px",
//               zIndex: 1,
//               backgroundColor: "transparent", // Fondo transparente
//               color: "#F24BA7", // Color de la flecha
//               border: "none",
//               padding: "15px",
//               borderRadius: "50%",
//               cursor: "pointer",
//               display: "flex",
//               justifyContent: "center",
//               alignItems: "center",
//               transition: "color 0.3s ease, transform 0.3s ease",
//             }}
//             onMouseEnter={(e) => (e.currentTarget.style.color = "#D96299")} // Cambiar color al hover
//             onMouseLeave={(e) => (e.currentTarget.style.color = "#F24BA7")}
//             onMouseDown={(e) =>
//               (e.currentTarget.style.transform = "scale(0.95)")
//             }
//             onMouseUp={(e) => (e.currentTarget.style.transform = "scale(1)")}
//           >
//             <FaChevronLeft size={24} />{" "}
//             {/* Icono de la flecha hacia la izquierda */}
//           </button>
//           <button
//             onClick={handleNext}
//             style={{
//               position: "absolute",
//               right: "20px",
//               zIndex: 1,
//               backgroundColor: "transparent", // Fondo transparente
//               color: "#F24BA7", // Color de la flecha
//               border: "none",
//               padding: "15px",
//               borderRadius: "50%",
//               cursor: "pointer",
//               display: "flex",
//               justifyContent: "center",
//               alignItems: "center",
//               transition: "color 0.3s ease, transform 0.3s ease",
//             }}
//             onMouseEnter={(e) => (e.currentTarget.style.color = "#D96299")} // Cambiar color al hover
//             onMouseLeave={(e) => (e.currentTarget.style.color = "#F24BA7")}
//             onMouseDown={(e) =>
//               (e.currentTarget.style.transform = "scale(0.95)")
//             }
//             onMouseUp={(e) => (e.currentTarget.style.transform = "scale(1)")}
//           >
//             <FaChevronRight size={24} />{" "}
//             {/* Icono de la flecha hacia la derecha */}
//           </button>

//           {/* Indicadores de imagen */}
//           <div
//             style={{
//               position: "absolute",
//               bottom: "15px",
//               left: "50%",
//               transform: "translateX(-50%)",
//               display: "flex",
//               gap: "5px",
//             }}
//           >
//             {bannerImages.map((_, index) => (
//               <span
//                 key={index}
//                 onClick={() => setCurrentIndex(index)} // Cambiar imagen al hacer clic
//                 style={{
//                   height: "10px",
//                   width: "10px",
//                   borderRadius: "50%",
//                   backgroundColor:
//                     currentIndex === index
//                       ? "#FF6BB0"
//                       : "rgba(255, 255, 255, 0.5)",
//                   cursor: "pointer",
//                   transition: "background-color 0.3s ease",
//                 }}
//               />
//             ))}
//           </div>
//         </>
//       )}

//       {/* Capa de superposición */}
//       <div
//         style={{
//           position: "absolute",
//           inset: 0,
//           backgroundColor: "rgba(0, 0, 0, 0.6)",
//         }}
//       ></div>

//       {/* Contenido del Banner */}
//       <div
//         style={{
//           position: "relative",
//           zIndex: 10,
//           color: "white",
//           textAlign: "center",
//         }}
//       >
//         <h1
//           style={{
//             fontSize: "4rem",
//             fontWeight: "bold",
//             animation: "fadeInUp 2s ease-in-out",
//             textShadow: "2px 2px 10px rgba(0, 0, 0, 0.5)",
//           }}
//         >
//           ¡Bienvenidos a <span style={{ color: "#FF6BB0" }}>Peluche Store</span>
//           !
//         </h1>
//         <p
//           style={{
//             marginTop: "1rem",
//             fontSize: "1.5rem",
//             fontWeight: "300",
//             animation: "fadeInUp 3s ease-in-out",
//             textShadow: "1px 1px 6px rgba(0, 0, 0, 0.3)",
//           }}
//         >
//           Encuentra los peluches más adorables y únicos para todos.
//         </p>

//         <Link to="/productos">
//           <button
//             style={{
//               marginTop: "2rem",
//               padding: "0.75rem 2rem",
//               backgroundColor: "#FF6BB0",
//               color: "#FFF",
//               fontSize: "1.2rem",
//               fontWeight: "600",
//               borderRadius: "50px",
//               boxShadow: "0 6px 15px rgba(0, 0, 0, 0.15)",
//               transition: "transform 0.3s ease, background-color 0.3s ease",
//             }}
//             className="hover:bg-pink-600 transform hover:scale-105"
//           >
//             Ver Productos
//           </button>
//         </Link>
//       </div>

//       {/* Estilos y animaciones integradas */}
//       <style>
//         {`
//           @keyframes fadeInUp {
//             0% {
//               opacity: 0;
//               transform: translateY(30px);
//             }
//             100% {
//               opacity: 1;
//               transform: translateY(0);
//             }
//           }

//           .hover:scale-105:hover {
//             transform: scale(1.05);
//           }

//           .animate-fade {
//             opacity: 0; /* Inicialmente transparente */
//             animation: fade 1s forwards; /* Animación de desvanecimiento */
//           }

//           @keyframes fade {
//             from {
//               opacity: 0;
//             }
//             to {
//               opacity: 1;
//             }
//           }

//           .hover:bg-pink-600:hover {
//             background-color: #e048c3;
//           }
//         `}
//       </style>
//     </div>
//   );
// };

// export default HeroBanner;
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import api from "./api"; // Asegúrate de importar tu instancia de API
import { FaChevronLeft, FaChevronRight } from "react-icons/fa"; // Importar los iconos

// Página Principal
const HeroBanner: React.FC = () => {
  const [bannerImages, setBannerImages] = useState<string[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);

  // Efecto para obtener las imágenes de la API
  useEffect(() => {
    const fetchBannerImages = async () => {
      try {
        const response = await api.get("/publicidad"); // Usando tu API

        // Verificar si la respuesta es válida
        if (response.status !== 200) {
          throw new Error(
            `Network response was not ok: ${response.statusText}`
          );
        }

        // Obtener las imágenes
        const data = response.data;

        if (data && data.length > 0) {
          const images = data.map((item: any) => item.imagen);
          setBannerImages(images);
        } else {
          console.warn(
            "No hay imágenes disponibles en la respuesta de la API."
          );
        }
      } catch (error) {
        console.error("Error al obtener las imágenes del banner:", error);
      }
    };

    fetchBannerImages();
  }, []);

  // Efecto para cambiar de imagen cada 3 segundos
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex((prevIndex) => (prevIndex + 1) % bannerImages.length);
    }, 3000);

    return () => clearInterval(interval);
  }, [bannerImages]);

  // Función para cambiar la imagen manualmente
  const handleNext = () => {
    setCurrentIndex((prevIndex) => (prevIndex + 1) % bannerImages.length);
  };

  const handlePrev = () => {
    setCurrentIndex(
      (prevIndex) => (prevIndex - 1 + bannerImages.length) % bannerImages.length
    );
  };

  return (
    <div
      style={{
        position: "relative",
        height: "26rem",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        overflow: "auto",
        textAlign: "center",
        borderRadius: "15px",
        marginBottom: "2rem",
        boxShadow: "0 4px 15px rgba(0, 0, 0, 0.2)", // Sombra para darle profundidad
      }}
    >
      {/* Contenedor del carrusel */}
      {bannerImages.length > 0 && (
        <>
          <img
            src={bannerImages[currentIndex]}
            alt="Banner"
            style={{
              position: "absolute",
              inset: 0,
              width: "100%",
              height: "100%",
              objectFit: "cover",
              transition: "opacity 1s ease-in-out",
              opacity: 1,
              zIndex: 0,
            }}
            className={`animate-fade ${currentIndex}`}
          />
          <button
            onClick={handlePrev}
            style={{
              position: "absolute",
              left: "20px",
              zIndex: 1,
              backgroundColor: "transparent", // Fondo transparente
              color: "#F24BA7", // Color de la flecha
              border: "none",
              padding: "15px",
              borderRadius: "50%",
              cursor: "pointer",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              transition: "color 0.3s ease, transform 0.3s ease",
            }}
            onMouseEnter={(e) => (e.currentTarget.style.color = "#D96299")} // Cambiar color al hover
            onMouseLeave={(e) => (e.currentTarget.style.color = "#F24BA7")}
            onMouseDown={(e) =>
              (e.currentTarget.style.transform = "scale(0.95)")
            }
            onMouseUp={(e) => (e.currentTarget.style.transform = "scale(1)")}
          >
            <FaChevronLeft size={24} />{" "}
            {/* Icono de la flecha hacia la izquierda */}
          </button>
          <button
            onClick={handleNext}
            style={{
              position: "absolute",
              right: "20px",
              zIndex: 1,
              backgroundColor: "transparent", // Fondo transparente
              color: "#F24BA7", // Color de la flecha
              border: "none",
              padding: "15px",
              borderRadius: "50%",
              cursor: "pointer",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              transition: "color 0.3s ease, transform 0.3s ease",
            }}
            onMouseEnter={(e) => (e.currentTarget.style.color = "#D96299")} // Cambiar color al hover
            onMouseLeave={(e) => (e.currentTarget.style.color = "#F24BA7")}
            onMouseDown={(e) =>
              (e.currentTarget.style.transform = "scale(0.95)")
            }
            onMouseUp={(e) => (e.currentTarget.style.transform = "scale(1)")}
          >
            <FaChevronRight size={24} />{" "}
            {/* Icono de la flecha hacia la derecha */}
          </button>

          {/* Indicadores de imagen */}
          <div
            style={{
              position: "absolute",
              bottom: "15px",
              left: "50%",
              transform: "translateX(-50%)",
              display: "flex",
              gap: "5px",
            }}
          >
            {bannerImages.map((_, index) => (
              <span
                key={index}
                onClick={() => setCurrentIndex(index)} // Cambiar imagen al hacer clic
                style={{
                  height: "10px",
                  width: "10px",
                  borderRadius: "50%",
                  backgroundColor:
                    currentIndex === index
                      ? "#FF6BB0"
                      : "rgba(255, 255, 255, 0.5)",
                  cursor: "pointer",
                  transition: "background-color 0.3s ease",
                }}
              />
            ))}
          </div>
        </>
      )}

      {/* Capa de superposición */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          backgroundColor: "rgba(0, 0, 0, 0.6)",
        }}
      ></div>

      {/* Contenido del Banner */}
      <div
        style={{
          position: "relative",
          zIndex: 10,
          color: "white",
          textAlign: "center",
              paddingTop: "5rem", // Añadir padding superior

        }}
      >
        <h1
          style={{
            fontSize: "4rem",
            fontWeight: "bold",
            animation: "fadeInUp 2s ease-in-out",
            textShadow: "2px 2px 10px rgba(0, 0, 0, 0.5)",
          }}
        >
          ¡Bienvenidos a <span style={{ color: "#FF6BB0" }}>Peluche Store</span>
          !
        </h1>
        <p
          style={{
            marginTop: "1rem",
            fontSize: "1.5rem",
            fontWeight: "300",
            animation: "fadeInUp 3s ease-in-out",
            textShadow: "1px 1px 6px rgba(0, 0, 0, 0.3)",
          }}
        >
          Encuentra los peluches más adorables y únicos para todos.
        </p>

        <Link to="/productos">
          <button
            style={{
              marginTop: "2rem",
              padding: "0.75rem 2rem",
              backgroundColor: "#FF6BB0",
              color: "#FFF",
              fontSize: "1.2rem",
              fontWeight: "600",
              borderRadius: "50px",
              boxShadow: "0 6px 15px rgba(0, 0, 0, 0.15)",
              transition: "transform 0.3s ease, background-color 0.3s ease",
            }}
            className="hover:bg-pink-600 transform hover:scale-105"
          >
            Ver Productos
          </button>
        </Link>
      </div>

      {/* Estilos y animaciones integradas */}
      <style>
        {`
          @keyframes fadeInUp {
            0% {
              opacity: 0;
              transform: translateY(30px);
            }
            100% {
              opacity: 1;
              transform: translateY(0);
            }
          }

          .hover:scale-105:hover {
            transform: scale(1.05);
          }

          .animate-fade {
            opacity: 0; /* Inicialmente transparente */
            animation: fade 1s forwards; /* Animación de desvanecimiento */
          }

          @keyframes fade {
            from {
              opacity: 0;
            }
            to {
              opacity: 1;
            }
          }

          .hover:bg-pink-600:hover {
            background-color: #e048c3;
          }
        `}
      </style>
    </div>
  );
};

export default HeroBanner;
