// src/pages/MiCuenta.tsx
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import authenticatedApi from '../components/api'; // Asegúrate de que el token JWT esté incluido en las peticiones

interface User {
  nombre: string;
  email: string;
  foto_perfil: string;
}

interface Purchase {
  id_compra: number;
  nombre_producto: string;
  cantidad: number;
  precio_total: number;
  fecha_compra: string;
}

const MiCuenta: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [purchases, setPurchases] = useState<Purchase[]>([]);
  const navigate = useNavigate();

  useEffect(() => {
    // Verificamos si hay un token JWT en localStorage
    const tokenJWT = localStorage.getItem('tokenJWT');
    
    if (!tokenJWT) {
      // Si no está logueado, redirigir al login
      navigate('/login');
    } else {
      // Si está logueado, obtenemos los datos del usuario y sus compras
      fetchUserData();
      fetchUserPurchases();
    }
  }, [navigate]);

  const fetchUserData = async () => {
    try {
      const response = await authenticatedApi.get('/usuarios/me'); // Endpoint para obtener datos del usuario logueado
      setUser(response.data);
    } catch (error) {
      console.error('Error al obtener los datos del usuario:', error);
    }
  };

  const fetchUserPurchases = async () => {
    try {
      const response = await authenticatedApi.get('/compras/mis-compras'); // Endpoint para obtener compras del usuario
      setPurchases(response.data);
    } catch (error) {
      console.error('Error al obtener las compras del usuario:', error);
    }
  };

  if (!user) {
    return <p>Cargando...</p>; // Mostrar un mensaje de carga mientras se obtienen los datos
  }

  return (
    <div className="max-w-4xl mx-auto p-4">
      <h1 className="text-3xl font-bold mb-4">Mi Cuenta</h1>

      {/* Información del Perfil */}
      <div className="bg-white p-6 shadow-md rounded-lg mb-6">
        <div className="flex items-center space-x-6">
          <img
            src={user.foto_perfil || '/ruta_default_de_imagen.jpg'}
            alt="Foto de perfil"
            className="w-24 h-24 rounded-full object-cover"
          />
          <div>
            <h2 className="text-2xl font-bold">{user.nombre}</h2>
            <p className="text-gray-600">{user.email}</p>
          </div>
        </div>
      </div>

      {/* Artículos Comprados */}
      <h2 className="text-2xl font-bold mb-4">Mis Compras</h2>
      <div className="bg-white p-6 shadow-md rounded-lg">
        {purchases.length > 0 ? (
          <ul>
            {purchases.map((purchase) => (
              <li key={purchase.id_compra} className="mb-4 border-b pb-4">
                <p className="text-xl font-semibold">{purchase.nombre_producto}</p>
                <p className="text-gray-600">Cantidad: {purchase.cantidad}</p>
                <p className="text-gray-600">Total: Gs. {purchase.precio_total.toLocaleString('es-PY')}</p>
                <p className="text-gray-500">Fecha: {new Date(purchase.fecha_compra).toLocaleDateString()}</p>
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-gray-500">Aún no has realizado ninguna compra.</p>
        )}
      </div>
    </div>
  );
};

export default MiCuenta;
