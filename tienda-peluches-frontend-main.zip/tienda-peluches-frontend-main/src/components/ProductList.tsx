import React, { useState, useEffect } from "react";
import { authenticatedApi } from "./api"; // Ruta correcta para tu archivo de API
import { Link } from "react-router-dom"; // Importamos Link para redirigir a ProductDetail
import tiktokicon from "../assets/tiktok.png"; // Importa la imagen de TikTok
import igicon from "../assets/ig.png";
import fbicon from "../assets/fb.png";
import whatsappIcon from "../assets/pngwing.com.png"; // Importa la imagen de WhatsApp

interface Product {
  id_categoria: number;
  id_producto: number;
  nombre: string;
  precio: number;
  foto: string[]; // Actualizado a un arreglo de strings
}

interface Category {
  id_categoria: number;
  descripcion: string;
}

const ProductList: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<number | null>(null);
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [minPrice, setMinPrice] = useState<string>("");
  const [maxPrice, setMaxPrice] = useState<string>("");

  useEffect(() => {
    fetchProducts();
    fetchCategories();
  }, []);

  const fetchProducts = async () => {
    try {
      const response = await authenticatedApi.get("/productos");
      const productsWithFotos = response.data.map((product: any) => ({
        ...product,
        foto: Array.isArray(product.foto) ? product.foto : [product.foto],
      }));
      setProducts(productsWithFotos);
    } catch (error) {
      console.error("Error al cargar los productos:", error);
    }
  };

  const fetchCategories = async () => {
    try {
      const response = await authenticatedApi.get("/categorias");
      setCategories(response.data);
    } catch (error) {
      console.error("Error al cargar las categorías:", error);
    }
  };

  const handleCategoryChange = (categoryId: number | null) => {
    setSelectedCategory(categoryId);
  };

  const filteredProducts = products
    .filter((product) =>
      selectedCategory ? product.id_categoria === selectedCategory : true
    )
    .filter((product) =>
      searchTerm
        ? product.nombre.toLowerCase().includes(searchTerm.toLowerCase())
        : true
    )
    .filter((product) =>
      minPrice ? product.precio >= parseFloat(minPrice) : true
    )
    .filter((product) =>
      maxPrice ? product.precio <= parseFloat(maxPrice) : true
    );

  return (
    <div className="flex flex-col min-h-screen">
      <div className="container mx-auto px-4 py-6 flex-grow mt-8">
        <h2 className="text-4xl font-extrabold text-center mb-8 text-pink-600 tracking-wide">
          Todos los Productos
        </h2>

        {/* Filtro de categorías */}
        <div className="mb-6 text-center">
          <label className="font-semibold text-xl mr-4 text-gray-700">
            Filtrar por Categoría:
          </label>
          <select
            onChange={(e) =>
              handleCategoryChange(Number(e.target.value) || null)
            }
            className="py-2 px-6 bg-white border border-pink-300 rounded-lg shadow-md text-lg transition duration-300 ease-in-out transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-pink-400"
            style={{ backgroundColor: "#F2D5D5" }} // Color de fondo
          >
            <option value="" className="bg-pink-200">
              Todas las Categorías
            </option>
            {categories.map((category) => (
              <option
                key={category.id_categoria}
                value={category.id_categoria}
                className="font-semibold text-xl mr-4 text-gray-700" // Color de fondo para las opciones
              >
                {category.descripcion}
              </option>
            ))}
          </select>
        </div>

        {/* Filtros adicionales de búsqueda y precio */}
        <div className="flex justify-center space-x-4 mb-8">
          <input
            type="text"
            placeholder="Buscar producto..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="py-2 px-4 border border-gray-300 rounded-lg shadow-md text-lg focus:outline-none focus:ring-2 focus:ring-pink-400"
          />
          <input
            type="number"
            placeholder="Precio Mín."
            value={minPrice}
            onChange={(e) => setMinPrice(e.target.value)}
            className="py-2 px-4 border border-gray-300 rounded-lg shadow-md text-lg focus:outline-none focus:ring-2 focus:ring-pink-400"
          />
          <input
            type="number"
            placeholder="Precio Máx."
            value={maxPrice}
            onChange={(e) => setMaxPrice(e.target.value)}
            className="py-2 px-4 border border-gray-300 rounded-lg shadow-md text-lg focus:outline-none focus:ring-2 focus:ring-pink-400"
          />
        </div>

        {/* Lista de productos */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProducts.map((product) => (
            <div
              key={product.id_producto}
              className="border rounded-xl p-6 shadow-lg hover:shadow-xl transition-shadow duration-300 transform hover:-translate-y-1 hover:scale-105 bg-white animate-fadeIn"
            >
              <img
                src={
                  product.foto && product.foto.length > 0
                    ? product.foto[0]
                    : "/ruta_default_de_imagen.jpg"
                }
                alt={product.nombre}
                className="w-full h-56 object-cover rounded-md mb-4 transition-transform duration-300 transform hover:scale-110"
              />
              <h3 className="text-2xl font-bold mb-2 text-pink-600">
                {product.nombre}
              </h3>
              <p className="text-lg text-gray-800">
                ₲{product.precio.toLocaleString("es-PY")}
              </p>
              <Link to={`/producto/${product.id_producto}`}>
                <button className="mt-4 py-2 px-4 bg-pink-500 text-white rounded-full shadow-md hover:bg-pink-600 transition duration-300 ease-in-out transform hover:scale-105">
                  Ver
                </button>
              </Link>
            </div>
          ))}
        </div>

        {filteredProducts.length === 0 && (
          <div className="text-center mt-12">
            <p className="text-xl font-semibold text-gray-700">
              No hay productos disponibles en esta categoría
            </p>
          </div>
        )}

        {/* Animación para los productos */}
        <style>
          {`
            .animate-fadeIn {
              opacity: 0;
              animation: fadeIn 0.6s ease-in-out forwards;
            }

            @keyframes fadeIn {
              0% {
                opacity: 0;
                transform: translateY(10px);
              }
              100% {
                opacity: 1;
                transform: translateY(0);
              }
            }
          `}
        </style>
      </div>

      {/* Pie de página */}
      <footer
        style={{
          backgroundColor: "#F2C2DC",
        }}
        className="text-center py-5 w-full mt-auto" // Cambiado a py-5 para menos espacio
      >
        <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Columna Nueva Izquierda - La Empresa */}
          <div className="flex flex-col items-center text-center">
            <h3
              className="text-2xl font-bold mb-2 tracking-wide"
              style={{ color: "#F24BA7" }}
            >
              La Empresa
            </h3>
            <Link
              to="/about-us"
              className="font-bold mt-2"
              style={{ color: "#F24BA7" }}
            >
              Sobre Nosotros
            </Link>
            <Link
              to="/about-us"
              className="font-bold mt-2"
              style={{ color: "#F24BA7" }}
            >
              Misión
            </Link>
            <Link
              to="/about-us"
              className="font-bold mt-2"
              style={{ color: "#F24BA7" }}
            >
              Visión
            </Link>
          </div>

          {/* Columna Izquierda - ¿Dónde Estamos? */}
          <div className="flex flex-col items-center text-center">
            <h3
              className="text-2xl font-bold mb-2 tracking-wide"
              style={{ color: "#F24BA7" }}
            >
              ¿Dónde Estamos?
            </h3>
            <p className="mt-2 font-bold" style={{ color: "#F24BA7" }}>
              Eusebio Lillo Robles Esquina, Asunción 001409
            </p>
            <div className="mt-2">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3607.3354307710406!2d-57.5567853!3d-25.292932!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x945da89294287697%3A0x164ec5c39508981e!2sBoopillows%20Py!5e0!3m2!1ses-419!2spy!4v1728595022183!5m2!1ses-419!2spy"
                width="300"
                height="200"
                style={{ border: "0" }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              ></iframe>
            </div>
          </div>

          {/* Columna Derecha - Atención al Cliente */}
          <div className="flex flex-col items-center text-center">
            <h3
              className="text-2xl font-bold mb-4 tracking-wide"
              style={{ color: "#F24BA7" }}
            >
              Atención al Cliente
            </h3>
            <ul className="mt-3 space-y-3">
            <li>
                <a
                  href="/politica-privacidad"
                  className="font-bold hover:text-pink-300 transition duration-300"
                  style={{ color: "#F24BA7" }}
                >
                  Políticas de Privacidad
                </a>
              </li>

              <li>
                <Link
                  to="/return-policy"
                  className="font-bold hover:text-pink-300 transition duration-300"
                  style={{ color: "#F24BA7" }}
                >
                  Políticas de Cambios y Devoluciones
                </Link>
              </li>
              <li>
                <a
                  href="https://beacons.ai/boopillows"
                  className="font-bold hover:text-pink-300 transition duration-300"
                  style={{ color: "#F24BA7" }}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Contáctanos
                </a>
              </li>
            </ul>

            {/* Iconos de Redes Sociales */}
            <div className="flex space-x-5 mt-10 justify-center">
              <a
                href="https://wa.me/595983474763"
                target="_blank"
                rel="noopener noreferrer"
              >
                <img src={whatsappIcon} alt="WhatsApp" className="h-8 w-8" />
              </a>
              <a
                href="https://www.instagram.com/boopillows/"
                target="_blank"
                rel="noopener noreferrer"
              >
                <img src={igicon} alt="Instagram" className="h-8 w-8" />
              </a>
              <a
                href="https://www.facebook.com/boopillows"
                target="_blank"
                rel="noopener noreferrer"
              >
                <img src={fbicon} alt="Facebook" className="h-8 w-8" />
              </a>
              <a
                href="https://www.tiktok.com/@boopillows"
                target="_blank"
                rel="noopener noreferrer"
              >
                <img src={tiktokicon} alt="TikTok" className="h-8 w-8" />
              </a>
            </div>
          </div>
        </div>

        <div className="mt-4 text-sm text-gray-200 font-bold">
          <p style={{ color: "#F24BA7" }}>
            &copy; {new Date().getFullYear()} Boo Pillows. Todos los derechos
            reservados.
          </p>
        </div>
      </footer>
    </div>
  );
};

export default ProductList;
