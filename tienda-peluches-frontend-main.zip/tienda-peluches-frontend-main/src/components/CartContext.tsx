import React, { createContext, useContext, useState, ReactNode } from 'react';

// Definir la interfaz para los elementos del carrito
interface CartItem {
  id: number;
  name: string;
  price: number;
  quantity: number;
  image: string;
  color: string; // Agregado
  size: string;  // Agregado
}

// Definir la interfaz para el contexto del carrito
interface CartContextType {
  cartItems: CartItem[];
  cartItemCount: number; // Añadir esta propiedad para contar los elementos del carrito
  addToCart: (item: CartItem) => void;
  removeFromCart: (id: number) => void;
  updateCartQuantity: (id: number, quantity: number) => void;
}

// Crear el contexto del carrito
const CartContext = createContext<CartContextType | undefined>(undefined);

// Definir las propiedades que el CartProvider acepta, incluyendo `children`
interface CartProviderProps {
  children: ReactNode;
}

// Crear el proveedor del contexto del carrito
export const CartProvider: React.FC<CartProviderProps> = ({ children }) => {
  const [cartItems, setCartItems] = useState<CartItem[]>([]);

  // Calcular la cantidad total de elementos en el carrito
  const cartItemCount = cartItems.reduce((count, item) => count + item.quantity, 0);

  // Función para agregar un producto al carrito
  const addToCart = (item: CartItem) => {
    setCartItems((prevItems) => {
      const existingItem = prevItems.find((cartItem) => cartItem.id === item.id);
      if (existingItem) {
        return prevItems.map((cartItem) =>
          cartItem.id === item.id
            ? { ...cartItem, quantity: cartItem.quantity + item.quantity }
            : cartItem
        );
      }
      return [...prevItems, item];
    });
  };

  // Función para eliminar un producto del carrito
  const removeFromCart = (id: number) => {
    setCartItems((prevItems) => prevItems.filter((item) => item.id !== id));
  };

  // Función para actualizar la cantidad de un producto en el carrito
  const updateCartQuantity = (id: number, quantity: number) => {
    setCartItems((prevItems) =>
      prevItems.map((item) =>
        item.id === id ? { ...item, quantity: quantity } : item
      )
    );
  };

  return (
    <CartContext.Provider
      value={{ cartItems, cartItemCount, addToCart, removeFromCart, updateCartQuantity }}
    >
      {children}
    </CartContext.Provider>
  );
};

// Hook personalizado para usar el contexto del carrito
export const useCart = () => {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart debe ser usado dentro de un CartProvider');
  }
  return context;
};
