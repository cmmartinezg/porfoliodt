import logo from "../assets/boopillowslogo.png"; // Asegúrate de que la imagen de tu logo esté en la carpeta correcta

const PoliticaPrivacidad = () => {
  return (
    <div className="flex justify-center my-12">
            <div className="p-8 mx-20 bg-white shadow-lg rounded-lg border border-[#D96299]">

      {/* Logo agregado */}
      <div className="text-center mb-4">
          <img src={logo} alt="Boo Pillows Logo" className="mx-auto w-32" /> {/* Ajusta el tamaño según sea necesario */}
        </div>
        <h1 className="text-4xl font-bold text-center mb-4 text-[#D96299]">
        Política de Privacidad y Cookies <br />
        <br />
        Nuestra política de privacidad
      </h1>
      <p style={{ marginTop: "10px", marginBottom: "10px" }}>
        <br />
        Nosotros somos Boopillows y nuestro compromiso es ofrecerte los
        productos y servicios que mejor se acomoden a tus necesidades. Por ello,
        en este acto, autorizas expresamente a Boopillows de conformidad a
        tratar tus datos personales que nos proporcionas al comprar nuestros
        productos por cualquiera de nuestros canales de comunicación o venta,
        tanto presenciales como remotos, para las finalidades que se indican más
        abajo.
      </p>

      <h2
        style={{ fontWeight: "bold", marginTop: "20px", marginBottom: "20px" }}
      >
        ¿Qué son los datos personales?
      </h2>
      <p style={{ marginTop: "10px", marginBottom: "10px" }}>
        Se entiende por datos personales, tu nombre y apellido, RUC, domicilio,
        teléfono, correo electrónico, datos de geolocalización, uso y visita del
        sitio web, historial de navegación, hábitos de compra, entre otros.
      </p>

      <h2
        style={{ fontWeight: "bold", marginTop: "20px", marginBottom: "20px" }}
      >
        Autorización de contacto
      </h2>
      <p style={{ marginTop: "10px", marginBottom: "10px" }}>
        Asimismo, nos autorizas a contactarte a través de medios digitales tales
        como email, Facebook, mensajes de texto (SMS), WhatsApp u otras
        plataformas similares, al número de celular que nos entregues, con el
        objeto de hacerte llegar información relacionada con las finalidades que
        se indican a continuación.
      </p>

      <h2
        style={{ fontWeight: "bold", marginTop: "20px", marginBottom: "20px" }}
      >
        Finalidades del tratamiento de tus datos personales
      </h2>
      <p style={{ marginTop: "10px", marginBottom: "10px" }}>
        Tus datos podrán ser tratados por nosotros o a través de nuestros
        proveedores, exclusivamente para las siguientes finalidades:
      </p>
      <ul style={{ marginTop: "10px", marginBottom: "10px" }}>
        <li>
          1. Gestionar tu registro como usuario, gestionar la compra de
          productos o servicios, atender tus consultas, así como para, en caso
          de que lo desees, enviarte nuestras comunicaciones personalizadas.
        </li>
        <li>
          2. Preparar, implementar, promocionar y ofrecerte nuevos productos y
          servicios, o bien, nuevos atributos, modalidades o características a
          los productos y servicios que ya están a tu disposición.
        </li>
        <li>
          3. Completar automáticamente los documentos asociados a las
          transacciones que realices en función de los productos adquiridos o
          que en el futuro adquieras, utilices o contrates con Boopillows.
        </li>
        <li>
          4. Acceder a procesar y tratar tu información, a fin de ajustar la
          oferta de productos y servicios a tu perfil de cliente, o bien,
          efectuar análisis, reportes y evaluaciones a su respecto; y por último
          desarrollar acciones comerciales o servicios post venta, de carácter
          general o dirigidas personalmente a ti, tendientes a mejorar tu
          experiencia como cliente.
        </li>
      </ul>

      <h2
        style={{ fontWeight: "bold", marginTop: "20px", marginBottom: "20px" }}
      >
        Legitimación para el uso de tus datos
      </h2>
      <p style={{ marginTop: "10px", marginBottom: "10px" }}>
        Estamos legitimados para tratar tus datos por diferentes motivos. El
        principal, es que necesitamos tratarlos para ejecutar el contrato que
        aceptas con nosotros al registrarte y al hacer una compra o disfrutar de
        alguno de nuestros servicios o funcionalidades.
      </p>

      <h2
        style={{ fontWeight: "bold", marginTop: "20px", marginBottom: "20px" }}
      >
        Compartición de datos con terceros
      </h2>
      <p style={{ marginTop: "10px", marginBottom: "10px" }}>
        Podríamos compartir tus datos con prestadores de servicios que nos
        ayudan o dan soporte en nuestras operaciones.
      </p>

      <h2
        style={{ fontWeight: "bold", marginTop: "20px", marginBottom: "20px" }}
      >
        Derechos del usuario
      </h2>
      <p style={{ marginTop: "10px", marginBottom: "10px" }}>
        En todo momento podrás revocar tu autorización y dispondrás siempre de
        los derechos de aclaración, rectificación, cancelación y oposición y
        todos los demás derechos que confiere la Ley.
      </p>

      <h2
        style={{ fontWeight: "bold", marginTop: "20px", marginBottom: "20px" }}
      >
        Responsable del tratamiento de datos
      </h2>
      <p style={{ marginTop: "10px", marginBottom: "10px" }}>
        Los responsables del tratamiento de tus datos somos:
        <br />
        Boopillows
        <br />
        Dirección: Casa Matriz, Eusebio Lillo Robles y Dr. Caballero, Asunción.
        <br />
        Correo electrónico: boopillows@gmail.com
      </p>

      <h2
        style={{ fontWeight: "bold", marginTop: "20px", marginBottom: "20px" }}
      >
        ¿Con qué finalidad tratamos tus datos personales?
      </h2>
      <p style={{ marginTop: "10px", marginBottom: "10px" }}>
        Dependiendo de cómo interactúes con nuestra Plataforma, trataremos tus
        datos personales para las siguientes finalidades:
      </p>
      <ul style={{ marginTop: "10px", marginBottom: "10px" }}>
        <li>1. Para gestionar tu registro como usuario de la Plataforma.</li>
        <li>
          2. Para el desarrollo, cumplimiento y ejecución del contrato de
          compraventa o de servicios que hayas contratado con nosotros en la
          Plataforma.
        </li>
        <li>
          3. Para fines de marketing, tratar tus datos para enviarte información
          personalizada sobre nuestros productos o servicios.
        </li>
      </ul>
      <p style={{ marginTop: "10px", marginBottom: "10px" }}>
        -En la medida en que te suscribas a nuestra Newsletter, se tratarán tus
        datos personales para gestionar tu suscripción, incluyendo el envío de
        información personalizada acerca de nuestros productos o servicios a
        través de diversos medios (como el correo electrónico o SMS).
        <br />
        -Por tanto, ten en cuenta que este tratamiento de datos conlleva el
        análisis de tu perfil de usuario o cliente para determinar cuáles son
        tus preferencias y por tanto cuáles pueden ser los productos y servicios
        que más encajan con tu estilo a la hora de enviarte información. -Llevar
        a cabo acciones promocionales.
        <br />
        -Difundir en la Plataforma o a través de nuestros canales en las redes
        sociales fotografías o imágenes que hayas compartido de forma pública,
        siempre que des tu consentimiento para ello.
        <br />
      </p>

      <p style={{ marginTop: "10px", marginBottom: "10px" }}>
        -En la medida en que te suscribas a nuestra Newsletter, se tratarán tus
        datos personales para gestionar tu suscripción, incluyendo el envío de
        información personalizada acerca de nuestros productos o servicios a
        través de diversos medios (como el correo electrónico o SMS).
        <br />
        -Por tanto, ten en cuenta que este tratamiento de datos conlleva el
        análisis de tu perfil de usuario o cliente para determinar cuáles son
        tus preferencias y por tanto cuáles pueden ser los productos y servicios
        que más encajan con tu estilo a la hora de enviarte información. -Llevar
        a cabo acciones promocionales.
        <br />
        -Difundir en la Plataforma o a través de nuestros canales en las redes
        sociales fotografías o imágenes que hayas compartido de forma pública,
        siempre que des tu consentimiento para ello.
        <br />
      </p>
      <h4>
        <b><br />
          4- Análisis de usabilidad y de calidad para la mejora de nuestros
          servicios
          <br /></b>
      </h4>
      <p>
        Si accedes a nuestra Plataforma, Boopillows te informa que tratará tus
        datos de navegación para fines analíticos y estadísticos, es decir, para
        entender la forma en la que los usuarios interactúan con nuestra
        Plataforma y así ser capaces de introducir mejoras en la misma.
      </p>
      <p>
        Así mismo, en ocasiones realizaremos acciones y encuestas de calidad
        destinadas a conocer el grado de satisfacción de nuestros clientes y
        usuarios y detectar aquellas áreas en las que podemos mejorar.<br />
      </p>
      <h4>
        <b><br />Base legal para el tratamiento de tus datos</b>
      </h4>
      <p>
        La base legal que nos permite tratar tus datos personales también
        depende de la finalidad para la que los tratemos, según lo explicado a
        continuación:
        </p><br />
      <h5>
        <b>1. Gestionar tu registro como usuario de la Plataforma</b>
      </h5>
      <p><br />
        Boopillows trata tus datos porque es necesario para la ejecución de los
        términos que regulan el uso de la Plataforma. En otras palabras, para
        que puedas registrarte como usuario en la Plataforma, necesitamos tratar
        tus datos personales, ya que de lo contrario no podría gestionar tu
        registro.
      </p>
      <h5>
        <b><br />
          2. Desarrollo, cumplimiento y ejecución del contrato de compraventa o
          de servicios
        </b>
      </h5>
      <p><br />
        El tratamiento de tus datos es necesario para la ejecución del contrato
        de compraventa o de prestación de servicios que nos vincule contigo.
      </p>
      <p>
        Es posible que algunos tratamientos de datos asociados al proceso de
        compra se activen únicamente porque tú lo solicites o nos autorices,
        como es el caso del almacenamiento de los datos de pago (tarjeta) para
        futuras compras o para informarte de la disponibilidad de nuestros
        productos. En estos casos, la base sobre la que tratamos tus datos es tu
        propio consentimiento.
      </p>
      <p>
        Consideramos que tenemos un interés legítimo para realizar las
        comprobaciones necesarias para detectar y prevenir posibles fraudes
        cuando realizas una compra. Entendemos que el tratamiento de estos datos
        resulta positivo para todas las partes que intervienen cuando se produce
        el pago de una compra y en particular para ti ya que nos permite poner
        medidas para protegerte contra intentos de fraude realizados por
        terceros.
      </p><br />
      <h5>
        <b>3. Atención al Cliente</b>
      </h5>
      <p><br />
        Consideramos que tenemos un interés legítimo para atender las
        solicitudes o consultas que nos plantees a través de los diversos medios
        de contacto existentes. Entendemos que el tratamiento de estos datos
        resulta también beneficioso para ti en tanto que nos permite poder
        atenderte adecuadamente y resolver las consultas planteadas.
      </p>
      <p>
        Cuando nos contactes, en particular, para la gestión de incidencias
        relacionadas con tu pedido o el producto/servicio adquirido a través de
        la Plataforma, el tratamiento es necesario para la ejecución del
        contrato de compraventa.
      </p>
      <p>
        Cuando tu consulta esté relacionada con el ejercicio de los derechos
        sobre los que te informamos más abajo, o con reclamaciones relacionadas
        con nuestros productos o servicios, lo que nos legitima para tratar tus
        datos es el cumplimiento de obligaciones legales por nuestra parte.
      </p><br />
      <h5>
        <b>4. Marketing</b>
      </h5>
      <p><br />
        La base legítima que ostenta Boopillows para tratar tus datos con
        finalidades de marketing es el consentimiento que le prestas, por
        ejemplo, cuando aceptas recibir información personalizada a través de
        diversos medios, cuando autorizas el envío de notificaciones push en tu
        dispositivo móvil o para publicar tus fotografías en la Plataforma o en
        nuestros canales de redes sociales.
      </p>
      <p>
        Para mostrarte información personalizada, Boopillows considera que tiene
        un interés legítimo para realizar un perfilado con la información que
        tiene sobre ti (como la navegación que realizas, preferencias o
        histórico de compras) y los datos personales que le has facilitado como
        rango de edad o idioma, ya que Boopillows entiende que el tratamiento de
        estos datos también resulta beneficioso para ti porque te permite
        mejorar tu experiencia como usuario y acceder a información de acuerdo
        con tus preferencias.
      </p>
      <h5>
        <b><br />5. Análisis de usabilidad y de calidad</b>
      </h5>
      <p><br />
        Consideramos que Boopillows tiene un interés legítimo para analizar la
        usabilidad de la Plataforma y el grado de satisfacción del usuario ya
        que entendemos que el tratamiento de estos datos también resulta
        beneficioso para ti porque la finalidad es mejorar la experiencia del
        usuario y ofrecer un servicio de mayor calidad.
      </p>
      <p>
        <strong><br />¿Durante cuánto tiempo conservamos tus datos?</strong>
      </p>
      <p><br />
        El plazo de conservación de tus datos dependerá de las finalidades para
        las que los tratemos, según lo explicado a continuación:
      </p>

      <p>
        <strong><br />1. Gestionar tu registro como usuario de la Plataforma</strong>
      </p>
      <p><br />
        Boopillows tratará tus datos durante el tiempo en que mantengas la
        condición de usuario registrado (es decir, hasta que decidas darte de
        baja).
      </p>

      <p>
        <strong><br />
          2. Desarrollo, cumplimiento y ejecución del contrato de compraventa o
          servicios
        </strong>
      </p>
      <p><br />
        Trataremos tus datos durante el tiempo necesario para gestionar la
        compra de los productos o servicios que hayas adquirido, incluyendo
        posibles devoluciones, quejas o reclamaciones asociadas a la compra del
        producto o servicio en particular. En algunas ocasiones, únicamente
        trataremos los datos hasta el momento en que tú decidas, como es el caso
        de los datos de pago (tarjeta) que nos has solicitado almacenar para
        posibles compras futuras.
      </p>

      <p>
        <strong><br />3. Atención al Cliente</strong>
      </p>
      <p><br />
        Trataremos tus datos durante el tiempo que sea necesario para atender tu
        solicitud o petición.
      </p>

      <p>
        <strong><br />4. Marketing</strong>
      </p>
      <p><br />
        Boopillows tratará tus datos hasta que te des de baja o canceles tu
        suscripción a la newsletter.
      </p>

      <p>
        <strong><br />5. Análisis de usabilidad y de calidad</strong>
      </p>
      <p><br />
        Se tratarán tus datos puntualmente durante el tiempo en el que
        procedamos a realizar una acción o encuesta de calidad concreta o hasta
        que anonimicemos tus datos de navegación.
      </p>

      <p>
        Independientemente de que tratemos tus datos durante el tiempo
        estrictamente necesario para cumplir con la finalidad correspondiente,
        los conservaremos posteriormente debidamente guardados y protegidos
        durante el tiempo en que pudieran surgir responsabilidades derivadas del
        tratamiento, en cumplimiento con la normativa vigente en cada momento.
        Una vez prescriban las posibles acciones en cada caso, procederemos a la
        supresión de los datos personales.
      </p>

      <p>
        <strong><br />¿Compartiremos tus datos con terceros?</strong>
      </p>
      <p><br />
        Para cumplir las finalidades indicadas en la presente Política de
        Privacidad y Cookies, es necesario que Boopillows de acceso a tus datos
        personales a terceras partes que nos presten apoyo en los servicios que
        te ofrecemos, a saber:
      </p>
      <ul>
        <li>Entidades financieras</li>
        <li>Entidades de detección y prevención de fraude</li>
        <li>Proveedores de servicios tecnológicos</li>
        <li>
          Proveedores y colaboradores de servicios de logística, transporte y
          entrega
        </li>
        <li>Proveedores de servicios relacionados con atención al cliente</li>
        <li>
          Proveedores y colaboradores de servicios relacionados con marketing y
          publicidad
        </li>
      </ul>

      <p>
        <strong><br />Ejercicio de tus derechos</strong>
      </p>
      <p><br />
        Nos comprometemos a respetar la confidencialidad de tus datos personales
        y a garantizarte el ejercicio de tus derechos. Los Corresponsables hemos
        acordado que puedes ejercitarlos sin coste alguno escribiéndonos un
        correo electrónico a{" "}
        <a href="mailto:boopillows@gmail.com">boopillows@gmail.com</a>,
        simplemente indicándonos el motivo de tu solicitud y el derecho que
        quieres ejercitar, o a través del 0983474763 o al 0984707037. En caso de
        que lo consideremos necesario para poder identificarte, podremos
        solicitarte copia de un documento acreditativo de tu identidad.
      </p>

      <p>
        En particular, independientemente de la finalidad o la base legal en
        virtud de la que tratemos tus datos, tienes derecho a:
      </p>
      <ul>
        <li>Pedirnos acceso a los datos de los que disponemos de ti.</li>
        <li>Pedirnos que rectifiquemos los datos de los que ya disponemos.</li>
        <li>
          Pedirnos que suprimamos tus datos en la medida en que ya no sean
          necesarios para la finalidad para la que los necesitemos.
        </li>
        <li>Pedirnos que limitemos el tratamiento de tus datos.</li>
      </ul>

      <p>
        Si nos has proporcionado tu consentimiento para el tratamiento de tus
        datos para cualquier finalidad, también tienes derecho a retirarlo en
        cualquier momento.
      </p>

      <p>
        <strong><br />¿Qué pasa si nos facilitas datos de terceros?</strong>
        <br />
        <br />
      </p>
      <p>
        Ofrecemos funcionalidades o servicios que requieren que tratemos los
        datos personales de un tercero que tú nos facilites, como para el caso
        de la activación y envío de la Tarjeta Regalo. En tales casos,
        garantizas haberles informado acerca de las finalidades y la forma en la
        que necesitamos tratar sus datos personales.
      </p>

      <p>
        <br />
        <strong>Cambios a la política de privacidad y cookies</strong>
        <br />
        <br />
      </p>
      <p>
        Es posible que modifiquemos la información contenida en esta Política de
        Privacidad y Cookies cuando lo estimemos conveniente. En caso de que lo
        hagamos, te lo notificaremos por distintas vías a través de la
        Plataforma. Te sugerimos que revises esta Política de Privacidad y
        Cookies de vez en cuando.
      </p>

      <p>
        <br />
        <strong>Información sobre cookies</strong>
        <br />
      </p>
      <p>
        Utilizamos cookies y dispositivos similares para facilitar tu navegación
        en la Plataforma. Por favor, lee nuestra Información sobre Cookies para
        conocer con mayor detalle las cookies y dispositivos similares que
        usamos, su finalidad y otra información de interés.
      </p>
      <p>
        <br />
        <strong>¿Para qué se utilizan las Cookies en este sitio web?</strong>
        <br />
        <br />
      </p>
      <p>
        Las Cookies son una parte esencial de cómo funciona nuestro sitio web.
        El objetivo principal de nuestras Cookies es mejorar su experiencia en
        la navegación. Por ejemplo, son utilizadas para recordar sus
        preferencias durante la navegación y en futuras visitas.
      </p>

      <p>
        La información recogida en las Cookies nos permite, además, mejorar la
        web mediante estimaciones sobre números y patrones de uso, la adaptación
        del sitio web a los intereses individuales de los usuarios, la
        aceleración de las búsquedas, etc.
      </p>

      <p>
        En ocasiones, si hemos obtenido su previo consentimiento informado,
        podremos utilizar Cookies, tags u otros dispositivos similares para
        obtener información que nos permita mostrarle desde nuestro sitio web,
        los de terceros, o cualquier otro medio o publicidad basada en el
        análisis de sus hábitos de navegación.
      </p>

      <p>
        <br />
        <strong>¿Para qué NO se utilizan las Cookies en esta web?</strong>
        <br />
        <br />
      </p>
      <p>
        Nosotros no almacenamos información sensible de identificación personal
        como su dirección, su contraseña, los datos de su tarjeta de crédito o
        débito, etc., en las Cookies que utilizamos.
      </p>

      <p>
        Las entregas y pickup se realizan según horario seleccionado.
        <br />
        <br />
      </p>

      <p>
        <br />
        <strong>Contacto</strong>
      </p>
      <p>
        Si tienes preguntas sobre esta política, contáctanos al número
        0983474763 o al correo{" "}
        <a href="mailto:boopillows@gmail.com">boopillows@gmail.com</a>.<br />
        <br />
      </p>
    </div>
    </div>
  );
};

export default PoliticaPrivacidad;
