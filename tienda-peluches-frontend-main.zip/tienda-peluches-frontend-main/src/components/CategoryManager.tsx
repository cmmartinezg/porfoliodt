import React, { useState, useEffect } from "react";
import authenticatedApi from "./api";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import Modal from "react-modal";

Modal.setAppElement("#root");

interface Category {
  id_categoria?: number;
  descripcion: string;
  foto?: string;
}

interface Subcategory {
  id_subcategoria?: number;
  id_categoria: number;
  descripcion: string;
}

interface Brand {
  id_marca?: number;
  nombre: string;
}

const CategoryManager: React.FC = () => {
  const [categories, setCategories] = useState<Category[]>([]);
  const [subcategories, setSubcategories] = useState<Subcategory[]>([]);
  const [brands, setBrands] = useState<Brand[]>([]);
  const [newCategory, setNewCategory] = useState<Category>({
    descripcion: "",
    foto: "",
  });
  const [newSubcategory, setNewSubcategory] = useState<Subcategory>({
    id_categoria: 0,
    descripcion: "",
  });
  const [newBrand, setNewBrand] = useState<Brand>({
    nombre: "",
  });
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [modalIsOpen, setModalIsOpen] = useState(false);
  const [currentImage, setCurrentImage] = useState("");

  useEffect(() => {
    fetchCategories();
    fetchSubcategories();
    fetchBrands();
  }, []);

  const fetchCategories = async () => {
    try {
      const response = await authenticatedApi.get("/categorias");
      setCategories(response.data);
    } catch (error) {
      console.error("Error al cargar categorías:", error);
      toast.error("Error al cargar categorías");
    }
  };

  const fetchSubcategories = async () => {
    try {
      const response = await authenticatedApi.get("/subcategorias");
      setSubcategories(response.data);
    } catch (error) {
      console.error("Error al cargar subcategorías:", error);
      toast.error("Error al cargar subcategorías");
    }
  };

  const fetchBrands = async () => {
    try {
      const response = await authenticatedApi.get("/productos/marcas");
      setBrands(response.data);
    } catch (error) {
      console.error("Error al cargar marcas:", error);
      toast.error("Error al cargar marcas");
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setNewCategory({ ...newCategory, [name]: value });
  };

  const handleSubcategoryInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setNewSubcategory({ ...newSubcategory, [name]: value });
  };

  const handleBrandInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setNewBrand({ ...newBrand, [name]: value });
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedFile(file);
    }
  };

  const handleCreateCategory = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!selectedFile) {
      toast.error("Por favor, selecciona una imagen para la categoría");
      return;
    }

    const formData = new FormData();
    formData.append("descripcion", newCategory.descripcion);
    formData.append("foto", selectedFile);

    try {
      const response = await authenticatedApi.post("/categorias", formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });

      setCategories([...categories, response.data]);
      setNewCategory({ descripcion: "", foto: "" });
      setSelectedFile(null);
      toast.success("Categoría creada exitosamente");
    } catch (error: any) {
      console.error("Error al crear categoría:", error);
      toast.error("Error al crear categoría");
    }
  };

  const handleCreateSubcategory = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!newSubcategory.id_categoria) {
      toast.error("Por favor, selecciona una categoría para la subcategoría");
      return;
    }

    try {
      const response = await authenticatedApi.post(
        "/subcategorias",
        newSubcategory
      );
      setSubcategories([... subcategories, response.data]);
      setNewSubcategory({ id_categoria: 0, descripcion: "" });
      toast.success("Subcategoría creada exitosamente");
    } catch (error: any) {
      console.error("Error al crear subcategoría:", error);
      toast.error("Error al crear subcategoría");
    }
  };

  const handleCreateBrand = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      const response = await authenticatedApi.post("/productos/marcas", newBrand);
      setBrands([...brands, response.data]);
      setNewBrand({ nombre: "" });
      toast.success("Marca creada exitosamente");
    } catch (error: any) {
      console.error("Error al crear marca:", error);
      toast.error("Error al crear marca");
    }
  };

  const handleDeleteCategory = async (id: number) => {
    try {
      await authenticatedApi.delete(`/categorias/${id}`);
      setCategories(categories.filter((cat) => cat.id_categoria !== id));
      toast.success("Categoría eliminada exitosamente");
    } catch (error) {
      console.error("Error al eliminar categoría:", error);
      toast.error("Error al eliminar categoría");
    }
  };

  const handleDeleteSubcategory = async (id: number) => {
    try {
      await authenticatedApi.delete(`/subcategorias/${id}`);
      setSubcategories(
        subcategories.filter((sub) => sub.id_subcategoria !== id)
      );
      toast.success("Subcategoría eliminada exitosamente");
    } catch (error) {
      console.error("Error al eliminar subcategoría:", error);
      toast.error("Error al eliminar subcategoría");
    }
  };

  const handleDeleteBrand = async (id: number) => {
    try {
      await authenticatedApi.delete(`/productos/marcas/${id}`);
      setBrands(brands.filter((brand) => brand.id_marca !== id));
      toast.success("Marca eliminada exitosamente");
    } catch (error) {
      console.error("Error al eliminar marca:", error);
      toast.error("Error al eliminar marca");
    }
  };

  const openModal = (image: string) => {
    setCurrentImage(image);
    setModalIsOpen(true);
  };

  const closeModal = () => {
    setModalIsOpen(false);
  };

  return (
    <div className="min-h-screen bg-[#F2C2DC] p-8 mt-5">
      <div className="max-w-4xl mx-auto bg-white p-6 shadow-md rounded-md">
        {/* Formulario para Categoría */}
        <h2 className="text-2xl font-bold mb-4 text-gray">Crear Categoría</h2>
        <form onSubmit={handleCreateCategory} className="mb-8">
          <div className="mb-4">
            <label
              htmlFor="descripcion"
              className="block text-sm font-medium text-[#F24BA7]"
            >
              Descripción de la Categoría
            </label>
            <input
              type="text"
              name="descripcion"
              id="descripcion"
              value={newCategory.descripcion}
              onChange={handleInputChange}
              className="mt-1 p-2 border border-[#D96299] rounded w-full"
              required
            />
          </div>
          <div className="mb-4">
            <label
              htmlFor="foto"
              className="block text-sm font-medium text-[#F24BA7]"
            >
              Foto
            </label>
            <input
              type="file"
              name="foto"
              id="foto"
              onChange={handleFileChange}
              className="mt-1 p-2 border border-[#D96299] rounded w-full"
            />
          </div>
          <button
            type="submit"
            className="w-full p-2 bg-[#F24BA7] text-white rounded hover:bg-[#D96299]"
          >
            Crear Categoría
          </button>
        </form>

        {/* Formulario para Subcategoría */}
        <h2 className="text-2xl font-bold mb-4 text-gray">
          Crear Subcategoría
        </h2>
        <form onSubmit={handleCreateSubcategory} className="mb-8">
          <div className="mb-4">
            <label
              htmlFor="id_categoria"
              className="block text-sm font-medium text-[#F24BA7]"
            >
              Categoría
            </label>
            <select
              name="id_categoria"
              id="id_categoria"
              value={newSubcategory.id_categoria}
              onChange={handleSubcategoryInputChange}
              className="mt-1 p-2 border border-[#D96299] rounded w-full"
              required
            >
              <option value="">Seleccion ar Categoría</option>
              {categories.map((category) => (
                <option
                  key={category.id_categoria}
                  value={category.id_categoria}
                >
                  {category.descripcion}
                </option>
              ))}
            </select>
          </div>
          <div className="mb-4">
            <label
              htmlFor="descripcion"
              className="block text-sm font-medium text-[#F24BA7]"
            >
              Descripción de la Subcategoría
            </label>
            <input
              type="text"
              name="descripcion"
              id="descripcion"
              value={newSubcategory.descripcion}
              onChange={handleSubcategoryInputChange}
              className="mt-1 p-2 border border-[#D96299] rounded w-full"
              required
            />
          </div>
          <button
            type="submit"
            className="w-full p-2 bg-[#F24BA7] text-white rounded hover:bg-[#D96299]"
          >
            Crear Subcategoría
          </button>
        </form>

        {/* Formulario para Marca */}
        <h2 className="text-2xl font-bold mb-4 text-gray">Crear Marca</h2>
        <form onSubmit={handleCreateBrand} className="mb-8">
          <div className="mb-4">
            <label
              htmlFor="nombre"
              className="block text-sm font-medium text-[#F24BA7]"
            >
              Nombre de la Marca
            </label>
            <input
              type="text"
              name="nombre"
              id="nombre"
              value={newBrand.nombre}
              onChange={handleBrandInputChange}
              className="mt-1 p-2 border border-[#D96299] rounded w-full"
              required
            />
          </div>
          <button
            type="submit"
            className="w-full p-2 bg-[#F24BA7] text-white rounded hover:bg-[#D96299]"
          >
            Crear Marca
          </button>
        </form>

        {/* Listado de Categorías */}
        <h3 className="text-xl font-bold mb-2 text-gray-800">
          Listado de Categorías
        </h3>
        <ul className="mb-8">
          {categories.map((category) => (
            <li
              key={category.id_categoria}
              className="border-b py-2 grid grid-cols-3 gap-4 items-center"
            >
              <span className="text-center">{category.descripcion}</span>
              {category.foto && (
                <div className="flex justify-center items-center">
                  <img
                    src={category.foto}
                    alt="miniatura"
                    className="w-12 h-12 object-cover cursor-pointer"
                    onClick={() => openModal(category.foto!)}
                  />
                </div>
              )}
              <button
                onClick={() => handleDeleteCategory(category.id_categoria!)}
                className="p-2 bg-[#F24BA7] text-white rounded mx-auto"
              >
                Eliminar
              </button>
            </li>
          ))}
        </ul>

        {/* Listado de Subcategorías */}
        <h3 className="text-xl font-bold mb-2 text-gray">
          Listado de Subcategorías
        </h3>
        <ul>
          {subcategories.map((subcategory) => (
            <li
              key={subcategory.id_subcategoria}
              className="border-b py-2 flex justify-between items-center"
            >
              <span>{subcategory.descripcion}</span>
              <div>
                <button
                  onClick={() =>
                    handleDeleteSubcategory(subcategory.id_subcategoria!)
                  }
                  className="p-1 bg-[#F24BA7] text-white rounded"
                >
                  Eliminar
                </button>
              </div>
            </li>
          ))}
        </ul>

        {/* Listado de Marcas */}
        <h3 className="text-xl font-bold mb-2 text-gray">
          Listado de Marcas
        </h3>
        <ul>
          {brands.map((brand) => (
            <li
              key={brand.id_marca}
              className="border-b py-2 flex justify-between items-center"
            >
              <span>{brand.nombre}</span>
              <div>
                <button
                  onClick={() => handleDeleteBrand(brand.id_marca!)}
                  className="p-1 bg-[#F24BA7] text-white rounded"
                >
                  Eliminar
                </button>
              </div>
            </li>
          ))}
        </ul>

        {/* Modal para mostrar imagen */}
        <Modal
          isOpen={modalIsOpen}
          onRequestClose={closeModal}
          contentLabel="Imagen de la Categoría"
        >
          <h2 className="text-xl font-bold mb-4">Imagen de la Categoría</h2>
          <img src={currentImage} alt="Categoría" className="mb-4" />
          <button
            onClick={closeModal}
            className="p-2 bg-[#F24BA7] text-white rounded"
          >
            Cerrar
          </button>
        </Modal>

        <ToastContainer />
      </div>
    </div>
  );
};

export default CategoryManager;