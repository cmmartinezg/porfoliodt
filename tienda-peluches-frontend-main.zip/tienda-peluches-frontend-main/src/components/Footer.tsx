// src/components/Footer.tsx
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-900 text-white p-8 mt-8">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div>
          <h3 className="font-bold">¿Dónde estamos?</h3>
          <p>Dirección de la tienda, Ciudad, País</p>
        </div>
        <div>
          <h3 className="font-bold">Atención al Cliente</h3>
          <ul>
            <li>Contacto</li>
            <li>FAQ</li>
          </ul>
        </div>
        {/* Agrega más secciones según sea necesario */}
      </div>
    </footer>
  );
};

export default Footer;
