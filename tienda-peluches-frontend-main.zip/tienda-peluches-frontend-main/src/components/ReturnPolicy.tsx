import React, { useEffect } from "react";
import logo from "../assets/boopillowslogo.png"; // Asegúrate de que la imagen de tu logo esté en la carpeta correcta

const ReturnPolicy: React.FC = () => {
  useEffect(() => {
    // Desplaza la ventana hacia el inicio cuando el componente se monte
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="flex justify-center my-12">
      {/* Margen externo superior e inferior */}
      <div className="p-8 mx-20 bg-white shadow-lg rounded-lg border border-[#D96299]">
        {/* Margen horizontal agregado */}
        
        {/* Logo agregado */}
        <div className="text-center mb-4">
          <img src={logo} alt="Boo Pillows Logo" className="mx-auto w-32" /> {/* Ajusta el tamaño según sea necesario */}
        </div>

        <h1 className="text-4xl font-bold text-center mb-4 text-[#D96299]">
          {/* Color del título */}
          POLÍTICAS DE CAMBIOS Y DEVOLUCIONES
        </h1>
        <p>
          Nuestro compromiso es su total satisfacción en las compras realizadas.
          Para evitar cualquier problema con su compra, al realizar el pedido,
          esté atento:{" "}
          <strong>al tamaño, diseño, color y precio del artículo.</strong>
        </p>
        <h2 className="text-2xl font-bold mt-4 text-[#F24BA7]">
          {/* Color del subtítulo */}
          1 - En caso de desistimiento de la compra en desacuerdo con la talla o
          el color del producto adquirido:
        </h2>
        <p>
          El cliente podrá solicitar el cambio y podrá devolvernos el producto
          en la Tienda en un plazo de <strong>24 horas</strong> a partir de la
          recepción del producto siempre que el producto presente idéntico
          importe y diseño y deberán observarse las siguientes condiciones:
        </p>
        <p>
          A- El producto deberá estar en el embalaje original (si lo tuviera),
          sin indicios de uso, sin violación de la etiqueta original del
          fabricante, con todas las piezas completas y acompañados de su{" "}
          <strong>factura nominada.</strong>
        </p>
        <p>
          B- La Tienda se reserva el derecho de no efectuar el cambio o
          devolución de ningún valor cuando conste que el producto ha sido
          utilizado previamente y que ya ha sido retirado del envase (si lo
          tuviera).
        </p>
        <p>
          C- La Tienda aceptará el cambio de los artículos, en cuyo caso deberá
          entregar junto con el artículo que desea cambiar el ticket de cambio a
          factura nominada que habrá recibido adjunto al producto y deberá
          presentarlo leído e impreso.{" "}
          <strong>No se realizan cambios de artículos en liquidación.</strong>
        </p>
        <h2 className="text-2xl font-bold mt-4 text-[#F24BA7]">
          2 - En caso de productos con defectos:
        </h2>
        <p>
          A- El producto será revisado para verificar la existencia de un
          defecto de fabricación. Si se constata que no hay defecto, la Tienda
          entregará el mismo producto al Cliente.
        </p>
        <p>
          B- Tras examinar el artículo le comunicaremos si tiene derecho al
          reembolso o sustitución del artículo y de la cantidad abonada a través
          de una <strong>nota de crédito.</strong>
        </p>
        <p>
          C- La sustitución podrá ser realizada en el mismo momento del cambio
          mientras que el reembolso se efectuará lo antes posible y, en
          cualquier caso, dentro de los <strong>5 días siguientes</strong> a la
          fecha en la que se confirme la devolución.
        </p>
        <p>
          D- El Cliente asumirá el costo y riesgo de devolvernos los productos.
          La tienda reembolsará íntegramente el reembolso incluidos los gastos
          de delivery y o inicios incurridos para entregarle el artículo.
        </p>
        <p>E- La devolución del pago se realizará de la siguiente manera:</p>
        <ul>
          <li>
            - En el mismo medio de pago que se utilizó para hacer la compra.
          </li>
          <li>
            - En los pagos con transferencia bancaria, el cliente deberá
            proporcionar su cuenta bancaria para que podamos realizar el
            reembolso.
          </li>
          <li>
            - En los pagos con POS el reembolso será efectuado íntegramente
            asumiendo la Tienda los gastos de comisiones efectuados por el
            servicio.
          </li>
        </ul>
        <p>
          <strong>
            No se hará ningún reembolso de productos que no estén en las mismas
            condiciones en las que se entregaron.
          </strong>
        </p>
      </div>
    </div>
  );
};

export default ReturnPolicy;
