import React, { useEffect, useState } from "react";
import { authenticatedApi } from "./api";
import { toast, ToastContainer } from "react-toastify";
import { Link } from "react-router-dom";
import Modal from "react-modal";

Modal.setAppElement('#root'); // Asegúrate de que este ID corresponde al elemento raíz en tu index.html

interface Product {
  id_producto: number;
  nombre: string;
  precio: number;
  stock: number;
  categoria: string;
  foto?: string;
}

const Products: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [modalIsOpen, setModalIsOpen] = useState(false);
  const [currentProduct, setCurrentProduct] = useState<Product | null>(null);

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      const response = await authenticatedApi.get("/products");
      setProducts(response.data);
    } catch (error) {
      console.error("Error fetching products:", error);
      toast.error("Error al cargar los productos");
    }
  };

  const deleteProduct = async (id: number) => {
    try {
      await authenticatedApi.delete(`/products/${id}`);
      setProducts(products.filter(product => product.id_producto !== id));
      toast.success("Producto eliminado con éxito");
    } catch (error) {
      console.error("Error deleting product:", error);
      toast.error("Error al eliminar producto");
    }
  };

  const openModal = (product: Product) => {
    setCurrentProduct(product);
    setModalIsOpen(true);
  };

  const closeModal = () => {
    setModalIsOpen(false);
  };

  return (
    <div>
      <h2>Gestión de Productos</h2>
      <Link to="/product/new" className="btn btn-primary">
        Agregar Producto
      </Link>
      <table className="table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Precio</th>
            <th>Stock</th>
            <th>Categoría</th>
            <th>Foto</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          {products.map((product) => (
            <tr key={product.id_producto}>
              <td>{product.id_producto}</td>
              <td>{product.nombre}</td>
              <td>{product.precio.toFixed(2)}</td>
              <td>{product.stock}</td>
              <td>{product.categoria}</td>
              <td>
                {product.foto && <img src={product.foto} alt={product.nombre} style={{ width: '50px', height: '50px' }} />}
              </td>
              <td>
                <button onClick={() => openModal(product)} className="btn btn-info">Ver</button>
                <Link to={`/product/edit/${product.id_producto}`} className="btn btn-warning">Editar</Link>
                <button onClick={() => deleteProduct(product.id_producto)} className="btn btn-danger">Eliminar</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      
      {currentProduct && (
        <Modal
          isOpen={modalIsOpen}
          onRequestClose={closeModal}
          contentLabel="Product Details"
        >
          <h2>{currentProduct.nombre}</h2>
          <p>Precio: ${currentProduct.precio.toFixed(2)}</p>
          <p>Stock: {currentProduct.stock}</p>
          <p>Categoría: {currentProduct.categoria}</p>
          {currentProduct.foto && <img src={currentProduct.foto} alt={currentProduct.nombre} style={{ maxWidth: '100%' }} />}
          <button onClick={closeModal}>Cerrar</button>
        </Modal>
      )}

      <ToastContainer />
    </div>
  );
};

export default Products;
