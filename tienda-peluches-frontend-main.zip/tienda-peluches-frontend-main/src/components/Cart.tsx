import React, { useState } from "react";
import { FaTrash } from "react-icons/fa";
import { useCart } from "./CartContext";

const departamentosYciudades = {
  // lista de departamentos y ciudades
  Central: ["Asunción", "San Lorenzo", "Luque", "Fernando de la Mora"],
  "Alto Paraná": [
    "Ciudad del Este",
    "Hernandarias",
    "Minga Guazú",
    "Presidente Franco",
  ],
  Itapúa: ["Encarnación", "Hohenau", "Obligado", "Cambyretá"],
  Cordillera: ["Caacupé", "Tobatí", "Atyrá", "Piribebuy"],
  Guairá: ["Villarrica", "Independencia", "Mbocayaty", "Borja"],
  Caaguazú: ["Coronel Oviedo", "Caaguazú", "Doctor Juan Eulogio Estigarribia"],
  Caazapá: ["Caazapá", "San Juan Nepomuceno", "Yuty", "Abaí"],
  Misiones: ["San Juan Bautista", "San Ignacio", "Santa Rosa", "Ayolas"],
  Paraguarí: ["Paraguarí", "Yaguarón", "Carapeguá", "Sapucai"],
  "Presidente Hayes": [
    "Villa Hayes",
    "Nanawa",
    "Benjamín Aceval",
    "José Falcón",
  ],
  Boquerón: ["Filadelfia", "Loma Plata", "Mariscal Estigarribia"],
  Ñeembucú: ["Pilar", "Humaitá", "Tacuara", "Tacuaras"],
  Amambay: ["Pedro Juan Caballero", "Zanja Pytá", "Bella Vista Norte"],
  Concepción: ["Concepción", "Horqueta", "Belén", "Loreto"],
  "San Pedro": [
    "San Pedro de Ycuamandiyú",
    "Santa Rosa del Aguaray",
    "Chore",
    "Guayaibí",
  ],
  Canindeyú: ["Salto del Guairá", "Curuguaty", "Ypejhú", "La Paloma"],
  "Alto Paraguay": ["Fuerte Olimpo", "Bahía Negra", "Puerto Casado"],
};

const Cart: React.FC = () => {
  const { cartItems, removeFromCart } = useCart();

  const [customerInfo, setCustomerInfo] = useState({
    firstName: "",
    lastName: "",
    documentType: "CI",
    documentNumber: "",
    phoneNumber: "",
    country: "Paraguay",
    department: "",
    city: "",
    address: "",
  });

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    setCustomerInfo({
      ...customerInfo,
      [e.target.name]: e.target.value,
    });
  };

  const handleDepartmentChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const department = e.target.value;
    setCustomerInfo({
      ...customerInfo,
      department,
      city: "",
    });
  };

  const handleSave = () => {
    console.log("Datos del cliente guardados:", customerInfo);
    alert("Datos del cliente guardados correctamente.");
  };

  const total = cartItems.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );

  return (
    <div className="max-w-6xl mx-auto p-8 mt-8 grid grid-cols-2 gap-12">
      {/* Columna 1: Datos del Comprador */}
      <div>
        <h3 className="text-2xl font-bold mb-6 text-[#F24BA7]">
          Datos del Comprador
        </h3>
        <form>
          <div className="mb-6">
            <label className="block text-gray-700">Nombre:</label>
            <input
              type="text"
              name="firstName"
              value={customerInfo.firstName}
              onChange={handleInputChange}
              className="w-full px-3 py-2 border rounded-md"
              placeholder="Nombre"
            />
          </div>
          <div className="mb-6">
            <label className="block text-gray-700">Apellido:</label>
            <input
              type="text"
              name="lastName"
              value={customerInfo.lastName}
              onChange={handleInputChange}
              className="w-full px-3 py-2 border rounded-md"
              placeholder="Apellido"
            />
          </div>
          <div className="mb-6">
            <label className="block text-gray-700">Tipo de Documento:</label>
            <select
              name="documentType"
              value={customerInfo.documentType}
              onChange={handleInputChange}
              className="w-full px-3 py-2 border rounded-md"
            >
              <option value="CI">CI</option>
              <option value="RUC">RUC</option>
            </select>
          </div>
          <div className="mb-6">
            <label className="block text-gray-700">Número de Documento:</label>
            <input
              type="text"
              name="documentNumber"
              value={customerInfo.documentNumber}
              onChange={handleInputChange}
              className="w-full px-3 py-2 border rounded-md"
              placeholder="Número de Documento"
            />
          </div>
          <div className="mb-6">
            <label className="block text-gray-700">Número de Teléfono:</label>
            <input
              type="tel"
              name="phoneNumber"
              value={customerInfo.phoneNumber}
              onChange={handleInputChange}
              className="w-full px-3 py-2 border rounded-md"
              placeholder="Número de Teléfono"
            />
          </div>
          <div className="mb-6">
            <label className="block text-gray-700">País:</label>
            <select
              name="country"
              value={customerInfo.country}
              onChange={handleInputChange}
              className="w-full px-3 py-2 border rounded-md"
            >
              <option value="Paraguay">Paraguay</option>
            </select>
          </div>
          <div className="mb-6">
            <label className="block text-gray-700">Departamento:</label>
            <select
              name="department"
              value={customerInfo.department}
              onChange={handleDepartmentChange}
              className="w-full px-3 py-2 border rounded-md"
            >
              <option value="">Seleccionar Departamento</option>
              {Object.keys(departamentosYciudades).map((dep) => (
                <option key={dep} value={dep}>
                  {dep}
                </option>
              ))}
            </select>
          </div>
          <div className="mb-6">
            <label className="block text-gray-700">Ciudad:</label>
            <select
              name="city"
              value={customerInfo.city}
              onChange={handleInputChange}
              className="w-full px-3 py-2 border rounded-md"
              disabled={!customerInfo.department}
            >
              <option value="">Seleccionar Ciudad</option>
              {customerInfo.department &&
                departamentosYciudades[
                  customerInfo.department as keyof typeof departamentosYciudades
                ]?.map((city) => (
                  <option key={city} value={city}>
                    {city}
                  </option>
                ))}
            </select>
          </div>
          <div className="mb-6">
            <label className="block text-gray-700">Dirección:</label>
            <input
              type="text"
              name="address"
              value={customerInfo.address}
              onChange={handleInputChange}
              className="w-full px-3 py-2 border rounded-md"
              placeholder="Dirección"
            />
          </div>
          <div className="flex justify-end">
            <button
              type="button"
              onClick={handleSave}
              className="mt-4 bg-pink-500 text-white py-2 px-4 rounded hover:bg-pink-600 transition duration-300"
            >
              Guardar Datos
            </button>
          </div>
        </form>
      </div>

      {/* Columna 2: Carrito de Compras */}
      <div>
        <h3 className="text-2xl font-bold mb-6 text-[#F24BA7]">
          Carrito de Compras
        </h3>
        <ul>
          {cartItems.map((item) => (
            <li
              key={item.id}
              className="flex justify-between items-center border-b py-4"
            >
              <img
                src={item.image || "/ruta_default_de_imagen.jpg"}
                alt={item.name}
                className="h-16 w-16 object-cover rounded-md"
              />
              <div className="flex-grow pl-4">
                <h3 className="text-lg font-semibold">{item.name}</h3>
                <p>Cantidad: {item.quantity}</p>
              </div>
              <p className="text-pink-500 font-bold">
                Gs. {(item.price * item.quantity).toLocaleString("es-PY")}
              </p>
              <button
                onClick={() => removeFromCart(item.id)}
                className="bg-transparent hover:bg-red-500 text-red-500 font-bold py-2 px-4 rounded-full hover:text-white transition duration-300 ml-4"
                title="Eliminar del carrito"
              >
                <FaTrash size={20} />
              </button>
            </li>
          ))}
        </ul>
        <div className="mt-8">
          <h3 className="text-xl font-bold mb-4 text-[#F24BA7]">
            Total: Gs. {total.toLocaleString("es-PY")}
          </h3>
          <div className="flex justify-end">
            <button className="mt-2 bg-pink-500 text-white py-2 px-4 rounded hover:bg-pink-600 transition duration-300">
              Proceder al Pago
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Cart;
