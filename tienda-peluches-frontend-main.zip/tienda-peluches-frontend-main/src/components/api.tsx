import axios, { AxiosInstance } from "axios";

// Define la URL base para localhost y producción
const LOCAL_API_BASE_URL = "http://localhost:3000/api"; // URL del backend local
const PROD_API_BASE_URL = "https://tienda-peluches-backend.onrender.com/api"; // URL del backend en producción

// Verifica si se está ejecutando en localhost
const isLocalhost = window.location.hostname === "localhost" || window.location.hostname === "127.0.0.1";

// Selecciona la URL base según la condición
const API_BASE_URL = isLocalhost ? LOCAL_API_BASE_URL : PROD_API_BASE_URL;

// Instancia de Axios sin autenticación
const api = axios.create({
  baseURL: API_BASE_URL,
});

// Función para obtener el token dinámicamente
const getToken = () => localStorage.getItem('token');

// Instancia de Axios con autenticación
const authenticatedApi: AxiosInstance = axios.create({
  baseURL: API_BASE_URL,
});

// Middleware de Axios para agregar el token de autenticación dinámicamente
authenticatedApi.interceptors.request.use(
  (config) => {
    const token = getToken();
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

export { authenticatedApi };
export default api;
