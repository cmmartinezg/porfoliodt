import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { createUserWithEmailAndPassword, signInWithPopup } from 'firebase/auth';
import { FaGoogle, FaFacebook } from 'react-icons/fa';
import { auth, googleProvider, facebookProvider } from '../components/firebaseConfig';
import authenticatedApi from '../components/api'; // Asumo que authenticatedApi está configurado

const Registro: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const navigate = useNavigate();

  // Función para manejar el registro con email
  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password !== confirmPassword) {
      alert('Las contraseñas no coinciden');
      return;
    }

    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;

      // Enviar el registro al backend para guardar el usuario en la base de datos
      await authenticatedApi.post('/usuarios', {
        email: user.email,
        nombre: user.displayName || 'Usuario sin nombre',  // Puedes personalizar esto
        rol: 'usuario',  // Puedes ajustar según la lógica de tu aplicación
      });

      navigate('/login');
    } catch (error: any) { // Cambiamos el tipo de error a `any`
      console.error('Error al crear la cuenta:', error?.message || error);
    }
  };

  const handleSocialLogin = async (provider: any) => {
    try {
      const result = await signInWithPopup(auth, provider);
      const token = await result.user.getIdToken(); // Obtener el token de Firebase
  
      // Enviar el token al backend para verificar o registrar al usuario
      const response = await authenticatedApi.post('/social/login-social', { token }); // Ajustar la URL base según tu configuración
  
      // Guardar el token JWT si lo necesitas
      const tokenJWT = response.data.token;
      localStorage.setItem('tokenJWT', tokenJWT);
  
      // También puedes guardar el nombre del usuario
      const userName = result.user.displayName || 'Usuario sin nombre';
      localStorage.setItem('userName', userName);
  
      navigate('/');
    } catch (error: any) {
      console.error('Error durante el inicio de sesión con el proveedor:', error);
    }
  };
  
  
  return (
    <div className="flex justify-center items-center h-screen bg-gradient-to-r from-pink-300 via-pink-400 to-pink-500">
      <div className="bg-white p-8 rounded-lg shadow-lg w-96">
        <h2 className="text-3xl font-bold mb-6 text-center text-pink-600">Crear Cuenta</h2>
        <form onSubmit={handleRegister}>
          <div className="mb-4">
            <label className="block text-gray-700 text-sm font-bold mb-2">Correo Electrónico</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              className="w-full p-3 border rounded-md focus:outline-none focus:ring-2 focus:ring-pink-400 transition duration-300"
              placeholder="tu@correo.com"
            />
          </div>
          <div className="mb-4">
            <label className="block text-gray-700 text-sm font-bold mb-2">Contraseña</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              className="w-full p-3 border rounded-md focus:outline-none focus:ring-2 focus:ring-pink-400 transition duration-300"
              placeholder="••••••••"
            />
          </div>
          <div className="mb-6">
            <label className="block text-gray-700 text-sm font-bold mb-2">Confirmar Contraseña</label>
            <input
              type="password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              required
              className="w-full p-3 border rounded-md focus:outline-none focus:ring-2 focus:ring-pink-400 transition duration-300"
              placeholder="••••••••"
            />
          </div>
          <button
            type="submit"
            className="w-full bg-pink-600 text-white py-3 rounded-md font-semibold shadow-lg hover:bg-pink-700 transition-transform transform hover:scale-105 duration-300"
          >
            Registrarse
          </button>
        </form>

        <div className="my-4 text-center text-gray-600">O regístrate con</div>

        {/* Botones para login social */}
        <div className="flex justify-between space-x-4">
          <button
            onClick={() => handleSocialLogin(googleProvider)}
            className="flex items-center justify-center w-full bg-white border border-gray-300 py-2 px-4 rounded-md font-semibold shadow-md hover:bg-gray-100 transition duration-300"
          >
            <FaGoogle className="text-red-500 mr-2" /> Google
          </button>
          <button
            onClick={() => handleSocialLogin(facebookProvider)}
            className="flex items-center justify-center w-full bg-white border border-gray-300 py-2 px-4 rounded-md font-semibold shadow-md hover:bg-gray-100 transition duration-300"
          >
            <FaFacebook className="text-blue-600 mr-2" /> Facebook
          </button>
        </div>

        <p className="mt-4 text-center text-gray-600 text-sm">
          ¿Ya tienes cuenta?{' '}
          <button
            onClick={() => navigate('/login')}
            className="text-pink-500 font-semibold hover:underline"
          >
            Inicia sesión aquí
          </button>
        </p>
      </div>
    </div>
  );
};

export default Registro;
