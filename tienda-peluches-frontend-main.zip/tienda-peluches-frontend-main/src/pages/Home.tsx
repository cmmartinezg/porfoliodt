import React, { useEffect, useState } from "react";
import CategorySlider from "../components/CategorySlider";
import Benefits from "../components/Benefits";
import HeroBanner from "../components/HeroBanner";
import ProductCard from "../components/ProductCard";
import { authenticatedApi } from "../components/api";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/pagination";
import "swiper/css/autoplay";
import { Navigation, Pagination, Autoplay } from "swiper/modules";

interface Product {
  id: number;
  name: string;
  price: number;
  image: string;
}

const Home: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([]);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await authenticatedApi.get("/productos");
        const fetchedProducts = response.data.map((product: any) => ({
          id: product.id_producto,
          name: product.nombre,
          price: parseFloat(product.precio),
          image:
            Array.isArray(product.foto) && product.foto.length > 0
              ? product.foto[0]
              : "/ruta_default_de_imagen.jpg",
        }));

        const latestProducts = fetchedProducts.slice(-10);
        setProducts(latestProducts);
      } catch (error) {
        console.error("Error al cargar los productos:", error);
      }
    };

    fetchProducts();

    // Solicitar permiso para las notificaciones
    const requestNotificationPermission = async () => {
      if ("Notification" in window) {
        const permission = await Notification.requestPermission();
        if (permission === "granted") {
          console.log("Permisos de notificación concedidos.");
          showNotification("¡Bienvenido!", "Ahora puedes recibir actualizaciones de nuestros productos.");
        } else if (permission === "denied") {
          console.log("Permisos de notificación denegados.");
        } else {
          console.log("Permisos de notificación ignorados.");
        }
      } else {
        console.log("Este navegador no soporta notificaciones.");
      }
    };

    const showNotification = (title: string, body: string) => {
      const notification = new Notification(title, {
        body: body,
        icon: "../assets/boopillowslogo.png", // Puedes agregar un icono si lo deseas
      });

      // Opcional: Manejar el evento de clic en la notificación
      notification.onclick = () => {
        console.log("Notificación clicada");
        // Puedes redirigir al usuario a otra página si lo deseas
      };
    };

    requestNotificationPermission();
  }, []);

  return (
    <main className="bg-gray-50">
      <HeroBanner />
      <CategorySlider />

      {/* Sección de los más vendidos */}
      <section className="p-8 bg-white shadow-lg rounded-lg mt-12 mb-12">
        <h2 className="text-3xl font-extrabold text-center mb-6 text-pink-600">
          Los Más Vendidos
        </h2>
        <Swiper
          spaceBetween={10}
          slidesPerView={3}
          navigation={{
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev",
          }}
          pagination={{
            clickable: true,
            renderBullet: (className) => {
              return `<span class="${className}" style="background-color: #F24BA7;"></span>`;
            },
          }}
          autoplay={{ delay: 3000 }}
          modules={[Navigation, Pagination, Autoplay]}
          className="w-full"
        >
          {products.map((product) => (
            <SwiperSlide key={product.id}>
              <ProductCard product={product} />
            </SwiperSlide>
          ))}
          {/* Botones de navegación para Los Más Vendidos */}
          <div className="swiper-button-next" style={{ color: "#F24BA7" }} />
          <div className="swiper-button-prev" style={{ color: "#F24BA7" }} />
        </Swiper>
      </section>

      {/* Sección de productos listados con carrusel */}
      <section className="p-8 bg-white shadow-lg rounded-lg mt-12 mb-12">
        <h2 className="text-3xl font-extrabold text-center mt-12 mb-8 text-pink-600">
          Nuevos Productos
        </h2>
        <Swiper
          spaceBetween={10}
          slidesPerView={3}
          navigation={{
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev",
          }}
          pagination={{
            clickable: true,
            renderBullet: (className) => {
              return `<span class="${className}" style="background-color: #F24BA7;"></span>`;
            },
          }}
          autoplay={{ delay: 3000 }}
          modules={[Navigation, Pagination, Autoplay]}
          className="w-full"
        >
          {products.map((product) => (
            <SwiperSlide key={product.id}>
              <ProductCard product={product} />
            </SwiperSlide>
          ))}
          {/* Botones de navegación para Nuevos Productos */}
          <div className="swiper-button-next" style={{ color: "#F24BA7" }} />
          <div className="swiper-button-prev" style={{ color: "#F24BA7" }} />
        </Swiper>
      </section>

      <Benefits />
    </main>
  );
};

export default Home;
