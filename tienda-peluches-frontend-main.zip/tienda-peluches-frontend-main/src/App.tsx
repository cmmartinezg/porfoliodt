import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/NavBar';
import Home from './pages/Home';
import Cart from './components/Cart';
import ProductDetail from './components/ProductDetail';
import MiCuenta from './components/MiCuenta';
import ProductUploadForm from './components/ProductUploadForm';
import CategoryManager from './components/CategoryManager';
import ProductList from './components/ProductList';
import Login from './components/Login';
import Registro from './components/Registro';
import ElegantProductList from './components/ElegantProductList';
import { CartProvider } from './components/CartContext';
import AdminPanel from './components/AdminPanel'; // Importación correcta del panel administrador
import PublicidadForm from './components/PublicidadForm'; // Importación correcta del panel administrador
import Benefits from "./components/Benefits";
import AboutUs from "./components/AboutUs";
import ReturnPolicy from './components/ReturnPolicy'; // Asegúrate de que la ruta sea correcta
import PoliticaPrivacidad from './components/PoliticaPrivacidad'; // Importa la página de la política de privacidad

// Asegúrate de que todos los componentes estén correctamente importados

const App: React.FC = () => {
  return (
    <CartProvider>
      <Router>
        <div className="app">
          <Navbar /> {/* Navbar siempre estará en la parte superior */}
          <div className="content pt-20">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/producto/:id" element={<ProductDetail />} />
              <Route path="/carrito" element={<Cart />} />
              <Route path="/mi-cuenta" element={<MiCuenta />} />
              <Route path="/subir-producto" element={<ProductUploadForm />} />
              <Route path="/CategoryManager" element={<CategoryManager />} />
              <Route path="/productos" element={<ProductList />} />
              <Route path="/login" element={<Login />} />
              <Route path="/registro" element={<Registro />} />
              <Route path="/producto-elegante" element={<ElegantProductList />} />
              {/* Ruta del panel de administración */}
              <Route path="/admin/*" element={<AdminPanel />} />
              {/* Puedes manejar subrutas dentro del AdminPanel si es necesario */}
              <Route path="/PublicidadForm" element={<PublicidadForm />} />
              <Route path="/" element={<Benefits />} />
        <Route path="/about-us" element={<AboutUs />} />
        <Route path="/return-policy" element={<ReturnPolicy />} />
        <Route path="/politica-privacidad" element={<PoliticaPrivacidad/>} />

            </Routes>
          </div>
        </div>
      </Router>
    </CartProvider>
  );
};

export default App;
