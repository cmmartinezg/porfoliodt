export default {
  trailingComma: 'none',
  singleQuote: true,
  printWidth: 80,
  semi: true,
  bracketSpacing: false,
};
