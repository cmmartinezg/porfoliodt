import React, { useState, useEffect, ChangeEvent, FormEvent } from "react";
import axios from "axios";
import { ContentHeader } from "@components";
import { useSelector } from 'react-redux';
import { useNavigate, useParams, Link } from "react-router-dom";
import { authenticatedApi } from "../interfaces/api";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import listaDepartamentos from "../interfaces/departamentos";
import listaCiudades from "../interfaces/ciudades";
import barrios from "../interfaces/barrios";
import Select from "react-select";

const EditarProfile = () => {
  const authentication = useSelector((state: any) => state.auth.authentication);
  const id = `${authentication.profile.id}`
  const [data, setData] = useState({
    sexo: "",
    fecha_nacimiento: "2000-01-01",
    direccion: "",
    departamento: "",
    ciudad: "",
    barrio: "",
    puntos: 0,
    fuma: "",
    toma_alcohol: "",
    tipo_documento: "",
    numero_documento: "",
    nombre: "",
    apellido: "",
    email: "",
    celular: "",
    area_trabajo: "",
    perfil: "",
    empresa_id: "",
    foto: "", // Nombre de archivo de la foto
  });

  type Departamento = keyof typeof listaCiudades;
  type Ciudad = (typeof listaCiudades)[Departamento][number];
  const [selectedBarrio, setSelectedBarrio] = useState("");
  const [file, setFile] = useState<File | null>(null);

  const navigate = useNavigate();


  useEffect(() => {
    authenticatedApi()
    .get(`/usuario/${id}`)
      .then((res) => {
        const personaData = res.data;
        setData(personaData);
      })
      .catch((err) => {
        console.error(err);
        toast.error("Error al cargar los datos de la persona");
      });
  }, [id]);
  
  function handleFileChange(event: ChangeEvent<HTMLInputElement>) {
    if (event.target.files && event.target.files.length > 0) {
      const selectedFile = event.target.files[0];
      setFile(selectedFile);
    }
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const formData = new FormData();
    if (file) {
      formData.append("file", file); // Adjunta la foto al FormData
    }

    const responseUpload = await authenticatedApi().post("/upload_perfil", formData); // Cambia la URL de la API para subir la foto
    const { filename } = responseUpload.data;
    const newData = { ...data, foto: filename }; 

    authenticatedApi().put(`/usuario/${id}`, newData)
      .then((res) => {
        toast.success("Datos actualizados con éxito!");
        setTimeout(() => {
          navigate("/profile");
        }, 3000);
      })
      .catch((err) => {
        console.error(err);
        toast.error("Error al actualizar los datos del perfil");
      });
  };

  return (
    <div>
      <ContentHeader title="Editar Perfil" />
      <section className="content">
        <div className="container-fluid">
          <div className="card card-info card-outline">
            <div className="card-header">
              <h3 className="card-title">Ingresar Información del Perfil</h3>
              <div className="card-tools">
                <Link to={`/profile`} className="btn btn-info">
                  Volver al Perfil
                </Link>
              </div>
            </div>
            <div className="card-body">
              <form onSubmit={handleSubmit} className="row">
                <div className="col-md-12">
                  <div className="card card-light">
                    <div className="card-header">
                      <h4 className="card-title">Datos Personales</h4>
                    </div>
                    <div className="card-body">
                      <div className="row">
                        <div className="col-md-6">
                          <div className="form-group">
                            <label htmlFor="nombre">Nombre *</label>
                            <input
                              type="text"
                              className="form-control"
                              id="nombre"
                              placeholder="Nombre de la persona"
                              required
                              value={data.nombre}
                              onChange={(e) =>
                                setData({ ...data, nombre: e.target.value })
                              }
                            />
                          </div>
                          <div className="form-group">
                            <label htmlFor="apellido">Apellido *</label>
                            <input
                              type="text"
                              className="form-control"
                              id="apellido"
                              placeholder="Apellido de la persona"
                              required
                              value={data.apellido}
                              onChange={(e) =>
                                setData({ ...data, apellido: e.target.value })
                              }
                            />
                          </div>
                          <div className="form-group">
                            <label htmlFor="tipo_documento">
                              Tipo de Documento *
                            </label>
                            <select
                              className="form-control"
                              id="tipo_documento"
                              name="tipo_documento"
                              required
                              value={data.tipo_documento}
                              onChange={(e) =>
                                setData({
                                  ...data,
                                  tipo_documento: e.target.value,
                                })
                              }
                            >
                              <option value="">
                                Seleccionar el tipo de Documento
                              </option>
                              <option value="CEDULA">
                                Cédula de Identidad
                              </option>
                              <option value="PASAPORTE">Pasaporte</option>
                            </select>
                          </div>
                          <div className="form-group">
                            <label htmlFor="numero_documento">
                              Número de Documento *
                            </label>
                            <div className="input-group">
                              <div className="input-group-prepend">
                                <span className="input-group-text">
                                  <i className="fas fa-id-card" />
                                </span>
                              </div>
                              <input
                                type="text"
                                className="form-control"
                                id="numero_documento"
                                name="numero_documento"
                                placeholder="Número de Documento"
                                required
                                value={data.numero_documento}
                                onChange={(e) =>
                                  setData({
                                    ...data,
                                    numero_documento: e.target.value,
                                  })
                                }
                              />
                            </div>
                          </div>
                          <div className="form-group">
                            <label htmlFor="email">Email *</label>
                            <div className="input-group">
                              <div className="input-group-prepend">
                                <span className="input-group-text">
                                  <i className="fas fa-envelope" />
                                </span>
                              </div>
                              <input
                                type="email"
                                className="form-control"
                                id="email"
                                name="email"
                                placeholder="Correo electrónico"
                                required
                                value={data.email}
                                onChange={(e) =>
                                  setData({ ...data, email: e.target.value })
                                }
                              />
                            </div>
                          </div>
                          <div className="form-group">
                            <label htmlFor="celular">Celular *</label>
                            <div className="input-group">
                              <div className="input-group-prepend">
                                <span className="input-group-text">
                                  <i className="fas fa-phone" />
                                </span>
                              </div>
                              <input
                                type="text"
                                className="form-control"
                                id="celular"
                                name="celular"
                                placeholder="Número de celular"
                                required
                                value={data.celular}
                                onChange={(e) =>
                                  setData({ ...data, celular: e.target.value })
                                }
                              />
                            </div>
                          </div>
                          <div className="form-group">
                            <label htmlFor="foto">Foto de Perfil</label>
                            <input
                              type="file"
                              className="form-control"
                              id="foto"
                              accept="image/jpeg, image/png" // Puedes ajustar las extensiones permitidas
                              onChange={handleFileChange}
                            />
                          </div>
                        </div>

                        <div className="col-md-6">
                          <div className="form-group">
                            <label htmlFor="sexo">Sexo *</label>
                            <select
                              className="form-control"
                              id="sexo"
                              value={data.sexo}
                              onChange={(e) =>
                                setData({ ...data, sexo: e.target.value })
                              }
                            >
                              <option value="">Seleccionar sexo</option>
                              <option value="MASCULINO">Masculino</option>
                              <option value="FEMENINO">Femenino</option>
                            </select>
                          </div>
                          <div className="form-group">
                            <label htmlFor="fecha_nacimiento">
                              Fecha de Nacimiento *
                            </label>
                            <input
                              type="date"
                              className="form-control"
                              id="fecha_nacimiento"
                              required
                              max="2022-01-01"
                              value={data.fecha_nacimiento}
                              onChange={(e) =>
                                setData({
                                  ...data,
                                  fecha_nacimiento: e.target.value,
                                })
                              }
                            />
                        </div>
                          <div className="form-group">
                            <label htmlFor="direccion">Dirección *</label>
                            <div className="input-group">
                              <div className="input-group-prepend">
                                <span className="input-group-text">
                                  <i className="fas fa-map-marker-alt" />
                                </span>
                              </div>
                              <input
                                type="text"
                                className="form-control"
                                id="direccion"
                                placeholder="Dirección de la persona"
                                value={data.direccion}
                                onChange={(e) =>
                                  setData({ ...data, direccion: e.target.value })
                                }
                              />
                            </div>
                          </div>
                          <div className="form-group">
                            <label htmlFor="departamento">Departamento *</label>
                            <select
                              className="form-control"
                              id="departamento"
                              required
                              value={data.departamento}
                              onChange={(e) => {
                                const selectedDepartamento = e.target
                                  .value as Departamento;
                                const defaultCiudad =
                                  selectedDepartamento in listaCiudades
                                    ? listaCiudades[
                                    selectedDepartamento as Departamento
                                    ][0]
                                    : "";
                                setData({
                                  ...data,
                                  departamento: selectedDepartamento,
                                  ciudad: defaultCiudad,
                                });
                              }}
                            >
                              <option value="">
                                Seleccionar el Departamento
                              </option>
                              {listaDepartamentos.map((departamento) => (
                                <option key={departamento} value={departamento}>
                                  {departamento}
                                </option>
                              ))}
                            </select>
                          </div>
                          <div className="form-group">
                            <label htmlFor="ciudad">Ciudad *</label>
                            <select
                              className="form-control"
                              id="ciudad"
                              required
                              value={data.ciudad || ""}
                              onChange={(e) =>
                                setData({ ...data, ciudad: e.target.value })
                              }
                            >
                              <option value="">Seleccionar la Ciudad</option>
                              {data.departamento in listaCiudades
                                ? listaCiudades[
                                  data.departamento as Departamento
                                ].map((ciudad: Ciudad) => (
                                  <option key={ciudad} value={ciudad}>
                                    {ciudad}
                                  </option>
                                ))
                                : null}
                            </select>
                          </div>
                          <div className="form-group">
                            <label htmlFor="barrio">Barrio *</label>
                            <Select
                              id="barrio"
                              name="barrio"
                              placeholder="Seleccionar el Barrio"
                              options={barrios
                                .filter(
                                  (barrio) => barrio.ciudad === data.ciudad
                                )
                                .map((barrio, index) => ({
                                  value: barrio.barrio,
                                  label: barrio.barrio,
                                }))}
                              value={{
                                label: data.barrio,
                                value: data.barrio,
                              }}
                              onChange={(selectedOption) =>
                                setData({
                                  ...data,
                                  barrio: selectedOption
                                    ? selectedOption.value
                                    : "",
                                })
                              }
                            />
                          </div>

                          <div className="form-group">
                            <label htmlFor="area_trabajo">
                              Área de Trabajo
                            </label>
                            <input
                              type="text"
                              className="form-control"
                              id="area_trabajo"
                              name="area_trabajo"
                              placeholder="Área de Trabajo"
                              value={data.area_trabajo}
                              onChange={(e) =>
                                setData({
                                  ...data,
                                  area_trabajo: e.target.value,
                                })
                              }
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="col-md-12">
                  <button type="submit" className="btn btn-info">
                    Guardar
                  </button>
                </div>
              </form>
            </div>
            <div className="card-footer">
              <small>
                * Campos obligatorios: Por favor, complete estos campos
              </small>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
export default EditarProfile;
