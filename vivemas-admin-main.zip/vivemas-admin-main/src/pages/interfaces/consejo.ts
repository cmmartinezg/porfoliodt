export interface Consejo {
    id: number;
    tipo: string;
    consejo: string;
}
