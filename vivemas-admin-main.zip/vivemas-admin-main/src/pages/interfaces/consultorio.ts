export interface Consultorio {
    id: number;
    nombre: string;
    direccion: string;
    latitud: number;
    longitud: number;
  }