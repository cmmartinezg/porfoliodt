export interface ActividadExtra {
  id: number;
  descripcion: string;
  fecha: number;
  puntos: number;
  costo: number;
  enlace: string;
  stock: number;
}
