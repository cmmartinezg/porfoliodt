export interface Plan {
    id: number;
    plan: string;
    descripcion: string;
    costo: number;
  }