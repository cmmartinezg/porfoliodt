const Departamentos = [
  "ALTO PARAGUAY",
  "ALTO PARANÁ",
  "AMAMBAY",
  "ASUNCIÓN",
  "BOQUERÓN",
  "CAAGUAZÚ",
  "CAAZAPÁ",
  "CANINDEYÚ",
  "CENTRAL",
  "CONCEPCIÓN",
  "CORDILLERA",
  "GUAIRÁ",
  "ITAPÚA",
  "MISIONES",
  "ÑEEMBUCÚ",
  "PARAGUARI",
  "PRESIDENTE HAYES",
  "SAN PEDRO",
];

export default Departamentos;