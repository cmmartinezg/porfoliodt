export interface Ingrediente {
    calorias: string;
    descripcion: string;
    grasa: string;
    grupo_alimento: string;
    hidrato: string;
    id: number;
    medida: string;
    medida_practica: string;
    peso: string;
    proteina: string;
    um_practica: string;
    unidad_medida: string;
  }