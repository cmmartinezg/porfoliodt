export interface Empresa {
  id: number;
  empresa: string;
  razon_social: string;
  direccion: string;  
  telefono: string;   
  email: string;      
}