export interface Premio {
    id: number;
    sucursal: number;
    premio: string;
    puntos: number;
    stock: number;
    precio: number;
    foto: string;
    foto_enlace: string;
    nombre_comercio: string;
    premio_observacion: string;
  
  }