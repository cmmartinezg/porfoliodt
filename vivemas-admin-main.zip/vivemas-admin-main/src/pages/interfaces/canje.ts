export interface Canje {
    id: number;
    nombre: string;
    apellido: string;
    numero_documento: string;
    premio: string;
    fecha: string;
    comercio: string;
    sucursal: string;
    estado: string;
    qr: string;
  }
  