export interface Racion {
    id: number;
    racion: string;
    peso_coccion: string;
    medida: number;
    medida_practica: number;
    um_practica: string;
    calorias_cal: number;
    hidrato_gr: number;
    proteina_gr: number;
    grasa_gr: number;
}