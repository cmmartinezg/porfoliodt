export interface Sucursal {
    id: number;
    comercio: number;
    sucursal: string;
    direccion: string;
    contacto_nombre_apellido: string;
    contacto_celular: string;
    email: string;
    nombre_comercio: string;
    ubicacion: string;
  }
  