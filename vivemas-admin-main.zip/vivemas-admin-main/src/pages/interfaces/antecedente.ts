export interface Antecedente {
    id: number;
    antecedente: string;
  }
  