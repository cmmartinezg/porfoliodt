export interface Usuario {
    id: number;
    fecha_hora_registro: string;
    tipo_documento: string;
    numero_documento: string;
    nombre: string;
    apellido: string;
    email: string;
    celular: string;
    contrasena: string;
    area_trabajo: string;
    estado: string;
    perfil: string;
    empresa_nombre: string;
    comercio_nombre: string;
  }
  