export interface CategoriaPremios {
  id: number;
  nombre: string;
  descripcion: string;
}
